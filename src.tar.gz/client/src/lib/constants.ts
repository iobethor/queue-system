// API endpoints
export const API_BASE_URL = '/api';

export const ENDPOINTS = {
  // Statistics
  STATISTICS: '/api/statistics',
  
  // Departments
  DEPARTMENTS: '/api/departments',
  
  // Services
  SERVICES: '/api/services',
  
  // Operators
  OPERATORS: '/api/operators',
  
  // Appointments
  APPOINTMENTS: '/api/appointments',
  APPOINTMENTS_BY_PIN: (pin: string) => `/api/appointments/pin/${pin}`,
  
  // Tickets
  TICKETS: '/api/tickets',
  TICKETS_BY_STATUS: (status: string) => `/api/tickets?status=${status}`,
  CALL_TICKET: (id: number) => `/api/tickets/${id}/call`,
  
  // Ratings
  RATINGS: '/api/ratings',
  
  // AI Chat
  AI_CHAT: '/api/ai/chat',
  AI_HISTORY: (userId: number) => `/api/ai/history/${userId}`,
  
  // Settings
  SETTINGS: '/api/settings',
  SETTING_BY_KEY: (key: string) => `/api/settings/${key}`,
} as const;

// WebSocket configuration
export const WS_CONFIG = {
  RECONNECT_ATTEMPTS: 5,
  RECONNECT_DELAY: 1000,
  PING_INTERVAL: 30000,
} as const;

// UI Constants
export const UI_CONFIG = {
  REFRESH_INTERVALS: {
    ACTIVE_TICKETS: 5000,
    DISPLAY: 2000,
    STATISTICS: 10000,
  },
  
  COLORS: {
    PRIMARY: '#1976D2',
    SUCCESS: '#4CAF50',
    WARNING: '#FF9800',
    ERROR: '#F44336',
    ACCENT: '#00BCD4',
    SECONDARY: '#424242',
  },
  
  TICKET_STATUSES: {
    WAITING: 'waiting',
    CALLED: 'called',
    SERVING: 'serving',
    COMPLETED: 'completed',
    MISSED: 'missed',
  },
  
  APPOINTMENT_STATUSES: {
    SCHEDULED: 'scheduled',
    CONFIRMED: 'confirmed',
    COMPLETED: 'completed',
    CANCELLED: 'cancelled',
    NO_SHOW: 'no_show',
  },
  
  USER_ROLES: {
    OPERATOR: 'operator',
    ADMIN: 'admin',
    SUPERVISOR: 'supervisor',
  },
} as const;

// Sound types
export const SOUND_TYPES = {
  CALL: 'call',
  NOTIFICATION: 'notification',
  SUCCESS: 'success',
  ERROR: 'error',
  ANNOUNCEMENT: 'announcement',
} as const;

// WebSocket message types
export const WS_MESSAGE_TYPES = {
  REGISTER: 'register',
  PING: 'ping',
  PONG: 'pong',
  CONNECTED: 'connected',
  REGISTERED: 'registered',
  TICKET_CREATED: 'ticket_created',
  TICKET_CALLED: 'ticket_called',
  TICKET_COMPLETED: 'ticket_completed',
  QUEUE_UPDATE: 'queue_update',
  OPERATOR_UPDATE: 'operator_update',
  ERROR: 'error',
} as const;

// Client types for WebSocket
export const CLIENT_TYPES = {
  DASHBOARD: 'dashboard',
  TERMINAL: 'terminal',
  OPERATOR: 'operator',
  DISPLAY: 'display',
  ADMIN: 'admin',
} as const;

// Validation rules
export const VALIDATION = {
  PIN_CODE_PATTERN: /^[A-Z]{2}-\d{4}$/,
  PHONE_PATTERN: /^\+7\s?\(\d{3}\)\s?\d{3}-\d{2}-\d{2}$/,
  EMAIL_PATTERN: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  
  MIN_NAME_LENGTH: 2,
  MAX_NAME_LENGTH: 255,
  MIN_PHONE_LENGTH: 10,
  MAX_PHONE_LENGTH: 20,
  
  PIN_CODE_LENGTH: 7,
  TICKET_NUMBER_LENGTH: 4,
} as const;

// Time formats
export const TIME_FORMATS = {
  DISPLAY_TIME: 'HH:mm:ss',
  DISPLAY_DATE: 'dd MMMM yyyy',
  FORM_DATE: 'yyyy-MM-dd',
  FORM_TIME: 'HH:mm',
  API_DATETIME: "yyyy-MM-dd'T'HH:mm:ss.SSSxxx",
} as const;

// Default values
export const DEFAULTS = {
  ESTIMATED_TIME: 15, // minutes
  MAX_DAILY_APPOINTMENTS: 50,
  QUEUE_REFRESH_INTERVAL: 5000,
  AI_TEMPERATURE: 0.7,
  WORKING_HOURS: {
    START: '09:00',
    END: '18:00',
  },
} as const;

// Error messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Ошибка сети. Проверьте подключение к интернету.',
  SERVER_ERROR: 'Ошибка сервера. Попробуйте позже.',
  VALIDATION_ERROR: 'Проверьте правильность заполнения полей.',
  UNAUTHORIZED: 'Недостаточно прав для выполнения операции.',
  NOT_FOUND: 'Запрашиваемый ресурс не найден.',
  WEBSOCKET_ERROR: 'Ошибка соединения с сервером.',
  AI_ERROR: 'ИИ-помощник временно недоступен.',
} as const;

// Success messages
export const SUCCESS_MESSAGES = {
  APPOINTMENT_CREATED: 'Запись успешно создана',
  TICKET_CREATED: 'Талон успешно выдан',
  TICKET_CALLED: 'Клиент вызван',
  SERVICE_COMPLETED: 'Обслуживание завершено',
  SETTINGS_SAVED: 'Настройки сохранены',
  DATA_EXPORTED: 'Данные экспортированы',
} as const;
