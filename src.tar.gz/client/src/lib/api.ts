import { apiRequest } from './queryClient';
import { ENDPOINTS } from './constants';

// Statistics API
export const statisticsApi = {
  getStatistics: () => apiRequest('GET', ENDPOINTS.STATISTICS),
};

// Departments API
export const departmentsApi = {
  getDepartments: () => apiRequest('GET', ENDPOINTS.DEPARTMENTS),
  createDepartment: (data: any) => apiRequest('POST', ENDPOINTS.DEPARTMENTS, data),
  updateDepartment: (id: number, data: any) => apiRequest('PUT', `${ENDPOINTS.DEPARTMENTS}/${id}`, data),
  deleteDepartment: (id: number) => apiRequest('DELETE', `${ENDPOINTS.DEPARTMENTS}/${id}`),
};

// Services API
export const servicesApi = {
  getServices: (departmentId?: number) => {
    const url = departmentId 
      ? `${ENDPOINTS.SERVICES}?departmentId=${departmentId}`
      : ENDPOINTS.SERVICES;
    return apiRequest('GET', url);
  },
  createService: (data: any) => apiRequest('POST', ENDPOINTS.SERVICES, data),
  updateService: (id: number, data: any) => apiRequest('PUT', `${ENDPOINTS.SERVICES}/${id}`, data),
  deleteService: (id: number) => apiRequest('DELETE', `${ENDPOINTS.SERVICES}/${id}`),
};

// Operators API
export const operatorsApi = {
  getOperators: () => apiRequest('GET', ENDPOINTS.OPERATORS),
  getOperator: (id: number) => apiRequest('GET', `${ENDPOINTS.OPERATORS}/${id}`),
  createOperator: (data: any) => apiRequest('POST', ENDPOINTS.OPERATORS, data),
  updateOperator: (id: number, data: any) => apiRequest('PUT', `${ENDPOINTS.OPERATORS}/${id}`, data),
  deleteOperator: (id: number) => apiRequest('DELETE', `${ENDPOINTS.OPERATORS}/${id}`),
};

// Appointments API
export const appointmentsApi = {
  getAppointments: (date?: string) => {
    const url = date 
      ? `${ENDPOINTS.APPOINTMENTS}?date=${date}`
      : ENDPOINTS.APPOINTMENTS;
    return apiRequest('GET', url);
  },
  getAppointmentByPin: (pin: string) => apiRequest('GET', ENDPOINTS.APPOINTMENTS_BY_PIN(pin)),
  createAppointment: (data: any) => apiRequest('POST', ENDPOINTS.APPOINTMENTS, data),
  updateAppointment: (id: number, data: any) => apiRequest('PUT', `${ENDPOINTS.APPOINTMENTS}/${id}`, data),
  cancelAppointment: (id: number) => apiRequest('DELETE', `${ENDPOINTS.APPOINTMENTS}/${id}`),
};

// Tickets API
export const ticketsApi = {
  getTickets: (status?: string) => {
    if (status) {
      return apiRequest('GET', ENDPOINTS.TICKETS_BY_STATUS(status));
    }
    return apiRequest('GET', ENDPOINTS.TICKETS);
  },
  getActiveTickets: () => apiRequest('GET', `${ENDPOINTS.TICKETS}?status=active`),
  createTicket: (data: any) => apiRequest('POST', ENDPOINTS.TICKETS, data),
  updateTicket: (id: number, data: any) => apiRequest('PUT', `${ENDPOINTS.TICKETS}/${id}`, data),
  callTicket: (id: number, operatorId: number, callType: string = 'first_call') => 
    apiRequest('POST', ENDPOINTS.CALL_TICKET(id), { operatorId, callType }),
};

// Ratings API
export const ratingsApi = {
  createRating: (data: any) => apiRequest('POST', ENDPOINTS.RATINGS, data),
  getRatingsByOperator: (operatorId: number) => 
    apiRequest('GET', `${ENDPOINTS.RATINGS}?operatorId=${operatorId}`),
};

// AI Chat API
export const aiApi = {
  sendMessage: (query: string, userId: number, userType: string = 'admin') => 
    apiRequest('POST', ENDPOINTS.AI_CHAT, { query, userId, userType }),
  getChatHistory: (userId: number, limit?: number) => {
    const url = limit 
      ? `${ENDPOINTS.AI_HISTORY(userId)}?limit=${limit}`
      : ENDPOINTS.AI_HISTORY(userId);
    return apiRequest('GET', url);
  },
};

// Settings API
export const settingsApi = {
  getSettings: () => apiRequest('GET', ENDPOINTS.SETTINGS),
  getSetting: (key: string) => apiRequest('GET', ENDPOINTS.SETTING_BY_KEY(key)),
  setSetting: (key: string, value: string, description?: string) => 
    apiRequest('POST', ENDPOINTS.SETTINGS, { key, value, description }),
};

// Utility functions for common operations
export const queueOperations = {
  // Get queue summary
  getQueueSummary: async () => {
    const [activeTickets, statistics] = await Promise.all([
      ticketsApi.getActiveTickets(),
      statisticsApi.getStatistics(),
    ]);
    
    return {
      activeTickets: await activeTickets.json(),
      statistics: await statistics.json(),
    };
  },

  // Call next ticket in queue
  callNextTicket: async (operatorId: number) => {
    const activeTickets = await ticketsApi.getActiveTickets();
    const tickets = await activeTickets.json();
    
    const waitingTickets = tickets.filter((t: any) => t.status === 'waiting');
    if (waitingTickets.length === 0) {
      throw new Error('Нет ожидающих клиентов');
    }
    
    const nextTicket = waitingTickets[0];
    return ticketsApi.callTicket(nextTicket.id, operatorId);
  },

  // Complete service
  completeService: async (ticketId: number, rating?: number, comment?: string) => {
    await ticketsApi.updateTicket(ticketId, { 
      status: 'completed',
      completedAt: new Date().toISOString()
    });
    
    if (rating) {
      await ratingsApi.createRating({
        ticketId,
        rating,
        comment: comment || '',
      });
    }
  },
};

// Export helper for creating typed API calls
export const createApiCall = <T = any>(
  method: string,
  endpoint: string,
  options?: {
    params?: Record<string, string | number>;
    data?: any;
  }
) => {
  return async (): Promise<T> => {
    let url = endpoint;
    
    if (options?.params) {
      const searchParams = new URLSearchParams();
      Object.entries(options.params).forEach(([key, value]) => {
        searchParams.append(key, value.toString());
      });
      url += `?${searchParams.toString()}`;
    }
    
    const response = await apiRequest(method, url, options?.data);
    return response.json();
  };
};

// Export all APIs
export const api = {
  statistics: statisticsApi,
  departments: departmentsApi,
  services: servicesApi,
  operators: operatorsApi,
  appointments: appointmentsApi,
  tickets: ticketsApi,
  ratings: ratingsApi,
  ai: aiApi,
  settings: settingsApi,
  queue: queueOperations,
};

export default api;
