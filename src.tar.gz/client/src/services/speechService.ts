interface VoiceSettings {
  lang: string;
  rate: number;
  pitch: number;
  volume: number;
  voiceName?: string;
  engine: 'rhvoice' | 'browser';
  rhvoiceVoice: string;
}

class SpeechService {
  private synthesis: SpeechSynthesis;
  private isEnabled: boolean = true;
  private rhvoiceUrl: string = '/api/rhvoice';
  private defaultSettings: VoiceSettings = {
    lang: 'ru-RU',
    rate: 0.9,
    pitch: 1.1,
    volume: 0.8,
    engine: 'rhvoice',
    rhvoiceVoice: 'elena'
  };

  constructor() {
    this.synthesis = window.speechSynthesis;
  }

  // Получение списка доступных голосов
  getVoices(): SpeechSynthesisVoice[] {
    return this.synthesis.getVoices();
  }

  // Поиск лучшего женского русского голоса
  getBestRussianFemaleVoice(): SpeechSynthesisVoice | null {
    const voices = this.getVoices();
    
    // Приоритетные женские голоса для русского языка
    const preferredVoices = [
      'Microsoft Irina Desktop - Russian',
      'Google русский',
      'Yandex Алиса',
      'Microsoft Irina',
      'ru-RU-SvetlanaNeural',
      'ru-RU-DariyaNeural'
    ];

    // Ищем среди предпочтительных
    for (const preferred of preferredVoices) {
      const voice = voices.find(v => 
        v.name.includes(preferred) || 
        v.name.toLowerCase().includes(preferred.toLowerCase())
      );
      if (voice) return voice;
    }

    // Ищем любой русский женский голос
    const russianFemaleVoice = voices.find(voice => 
      voice.lang.startsWith('ru') && 
      (voice.name.toLowerCase().includes('female') || 
       voice.name.toLowerCase().includes('женский') ||
       voice.name.toLowerCase().includes('ирина') ||
       voice.name.toLowerCase().includes('светлана') ||
       voice.name.toLowerCase().includes('алиса'))
    );

    if (russianFemaleVoice) return russianFemaleVoice;

    // Ищем любой русский голос
    const russianVoice = voices.find(voice => voice.lang.startsWith('ru'));
    return russianVoice || null;
  }

  // Основная функция для объявления талона
  announceTicket(ticketNumber: string, operatorName: string, windowNumber?: number): Promise<void> {
    if (!this.isEnabled) {
      return Promise.resolve();
    }

    // Формируем текст объявления в правильном формате
    let message = `Посетитель с номером талона ${this.formatTicketNumber(ticketNumber)}`;
    
    if (windowNumber) {
      message += ` пройдите к оператору номер ${windowNumber}`;
    } else {
      message += ` пройдите к оператору ${operatorName}`;
    }

    // Используем RHVoice или браузерный движок
    if (this.defaultSettings.engine === 'rhvoice') {
      return this.speakWithRHVoice(message);
    } else {
      return this.speakWithBrowser(message);
    }
  }

  // Синтез речи через RHVoice
  private async speakWithRHVoice(text: string): Promise<void> {
    try {
      const response = await fetch(this.rhvoiceUrl + '/say', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: text,
          voice: this.defaultSettings.rhvoiceVoice,
          format: 'wav',
          rate: Math.round(this.defaultSettings.rate * 100),
          pitch: Math.round(this.defaultSettings.pitch * 100),
          volume: Math.round(this.defaultSettings.volume * 100)
        })
      });

      if (!response.ok) {
        throw new Error('RHVoice service unavailable');
      }

      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      
      return new Promise((resolve, reject) => {
        audio.onended = () => {
          URL.revokeObjectURL(audioUrl);
          resolve();
        };
        audio.onerror = () => {
          URL.revokeObjectURL(audioUrl);
          reject(new Error('Audio playback failed'));
        };
        
        audio.volume = this.defaultSettings.volume;
        audio.play();
      });
    } catch (error) {
      console.warn('RHVoice не доступен, переключаюсь на браузерный синтез:', error);
      // Fallback на браузерный синтез речи
      return this.speakWithBrowser(text);
    }
  }

  // Браузерный синтез речи (fallback)
  private speakWithBrowser(text: string): Promise<void> {
    if (!('speechSynthesis' in window)) {
      return Promise.resolve();
    }

    return new Promise((resolve, reject) => {
      // Останавливаем предыдущие объявления
      this.synthesis.cancel();

      const voice = this.getBestRussianFemaleVoice();
      const utterance = new SpeechSynthesisUtterance(text);
      
      // Настройки голоса
      utterance.lang = this.defaultSettings.lang;
      utterance.rate = this.defaultSettings.rate;
      utterance.pitch = this.defaultSettings.pitch;
      utterance.volume = this.defaultSettings.volume;
      
      if (voice) {
        utterance.voice = voice;
      }

      // Обработчики событий
      utterance.onend = () => resolve();
      utterance.onerror = (event) => reject(event);

      // Воспроизводим
      this.synthesis.speak(utterance);
    });
  }

  // Форматирование номера талона для лучшего произношения
  private formatTicketNumber(ticketNumber: string): string {
    // P2-01 -> "пэ два, ноль один"
    return ticketNumber.replace(/([A-Z])(\d+)-(\d+)/, (match, letter, service, number) => {
      const letterName = this.getLetterName(letter);
      const serviceNum = this.formatNumber(service);
      const ticketNum = this.formatNumberWithZeros(number);
      return `${letterName} ${serviceNum}, ${ticketNum}`;
    });
  }

  // Произношение букв
  private getLetterName(letter: string): string {
    const letterNames: { [key: string]: string } = {
      'A': 'а',
      'B': 'бэ', 
      'C': 'цэ',
      'D': 'дэ',
      'E': 'е',
      'F': 'эф',
      'G': 'гэ',
      'H': 'аш',
      'I': 'и',
      'J': 'жи',
      'K': 'ка',
      'L': 'эл',
      'M': 'эм',
      'N': 'эн',
      'O': 'о',
      'P': 'пэ',
      'Q': 'ку',
      'R': 'эр',
      'S': 'эс',
      'T': 'тэ',
      'U': 'у',
      'V': 'вэ',
      'W': 'дубль вэ',
      'X': 'икс',
      'Y': 'игрек',
      'Z': 'зэт'
    };
    return letterNames[letter] || letter.toLowerCase();
  }

  // Форматирование чисел
  private formatNumber(num: string): string {
    const numbers: { [key: string]: string } = {
      '0': 'ноль', '1': 'один', '2': 'два', '3': 'три', '4': 'четыре',
      '5': 'пять', '6': 'шесть', '7': 'семь', '8': 'восемь', '9': 'девять',
      '10': 'десять', '11': 'одиннадцать', '12': 'двенадцать'
    };
    return numbers[num] || num;
  }

  // Форматирование номера с нулями (например 01 -> "ноль один")
  private formatNumberWithZeros(num: string): string {
    return num.split('').map(digit => this.formatNumber(digit)).join(' ');
  }

  // Получить доступные голоса RHVoice
  async getRHVoiceVoices(): Promise<string[]> {
    try {
      const response = await fetch(this.rhvoiceUrl + '/voices');
      if (!response.ok) return ['elena', 'irina', 'milena', 'arina'];
      const voices = await response.json();
      return Array.isArray(voices) ? voices : ['elena', 'irina', 'milena', 'arina'];
    } catch (error) {
      console.warn('RHVoice voices not available:', error);
      return ['elena', 'irina', 'milena', 'arina']; // Fallback список
    }
  }

  // Тестовое объявление
  testAnnouncement(): Promise<void> {
    return this.announceTicket('A123', 'Мария Петровна', 1);
  }

  // Объявление общих сообщений
  announceMessage(message: string): Promise<void> {
    if (!this.isEnabled) {
      return Promise.resolve();
    }

    // Используем RHVoice или браузерный движок
    if (this.defaultSettings.engine === 'rhvoice') {
      return this.speakWithRHVoice(message);
    } else {
      return this.speakWithBrowser(message);
    }
  }

  // Включение/выключение голосовых объявлений
  setEnabled(enabled: boolean): void {
    this.isEnabled = enabled;
    if (!enabled) {
      this.synthesis.cancel();
      // Останавливаем все аудио элементы
      document.querySelectorAll('audio').forEach(audio => {
        audio.pause();
        audio.currentTime = 0;
      });
    }
  }

  // Установка движка синтеза
  setEngine(engine: 'rhvoice' | 'browser'): void {
    this.defaultSettings.engine = engine;
  }

  // Установка голоса RHVoice
  setRHVoiceVoice(voice: string): void {
    this.defaultSettings.rhvoiceVoice = voice;
  }

  // Обновление настроек голоса
  updateSettings(settings: Partial<VoiceSettings>): void {
    this.defaultSettings = { ...this.defaultSettings, ...settings };
  }

  // Проверка поддержки
  isSupported(): boolean {
    return 'speechSynthesis' in window;
  }

  // Проверка доступности RHVoice
  async isRHVoiceAvailable(): Promise<boolean> {
    try {
      const response = await fetch(this.rhvoiceUrl + '/health', { 
        method: 'GET',
        signal: AbortSignal.timeout(3000)
      });
      if (!response.ok) return false;
      const data = await response.json();
      return data.status === 'healthy';
    } catch (error) {
      console.warn('RHVoice не доступен:', error);
      return false;
    }
  }

  // Получение текущих настроек
  getSettings(): VoiceSettings {
    return { ...this.defaultSettings };
  }
}

export const speechService = new SpeechService();
export type { VoiceSettings };