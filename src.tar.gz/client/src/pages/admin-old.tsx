import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Navigation from "@/components/layout/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Users, Building2, Settings, HelpCircle, UserPlus, Plus,
  Edit, Trash2, Monitor, Palette, Clock, Volume2, Printer,
  MessageSquare, Send, Bot, Tv, CheckSquare, Square,
  Save, Wifi, Zap, Loader2, BarChart3, UserCircle,
  Bell, Download, CheckCircle, AlertTriangle, Calendar, Eye, User, Timer,
  Upload, FileDown, FileUp, Mail, Database, Cpu, Globe, Trash,
  RefreshCw, Activity, MessageCircle, History, TrendingUp,
  ToggleLeft, ToggleRight, UserCheck, Ticket, AlertCircle, Search,
  Home, CalendarPlus
} from "lucide-react";
import { VoiceSettingsEnhanced } from "@/components/ui/voice-settings-enhanced";
import { DisplayBoardSettings } from "@/components/ui/display-board-settings";

// Security Settings Component
function SecuritySettingsComponent() {
  const { toast } = useToast();
  
  const { data: securitySettings, isLoading } = useQuery({
    queryKey: ['/api/security-settings'],
  });

  const updateSecurityMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('PUT', '/api/security-settings', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Настройки безопасности обновлены",
        description: "Изменения применены успешно",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/security-settings'] });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить настройки безопасности",
        variant: "destructive",
      });
    },
  });

  const handleSecurityToggle = (enabled: boolean) => {
    updateSecurityMutation.mutate({
      externalAccessRestricted: enabled,
      allowedExternalPaths: ['/booking'],
      internalNetworkRanges: ['192.168.0.0/16', '10.0.0.0/8', '172.16.0.0/12', '127.0.0.1'],
      updatedBy: 'admin'
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Загрузка настроек безопасности...</span>
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5 text-orange-500" />
          Контроль доступа к системе
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between p-4 border rounded-lg">
          <div className="space-y-1">
            <h3 className="font-medium">Ограничить внешний доступ</h3>
            <p className="text-sm text-gray-600">
              Разрешить внешним пользователям доступ только к странице веб-записи
            </p>
          </div>
          <Switch
            checked={securitySettings?.externalAccessRestricted || false}
            onCheckedChange={handleSecurityToggle}
            disabled={updateSecurityMutation.isPending}
            data-testid="switch-security-restriction"
          />
        </div>

        <div className="p-4 bg-gray-50 rounded-lg space-y-3">
          <h4 className="font-medium text-gray-900">Текущие настройки:</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Статус:</span>
              <Badge 
                className={`ml-2 ${securitySettings?.externalAccessRestricted ? 'bg-red-500 text-white' : 'bg-green-500 text-white'}`}
              >
                {securitySettings?.externalAccessRestricted ? 'Ограничен' : 'Открыт'}
              </Badge>
            </div>
            <div>
              <span className="font-medium">Разрешенные пути:</span>
              <span className="ml-2 text-gray-600">/booking</span>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h4 className="font-medium">Как это работает:</h4>
          <div className="space-y-2 text-sm text-gray-600">
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
              <span><strong>Внутренняя сеть:</strong> Полный доступ ко всем страницам системы</span>
            </div>
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-orange-500 mt-0.5" />
              <span><strong>Внешние IP:</strong> {securitySettings?.externalAccessRestricted ? 'Доступ только к веб-записи' : 'Полный доступ ко всем страницам'}</span>
            </div>
            <div className="flex items-start gap-2">
              <Globe className="h-4 w-4 text-blue-500 mt-0.5" />
              <span><strong>Автоопределение:</strong> Система автоматически определяет внутренние и внешние IP</span>
            </div>
          </div>
        </div>

        {updateSecurityMutation.isPending && (
          <div className="flex items-center gap-2 text-blue-600">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span className="text-sm">Применение настроек...</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Operator Status Overview Component
function OperatorStatusOverview() {
  const { data: operators } = useQuery({
    queryKey: ['/api/operators'],
    refetchInterval: 10000,
  });

  const { data: operatorStatuses } = useQuery({
    queryKey: ['/api/operator-status'],
    refetchInterval: 10000,
  });

  const [selectedOperators, setSelectedOperators] = useState<any[]>([]);
  const [showDetails, setShowDetails] = useState(false);
  const [detailType, setDetailType] = useState<'online' | 'offline' | 'break'>('online');

  if (!operators || !operatorStatuses) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Загрузка статуса операторов...</span>
      </div>
    );
  }

  const onlineOperators = (operators as any)?.filter((op: any) => {
    const status = (operatorStatuses as any)?.find((s: any) => s.operatorId === op.id);
    return status && (status.status === 'available' || status.status === 'busy') && op.isActive;
  }) || [];

  const offlineOperators = (operators as any)?.filter((op: any) => {
    const status = (operatorStatuses as any)?.find((s: any) => s.operatorId === op.id);
    return (!status || status.status === 'offline') && op.isActive;
  }) || [];

  const breakOperators = (operators as any)?.filter((op: any) => {
    const status = (operatorStatuses as any)?.find((s: any) => s.operatorId === op.id);
    return status && status.status === 'break' && op.isActive;
  }) || [];

  const handleShowDetails = (type: 'online' | 'offline' | 'break') => {
    setDetailType(type);
    switch(type) {
      case 'online':
        setSelectedOperators(onlineOperators);
        break;
      case 'offline':
        setSelectedOperators(offlineOperators);
        break;
      case 'break':
        setSelectedOperators(breakOperators);
        break;
    }
    setShowDetails(true);
  };

  return (
    <>
      <div className="grid grid-cols-3 gap-4 mb-6">
        <Button 
          variant="outline" 
          className="p-4 h-auto flex flex-col items-center gap-2 hover:bg-green-50"
          onClick={() => handleShowDetails('online')}
          data-testid="button-online-operators"
        >
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="font-semibold text-lg">{onlineOperators.length}</span>
          </div>
          <span className="text-xs text-gray-600">В сети</span>
        </Button>
        
        <Button 
          variant="outline" 
          className="p-4 h-auto flex flex-col items-center gap-2 hover:bg-red-50"
          onClick={() => handleShowDetails('offline')}
          data-testid="button-offline-operators"
        >
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span className="font-semibold text-lg">{offlineOperators.length}</span>
          </div>
          <span className="text-xs text-gray-600">Не в сети</span>
        </Button>
        
        <Button 
          variant="outline" 
          className="p-4 h-auto flex flex-col items-center gap-2 hover:bg-yellow-50"
          onClick={() => handleShowDetails('break')}
          data-testid="button-break-operators"
        >
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <span className="font-semibold text-lg">{breakOperators.length}</span>
          </div>
          <span className="text-xs text-gray-600">На перерыве</span>
        </Button>
      </div>
      
      {/* Quick operators list */}
      <div className="space-y-2">
        {onlineOperators.slice(0, 3).map((operator: any) => {
          const status = operatorStatuses.find((s: any) => s.operatorId === operator.id);
          return (
            <div key={operator.id} className="flex items-center justify-between p-2 bg-green-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="font-medium">{operator.firstName} {operator.lastName}</span>
                <Badge variant="secondary">Окно {operator.windowNumber}</Badge>
              </div>
              <Badge variant={status?.status === 'busy' ? 'default' : 'outline'}>
                {status?.status === 'busy' ? 'Занят' : 'Доступен'}
              </Badge>
            </div>
          );
        })}
        
        {onlineOperators.length > 3 && (
          <div className="text-center text-sm text-gray-500">
            и ещё {onlineOperators.length - 3} операторов...
          </div>
        )}
      </div>

      {/* Details Dialog */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {detailType === 'online' && 'Операторы в сети'}
              {detailType === 'offline' && 'Операторы не в сети'}
              {detailType === 'break' && 'Операторы на перерыве'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {selectedOperators.map((operator: any) => {
              const status = operatorStatuses.find((s: any) => s.operatorId === operator.id);
              return (
                <div key={operator.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarFallback>
                        {operator.firstName.charAt(0)}{operator.lastName.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{operator.firstName} {operator.lastName}</p>
                      <p className="text-sm text-gray-600">@{operator.username}</p>
                      {operator.email && (
                        <p className="text-xs text-gray-500">{operator.email}</p>
                      )}
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary">Окно {operator.windowNumber}</Badge>
                        {status?.breakReason && (
                          <Badge variant="outline">{status.breakReason}</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="flex items-center gap-2 mb-1">
                      <div className={`w-2 h-2 rounded-full ${
                        detailType === 'online' ? 'bg-green-500' :
                        detailType === 'offline' ? 'bg-red-500' : 'bg-yellow-500'
                      }`}></div>
                      <span className="text-sm font-medium">
                        {detailType === 'online' && (status?.status === 'busy' ? 'Занят' : 'Доступен')}
                        {detailType === 'offline' && 'Не в сети'}
                        {detailType === 'break' && 'На перерыве'}
                      </span>
                    </div>
                    {status?.lastActivity && (
                      <p className="text-xs text-gray-500">
                        Активность: {new Date(status.lastActivity).toLocaleString('ru-RU')}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Quick Stats Today Component
function QuickStatsToday() {
  const { data: stats } = useQuery({
    queryKey: ['/api/statistics'],
    refetchInterval: 30000,
  });

  if (!stats) {
    return (
      <div className="flex items-center justify-center py-4">
        <Loader2 className="h-4 w-4 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">В очереди</span>
        <span className="font-semibold">{stats.activeQueue || 0}</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">Обслужено</span>
        <span className="font-semibold text-green-600">{stats.completedToday || 0}</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">Среднее время</span>
        <span className="font-semibold">{stats.averageWaitTime || 0} мин</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">Записи</span>
        <span className="font-semibold text-blue-600">{stats.appointmentsToday || 0}</span>
      </div>
    </div>
  );
}

// System Status Component  
function SystemStatus() {
  const { data: aiSettings } = useQuery({
    queryKey: ['/api/ai-settings'],
  });

  const { data: voiceSettings } = useQuery({
    queryKey: ['/api/voice-settings'],
  });

  const { data: displayBoards } = useQuery({
    queryKey: ['/api/display-boards'],
  });

  const aiActive = Array.isArray(aiSettings) ? aiSettings.some((setting: any) => setting.isActive) : false;
  const voiceActive = voiceSettings && typeof voiceSettings === 'object' && !Array.isArray(voiceSettings) ? 
    (voiceSettings as any).engine !== null && (voiceSettings as any).engine !== '' : false;
  const displaysActive = displayBoards?.length > 0 || false;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">ИИ Помощник</span>
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${aiActive ? 'bg-green-500' : 'bg-gray-300'}`}></div>
          <span className="text-sm font-medium">{aiActive ? 'Активен' : 'Отключен'}</span>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">Голосовые объявления</span>
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${voiceActive ? 'bg-green-500' : 'bg-gray-300'}`}></div>
          <span className="text-sm font-medium">{voiceActive ? 'Активны' : 'Отключены'}</span>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">Электронные табло</span>
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${displaysActive ? 'bg-green-500' : 'bg-gray-300'}`}></div>
          <span className="text-sm font-medium">{displaysActive ? `${displayBoards?.length} шт.` : 'Не настроены'}</span>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">База данных</span>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500"></div>
          <span className="text-sm font-medium">Подключена</span>
        </div>
      </div>
    </div>
  );
}

// Validation schemas
const operatorSchema = z.object({
  firstName: z.string().min(1, "Имя обязательно").transform(s => s.trim()),
  lastName: z.string().min(1, "Фамилия обязательна").transform(s => s.trim()),
  username: z.string().min(2, "Имя пользователя обязательно (мин. 2 символа)").transform(s => s.trim()),
  email: z.string().email("Неверный формат email").optional().or(z.literal('')),
  phone: z.string().optional(),
  departmentId: z.number().min(1, "Выберите отделение"),
  windowNumber: z.number().optional(),
  role: z.string().default("operator"),
  passwordHash: z.string().min(6, "Пароль должен быть не менее 6 символов"),
  isActive: z.boolean().default(true),
});

const serviceSchema = z.object({
  name: z.string().min(1, "Название услуги обязательно"),
  description: z.string().optional(),
  estimatedTime: z.number().min(1, "Время обслуживания обязательно"),
  departmentId: z.number().min(1, "Выберите отделение"),
  serviceCode: z.string().min(1, "Код услуги обязателен"),
  isActive: z.boolean().default(true),
});

const departmentSchema = z.object({
  name: z.string().min(1, "Название отделения обязательно"),
  address: z.string().optional(),
  phone: z.string().optional(),
  workingHours: z.any().optional(),
  isActive: z.boolean().default(true),
});

const terminalSettingsSchema = z.object({
  theme: z.string().default("classic"),
  displayTimeSeconds: z.number().min(1).max(60).default(5),
  organizationName: z.string().min(1, "Название организации обязательно"),
  backgroundColor: z.string().regex(/^#[0-9A-F]{6}$/i, "Неверный формат цвета"),
  textColor: z.string().regex(/^#[0-9A-F]{6}$/i, "Неверный формат цвета"),
  accentColor: z.string().regex(/^#[0-9A-F]{6}$/i, "Неверный формат цвета"),
  showWaitingTime: z.boolean().default(true),
  showQueuePosition: z.boolean().default(true),
  enableSound: z.boolean().default(true),
  ticketTemplate: z.string().optional(),
});

const aiSettingsSchema = z.object({
  settingName: z.string().min(1, "Имя подключения обязательно"),
  providerType: z.enum(["ollama", "openai", "anthropic", "gemini", "huggingface"]),
  modelName: z.string().min(1, "Название модели обязательно"),
  apiUrl: z.string().optional(),
  apiKey: z.string().optional(),
  temperature: z.number().min(0).max(100).default(70),
  context: z.string().optional(),
  module: z.string().optional(),
  isActive: z.boolean().default(true),
  isOnline: z.boolean().default(false)
});

const emailSettingsSchema = z.object({
  smtpHost: z.string().min(1, "SMTP сервер обязателен"),
  smtpPort: z.number().min(1).max(65535),
  smtpUser: z.string().min(1, "Пользователь SMTP обязателен"),
  smtpPassword: z.string().min(1, "Пароль SMTP обязателен"),
  fromEmail: z.string().email("Неверный формат email"),
  fromName: z.string().min(1, "Имя отправителя обязательно"),
  adminEmail: z.string().email("Неверный формат email"),
  enableDailyReports: z.boolean().default(true),
  reportTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Формат времени HH:MM"),
  useTLS: z.boolean().default(true)
});

const ticketSettingsSchema = z.object({
  ticketNumberLength: z.number().min(1).max(8).default(4),
});

// Ticket Settings Component
function TicketSettingsForm() {
  const { toast } = useToast();
  
  // Fetch current settings
  const { data: ticketSettings, isLoading } = useQuery({
    queryKey: ['/api/ticket-settings'],
    queryFn: async () => {
      const response = await fetch('/api/ticket-settings');
      if (!response.ok) throw new Error('Failed to fetch');
      return response.json();
    },
  });

  const form = useForm<z.infer<typeof ticketSettingsSchema>>({
    resolver: zodResolver(ticketSettingsSchema),
    defaultValues: {
      ticketNumberLength: 4,
    },
  });

  // Update form when data loads
  React.useEffect(() => {
    if (ticketSettings) {
      form.reset({
        ticketNumberLength: ticketSettings.ticketNumberLength || 4,
      });
    }
  }, [ticketSettings, form]);

  const mutation = useMutation({
    mutationFn: async (values: z.infer<typeof ticketSettingsSchema>) => {
      const response = await fetch('/api/ticket-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
      });
      if (!response.ok) throw new Error('Failed to save');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Настройки талонов сохранены",
        description: "Длина номера талона успешно обновлена",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ticket-settings'] });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить настройки талонов",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: z.infer<typeof ticketSettingsSchema>) => {
    mutation.mutate(values);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin" />
            <span className="ml-2">Загрузка настроек...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Ticket className="h-5 w-5 text-blue-500" />
          Настройки талонов
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="max-w-md space-y-4">
              <FormField
                control={form.control}
                name="ticketNumberLength"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Длина номера талона</FormLabel>
                    <Select 
                      onValueChange={(value) => field.onChange(parseInt(value))}
                      value={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-ticket-length">
                          <SelectValue placeholder="Выберите длину" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="1">1 цифра (A1, B2, C3)</SelectItem>
                        <SelectItem value="2">2 цифры (A01, B02, C03)</SelectItem>
                        <SelectItem value="3">3 цифры (A001, B002, C003)</SelectItem>
                        <SelectItem value="4">4 цифры (A0001, B0002, C0003)</SelectItem>
                        <SelectItem value="5">5 цифр (A00001, B00002, C00003)</SelectItem>
                        <SelectItem value="6">6 цифр (A000001, B000002, C000003)</SelectItem>
                        <SelectItem value="7">7 цифр (A0000001, B0000002, C0000003)</SelectItem>
                        <SelectItem value="8">8 цифр (A00000001, B00000002, C00000003)</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="text-sm text-gray-600">
                      Количество цифр после кода услуги. По умолчанию 4 цифры.
                      Общая длина талона = код услуги + цифры.
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Примеры форматов:</h4>
                <div className="space-y-1 text-sm text-blue-800">
                  <div>• Услуга с кодом "A": A0001, A0002, A0003...</div>
                  <div>• Услуга с кодом "C": C0001, C0002, C0003...</div>
                  <div>• При длине 2 цифры: A01, B02, C03</div>
                  <div>• При длине 6 цифр: A000001, B000002, C000003</div>
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <Button 
                type="submit" 
                className="bg-blue-500 hover:bg-blue-600"
                disabled={mutation.isPending}
                data-testid="button-save-ticket-settings"
              >
                {mutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Сохранение...
                  </>
                ) : (
                  'Сохранить настройки'
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

export default function Admin() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [aiQuery, setAiQuery] = useState("");
  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const [isAiChatLoading, setIsAiChatLoading] = useState(false);
  const [selectedAiProvider, setSelectedAiProvider] = useState<string>("");
  const [showAiSettings, setShowAiSettings] = useState(false);
  const [ticketPreview, setTicketPreview] = useState<string>("");
  
  // Export/Import states
  const [exportStartDate, setExportStartDate] = useState("");
  const [exportEndDate, setExportEndDate] = useState("");
  const [exportType, setExportType] = useState("appointments");
  const [importType, setImportType] = useState("appointments");
  const [importFile, setImportFile] = useState<File | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);

  // Modal states
  const [showOperatorDialog, setShowOperatorDialog] = useState(false);
  const [showServiceDialog, setShowServiceDialog] = useState(false);
  const [showDepartmentDialog, setShowDepartmentDialog] = useState(false);
  const [showOperatorServicesDialog, setShowOperatorServicesDialog] = useState(false);
  const [showAiSettingsDialog, setShowAiSettingsDialog] = useState(false);
  const [showEmailSettingsDialog, setShowEmailSettingsDialog] = useState(false);
  const [editingOperator, setEditingOperator] = useState<any>(null);
  const [editingService, setEditingService] = useState<any>(null);
  const [editingDepartment, setEditingDepartment] = useState<any>(null);
  const [selectedOperatorForServices, setSelectedOperatorForServices] = useState<any>(null);
  const [operatorServices, setOperatorServices] = useState<number[]>([]);
  const [editingAiSetting, setEditingAiSetting] = useState<any>(null);
  
  // Operator Chat states
  const [selectedOperatorForChat, setSelectedOperatorForChat] = useState<any>(null);
  const [operatorChatMessage, setOperatorChatMessage] = useState("");
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  
  // Hall management states
  const [searchPin, setSearchPin] = useState("");
  const [searchResult, setSearchResult] = useState<any>(null);

  // Database backup states
  const [backupDescription, setBackupDescription] = useState("");
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);
  const [autoBackupEnabled, setAutoBackupEnabled] = useState(false);
  const [clearDbPin, setClearDbPin] = useState("");
  const [preventDuplicates, setPreventDuplicates] = useState(true);
  
  // Mock database backups data
  const [databaseBackups] = useState([
    {
      id: 1,
      description: "Еженедельная резервная копия",
      timestamp: "2024-01-15 09:00:00",
      size: "2.5 MB",
      tables: 8,
      records: 1250
    },
    {
      id: 2,
      description: "Копия перед обновлением",
      timestamp: "2024-01-10 14:30:00",
      size: "2.1 MB", 
      tables: 8,
      records: 1100
    }
  ]);

  // Windows shortcut creation functions
  const createWindowsShortcut = (module: string, name: string, path: string) => {
    const url = `${window.location.origin}${path}`;
    const shortcut = `[InternetShortcut]\nURL=${url}\nIconFile=%windir%\\system32\\shell32.dll\nIconIndex=14`;
    const blob = new Blob([shortcut], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${name}.url`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    toast({
      title: "Ярлык создан",
      description: `Ярлык "${name}" загружен`,
    });
  };

  const createAllWindowsShortcuts = () => {
    const shortcuts = [
      { module: 'terminal', name: 'Терминал выдачи талонов', path: '/terminal' },
      { module: 'display', name: 'Информационное табло', path: '/display' },
      { module: 'operator', name: 'Операторский интерфейс', path: '/operator' },
      { module: 'booking', name: 'Предварительная запись', path: '/booking' },
      { module: 'admin', name: 'Админ-панель', path: '/admin' }
    ];
    
    shortcuts.forEach(shortcut => {
      createWindowsShortcut(shortcut.module, shortcut.name, shortcut.path);
    });
    
    toast({
      title: "Все ярлыки созданы",
      description: "5 ярлыков успешно загружены",
    });
  };

  // Search by PIN function
  const searchByPin = () => {
    if (!searchPin.trim()) {
      toast({
        title: "Введите PIN",
        description: "Пожалуйста, введите PIN-код для поиска",
        variant: "destructive",
      });
      return;
    }
    
    const appointment = appointments.find((app: any) => app.pinCode === searchPin.trim());
    if (appointment) {
      setSearchResult(appointment);
      toast({
        title: "Запись найдена",
        description: `Найдена запись для ${appointment.clientName}`,
      });
    } else {
      setSearchResult(null);
      toast({
        title: "Запись не найдена",
        description: `Запись с PIN ${searchPin} не найдена`,
        variant: "destructive",
      });
    }
  };

  // Ticket preview generation
  const generateTicketPreview = () => {
    const template = `================================
{{organizationName}}
================================

ТАЛОН № {{ticketNumber}}

Услуга: {{serviceName}}

Дата: {{date}}
Время: {{time}}

В очереди: {{queueCount}} человек

Приблизительное время ожидания:
{{waitTime}} минут

================================
Сохраните этот талон до вызова
================================`;

    const preview = template
      .replace('{{organizationName}}', 'ЭЛЕКТРОННАЯ ОЧЕРЕДЬ')
      .replace('{{ticketNumber}}', 'P1-01')
      .replace('{{serviceName}}', 'Получение паспорта')
      .replace('{{date}}', new Date().toLocaleDateString('ru-RU'))
      .replace('{{time}}', new Date().toLocaleTimeString('ru-RU'))
      .replace('{{queueCount}}', '3')
      .replace('{{waitTime}}', '15');
    
    setTicketPreview(preview);
  };

  // Forms
  const operatorForm = useForm({
    resolver: zodResolver(operatorSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      username: "",
      email: "",
      phone: "",
      departmentId: 0,
      windowNumber: 1,
      role: "operator",
      passwordHash: "",
      isActive: true,
    },
  });

  const serviceForm = useForm({
    resolver: zodResolver(serviceSchema),
    defaultValues: {
      name: "",
      description: "",
      estimatedTime: 15,
      departmentId: 0,
      serviceCode: "",
      isActive: true,
    },
  });

  const departmentForm = useForm({
    resolver: zodResolver(departmentSchema),
    defaultValues: {
      name: "",
      address: "",
      phone: "",
      isActive: true,
    },
  });

  const emailForm = useForm({
    resolver: zodResolver(emailSettingsSchema),
    defaultValues: {
      smtpHost: "",
      smtpPort: 587,
      smtpUser: "",
      smtpPassword: "",
      fromEmail: "",
      fromName: "",
      adminEmail: "",
      enableDailyReports: true,
      reportTime: "09:00",
      useTLS: true,
    },
  });

  const terminalSettingsForm = useForm({
    resolver: zodResolver(terminalSettingsSchema),
    defaultValues: {
      theme: "classic",
      displayTimeSeconds: 5,
      organizationName: "ЭЛЕКТРОННАЯ ОЧЕРЕДЬ",
      backgroundColor: "#ffffff",
      textColor: "#000000",
      accentColor: "#0079F2",
      showWaitingTime: true,
      showQueuePosition: true,
      enableSound: true,
      ticketTemplate: "",
    },
  });

  const aiSettingsForm = useForm({
    resolver: zodResolver(aiSettingsSchema),
    defaultValues: {
      settingName: "",
      providerType: "ollama" as const,
      modelName: "",
      apiUrl: "",
      apiKey: "",
      temperature: 70,
      context: "",
      module: "",
      isActive: true,
      isOnline: false,
    },
  });

  const emailSettingsForm = useForm({
    resolver: zodResolver(emailSettingsSchema),
    defaultValues: {
      smtpHost: "",
      smtpPort: 587,
      smtpUser: "",
      smtpPassword: "",
      fromEmail: "",
      fromName: "",
      adminEmail: "",
      enableDailyReports: true,
      reportTime: "09:00",
      useTLS: true,
    },
  });

  const { data: operators = [] as any[], isLoading: operatorsLoading } = useQuery({
    queryKey: ['/api/operators'],
    select: (data) => Array.isArray(data) ? data : []
  });

  const { data: services = [] as any[], isLoading: servicesLoading } = useQuery({
    queryKey: ['/api/services'],
    select: (data) => Array.isArray(data) ? data : []
  });

  const { data: appointments = [] as any[] } = useQuery({
    queryKey: ['/api/appointments'],
    select: (data) => Array.isArray(data) ? data : []
  });

  const { data: tickets = [] as any[] } = useQuery({
    queryKey: ['/api/tickets'],
    refetchInterval: 5000,
    staleTime: 0,
    gcTime: 0,
    select: (data) => Array.isArray(data) ? data : []
  });

  const { data: departments = [] as any[], isLoading: departmentsLoading } = useQuery({
    queryKey: ['/api/departments'],
    select: (data) => Array.isArray(data) ? data : []
  });

  const { data: statistics = { activeQueue: '0', completedToday: '0', averageWaitTime: '0', appointmentsToday: '0' } as any } = useQuery({
    queryKey: ['/api/statistics'],
    select: (data) => data || { activeQueue: '0', completedToday: '0', averageWaitTime: '0', appointmentsToday: '0' }
  });

  const { data: terminalSettings, isLoading: terminalSettingsLoading } = useQuery({
    queryKey: ['/api/terminal-settings'],
  });

  const { data: aiSettings = [] as any[] } = useQuery({
    queryKey: ['/api/ai-settings'],
    select: (data) => Array.isArray(data) ? data : []
  });

  const { data: emailSettings = {} } = useQuery({
    queryKey: ['/api/email-settings'],
  });

  const { data: chatHistoryData = [] } = useQuery({
    queryKey: ['/api/ai/chat-history'],
  });

  const { data: importExportLogs = [] as any[] } = useQuery({
    queryKey: ['/api/import-export-logs'],
    select: (data) => Array.isArray(data) ? data : []
  });

  // Database backup functions
  const handleCreateBackup = async () => {
    setIsCreatingBackup(true);
    try {
      // Mock backup creation
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast({
        title: "Резервная копия создана",
        description: "База данных успешно скопирована",
      });
    } catch (error) {
      toast({
        title: "Ошибка резервного копирования",
        description: "Не удалось создать резервную копию",
        variant: "destructive",
      });
    } finally {
      setIsCreatingBackup(false);
      setBackupDescription("");
    }
  };

  const handleClearDatabase = async () => {
    if (clearDbPin !== "CLEAR123") {
      toast({
        title: "Неверный PIN",
        description: "Введите правильный PIN-код для очистки базы",
        variant: "destructive",
      });
      return;
    }

    try {
      // Mock database clearing
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: "База данных очищена",
        description: "Все данные успешно удалены",
      });
      setClearDbPin("");
    } catch (error) {
      toast({
        title: "Ошибка очистки",
        description: "Не удалось очистить базу данных",
        variant: "destructive",
      });
    }
  };

  const handleDeleteBackup = (backupId: number) => {
    toast({
      title: "Резервная копия удалена",
      description: "Копия успешно удалена с диска",
    });
  };

  // Load operator services when dialog opens
  const { data: currentOperatorServices = [] } = useQuery({
    queryKey: ['/api/operators', selectedOperatorForServices?.id, 'services'],
    enabled: !!selectedOperatorForServices?.id,
  });

  const terminalSettingsMutation = useMutation({
    mutationFn: async (settings: any) => {
      const response = await apiRequest('PUT', '/api/terminal-settings', settings);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Настройки сохранены",
        description: "Настройки терминала успешно обновлены",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/terminal-settings'] });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить настройки терминала",
        variant: "destructive",
      });
    },
  });

  const aiChatMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest('POST', '/api/ai/chat', {
        message,
        userId: 1,
        userType: 'admin',
        module: 'admin'
      });
      return response.json();
    },
    onSuccess: (data) => {
      const newMessage = {
        id: Date.now(),
        query: aiQuery,
        response: data.response,
        timestamp: new Date(),
        user: 'admin',
        processingTime: data.processingTime
      };
      setChatHistory(prev => [...prev, newMessage]);
      setAiQuery("");
      setIsAiChatLoading(false);
    },
    onError: () => {
      toast({
        title: "Ошибка ИИ",
        description: "Не удалось получить ответ от ИИ-помощника",
        variant: "destructive",
      });
      setIsAiChatLoading(false);
    },
  });

  // AI Settings mutations
  const createAiSettingMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/ai-settings', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Настройки ИИ созданы",
        description: "Новые настройки ИИ успешно добавлены",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ai-settings'] });
      setShowAiSettingsDialog(false);
      aiSettingsForm.reset();
      setEditingAiSetting(null);
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать настройки ИИ",
        variant: "destructive",
      });
    },
  });

  const updateAiSettingMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest('PUT', `/api/ai-settings/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Настройки ИИ обновлены",
        description: "Настройки ИИ успешно изменены",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ai-settings'] });
      setShowAiSettingsDialog(false);
      aiSettingsForm.reset();
      setEditingAiSetting(null);
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить настройки ИИ",
        variant: "destructive",
      });
    },
  });

  const deleteAiSettingMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/ai-settings/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Настройки ИИ удалены",
        description: "Настройки ИИ успешно удалены",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ai-settings'] });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить настройки ИИ",
        variant: "destructive",
      });
    },
  });

  // Email Settings mutation
  const updateEmailSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/email-settings', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Настройки почты сохранены",
        description: "Настройки почты успешно обновлены",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/email-settings'] });
      setShowEmailSettingsDialog(false);
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить настройки почты",
        variant: "destructive",
      });
    },
  });

  // Operator mutations
  const createOperatorMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/operators', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Оператор создан",
        description: "Новый оператор успешно добавлен",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/operators'] });
      setShowOperatorDialog(false);
      operatorForm.reset();
      setEditingOperator(null);
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать оператора",
        variant: "destructive",
      });
    },
  });

  const updateOperatorMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest('PUT', `/api/operators/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Оператор обновлен",
        description: "Данные оператора успешно изменены",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/operators'] });
      setShowOperatorDialog(false);
      operatorForm.reset();
      setEditingOperator(null);
    },
  });

  const deleteOperatorMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/operators/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Оператор удален",
        description: "Оператор успешно удален из системы",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/operators'] });
    },
  });

  // Service mutations
  const createServiceMutation = useMutation({
    mutationFn: async (data: any) => {
      console.log('Creating service with data:', data);
      const response = await apiRequest('POST', '/api/services', data);
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Service creation failed:', errorText);
        throw new Error(errorText);
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Услуга создана",
        description: "Новая услуга успешно добавлена",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      setShowServiceDialog(false);
      serviceForm.reset();
      setEditingService(null);
    },
    onError: (error: any) => {
      console.error('Service creation error:', error);
      toast({
        title: "Ошибка создания услуги",
        description: error.message || "Не удалось создать услугу",
        variant: "destructive",
      });
    },
  });

  const updateServiceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest('PUT', `/api/services/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Услуга обновлена",
        description: "Данные услуги успешно изменены",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      setShowServiceDialog(false);
      serviceForm.reset();
      setEditingService(null);
    },
  });

  const deleteServiceMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/services/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Услуга удалена",
        description: "Услуга успешно удалена из системы",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
    },
  });

  // Department mutations
  const createDepartmentMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/departments', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Отделение создано",
        description: "Новое отделение успешно добавлено",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/departments'] });
      setShowDepartmentDialog(false);
      departmentForm.reset();
      setEditingDepartment(null);
    },
  });

  const updateDepartmentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest('PUT', `/api/departments/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Отделение обновлено",
        description: "Данные отделения успешно изменены",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/departments'] });
      setShowDepartmentDialog(false);
      departmentForm.reset();
      setEditingDepartment(null);
    },
  });

  const deleteDepartmentMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/departments/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Отделение удалено",
        description: "Отделение успешно удалено из системы",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/departments'] });
    },
  });

  // Handler functions
  const handleAiSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (aiQuery.trim()) {
      aiChatMutation.mutate(aiQuery.trim());
    }
  };

  const handleOperatorSubmit = (data: any) => {
    if (editingOperator) {
      updateOperatorMutation.mutate({ id: editingOperator.id, data });
    } else {
      createOperatorMutation.mutate(data);
    }
  };

  const handleServiceSubmit = (data: any) => {
    if (editingService) {
      updateServiceMutation.mutate({ id: editingService.id, data });
    } else {
      createServiceMutation.mutate(data);
    }
  };

  const handleDepartmentSubmit = (data: any) => {
    if (editingDepartment) {
      updateDepartmentMutation.mutate({ id: editingDepartment.id, data });
    } else {
      createDepartmentMutation.mutate(data);
    }
  };

  const openOperatorDialog = (operator?: any) => {
    if (operator) {
      setEditingOperator(operator);
      operatorForm.reset({
        firstName: operator.firstName,
        lastName: operator.lastName,
        username: operator.username,
        email: operator.email || "",
        phone: operator.phone || "",
        departmentId: operator.departmentId,
        windowNumber: operator.windowNumber,
        role: operator.role,
        passwordHash: "",
        isActive: operator.isActive,
      });
    } else {
      setEditingOperator(null);
      operatorForm.reset({
        firstName: "",
        lastName: "",
        username: "",
        email: "",
        phone: "",
        departmentId: 0,
        windowNumber: 1,
        role: "operator",
        passwordHash: "",
        isActive: true,
      });
    }
    setShowOperatorDialog(true);
  };

  const openServiceDialog = (service?: any) => {
    if (service) {
      setEditingService(service);
      serviceForm.reset({
        name: service.name,
        description: service.description || "",
        estimatedTime: service.estimatedTime,
        departmentId: service.departmentId,
        serviceCode: service.serviceCode,
        isActive: service.isActive,
      });
    } else {
      setEditingService(null);
      serviceForm.reset();
    }
    setShowServiceDialog(true);
  };

  const openDepartmentDialog = (department?: any) => {
    if (department) {
      setEditingDepartment(department);
      departmentForm.reset({
        name: department.name,
        address: department.address || "",
        phone: department.phone || "",
        isActive: department.isActive,
      });
    } else {
      setEditingDepartment(null);
      departmentForm.reset();
    }
    setShowDepartmentDialog(true);
  };

  // AI Settings functions
  const openAiSettingsDialog = (aiSetting?: any) => {
    if (aiSetting) {
      setEditingAiSetting(aiSetting);
      aiSettingsForm.reset({
        settingName: aiSetting.settingName,
        providerType: aiSetting.providerType,
        modelName: aiSetting.modelName,
        apiUrl: aiSetting.apiUrl || "",
        apiKey: aiSetting.apiKey || "",
        temperature: aiSetting.temperature,
        context: aiSetting.context || "",
        module: aiSetting.module || "",
        isActive: aiSetting.isActive,
        isOnline: aiSetting.isOnline,
      });
    } else {
      setEditingAiSetting(null);
      // Предзаполненные данные для нового подключения
      aiSettingsForm.reset({
        settingName: "",
        providerType: "ollama",
        modelName: "llama3.1:8b",
        apiUrl: "",
        apiKey: "",
        temperature: 70,
        context: "",
        module: "",
        isActive: true,
        isOnline: false,
      });
    }
    setShowAiSettingsDialog(true);
  };

  // Operator Services mutation
  const updateOperatorServicesMutation = useMutation({
    mutationFn: async ({ operatorId, serviceIds }: { operatorId: number; serviceIds: number[] }) => {
      const response = await apiRequest('PUT', `/api/operators/${operatorId}/services`, { serviceIds });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Услуги оператора обновлены",
        description: "Список услуг оператора успешно изменен",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/operators', selectedOperatorForServices?.id, 'services'] });
      setShowOperatorServicesDialog(false);
    },
  });

  // AI Connection Test mutation
  const testAiConnectionMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/ai/test-connection', data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: data.success ? "Подключение успешно" : "Ошибка подключения",
        description: data.message,
        variant: data.success ? "default" : "destructive",
      });
    },
  });

  // Handle operator services management
  const openOperatorServicesDialog = (operator: any) => {
    setSelectedOperatorForServices(operator);
    setShowOperatorServicesDialog(true);
  };

  // Initialize operator services state when data loads
  React.useEffect(() => {
    if (selectedOperatorForServices && Array.isArray(currentOperatorServices)) {
      setOperatorServices(currentOperatorServices.map((s: any) => s.id || s));
    }
  }, [currentOperatorServices, selectedOperatorForServices]);

  // Initialize ticket preview on component mount
  React.useEffect(() => {
    generateTicketPreview();
  }, []);

  // Send message to operator function
  const sendMessageToOperator = async () => {
    if (!selectedOperatorForChat || !operatorChatMessage.trim()) return;

    setIsSendingMessage(true);
    try {
      const response = await apiRequest('POST', '/api/admin/send-message', {
        operatorId: selectedOperatorForChat.id,
        message: operatorChatMessage,
        timestamp: new Date().toISOString()
      });

      if (response.ok) {
        toast({
          title: "Сообщение отправлено",
          description: `Сообщение успешно отправлено оператору ${selectedOperatorForChat.firstName} ${selectedOperatorForChat.lastName}`,
        });
        setOperatorChatMessage("");
      }
    } catch (error) {
      toast({
        title: "Ошибка отправки",
        description: "Не удалось отправить сообщение оператору",
        variant: "destructive",
      });
    } finally {
      setIsSendingMessage(false);
    }
  };

  // Handle service checkbox changes
  const toggleOperatorService = (serviceId: number) => {
    setOperatorServices(prev => 
      prev.includes(serviceId) 
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  // Export/Import functions
  const handleExport = async () => {
    if (!exportStartDate || !exportEndDate) {
      toast({
        title: "Ошибка",
        description: "Выберите период для экспорта",
        variant: "destructive"
      });
      return;
    }
    
    setIsExporting(true);
    try {
      const response = await fetch(`/api/export/${exportType}?startDate=${exportStartDate}&endDate=${exportEndDate}`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${exportType}_${exportStartDate}_${exportEndDate}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        toast({
          title: "Экспорт завершен",
          description: `Файл ${exportType}_${exportStartDate}_${exportEndDate}.json загружен`
        });
        
        queryClient.invalidateQueries({ queryKey: ['/api/import-export-logs'] });
      } else {
        throw new Error('Ошибка экспорта');
      }
    } catch (error) {
      toast({
        title: "Ошибка экспорта",
        description: "Не удалось экспортировать данные",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleImport = async () => {
    if (!importFile) {
      toast({
        title: "Ошибка",
        description: "Выберите файл для импорта",
        variant: "destructive"
      });
      return;
    }
    
    setIsImporting(true);
    try {
      const formData = new FormData();
      formData.append('file', importFile);
      
      const response = await fetch('/api/import/appointments', {
        method: 'POST',
        body: formData
      });
      
      if (response.ok) {
        const result = await response.json();
        toast({
          title: "Импорт завершен",
          description: `Импортировано ${result.imported} из ${result.total} записей`
        });
        
        queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
        queryClient.invalidateQueries({ queryKey: ['/api/import-export-logs'] });
        setImportFile(null);
      } else {
        throw new Error('Ошибка импорта');
      }
    } catch (error) {
      toast({
        title: "Ошибка импорта",
        description: "Не удалось импортировать данные",
        variant: "destructive"
      });
    } finally {
      setIsImporting(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setImportFile(file || null);
  };

  const handleEmailSubmit = async (data: any) => {
    try {
      updateEmailSettingsMutation.mutate(data);
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить настройки email",
        variant: "destructive"
      });
    }
  };

  const handleAiSettingsSubmit = (data: any) => {
    if (editingAiSetting) {
      updateAiSettingMutation.mutate({ id: editingAiSetting.id, data });
    } else {
      createAiSettingMutation.mutate(data);
    }
  };

  // AI Chat function
  const handleAiChat = async () => {
    if (!aiQuery.trim() || !selectedAiProvider) return;
    
    const selectedProvider = aiSettings.find((s: any) => s.id.toString() === selectedAiProvider);
    if (!selectedProvider) {
      toast({
        title: "Ошибка",
        description: "Выбранный провайдер не найден",
        variant: "destructive"
      });
      return;
    }
    
    setIsAiChatLoading(true);
    const userMessage = {
      message: aiQuery,
      timestamp: new Date().toISOString(),
      isLoading: true
    };
    setChatHistory(prev => [...prev, userMessage]);
    
    try {
      const response = await apiRequest('POST', '/api/ai/chat', {
        message: aiQuery,
        providerId: selectedAiProvider,
        userType: 'admin',
        userId: 1
      });
      const data = await response.json();
      
      setChatHistory(prev => 
        prev.map(msg => 
          msg === userMessage 
            ? { ...msg, response: data.response, isLoading: false }
            : msg
        )
      );
      
      setAiQuery("");
    } catch (error) {
      setChatHistory(prev => prev.filter(msg => msg !== userMessage));
      toast({
        title: "Ошибка",
        description: "Не удалось получить ответ от ИИ",
        variant: "destructive"
      });
    } finally {
      setIsAiChatLoading(false);
    }
  };

  const quickQueries = [
    "Покажи статистику за сегодня",
    "Прогноз нагрузки на завтра",
    "Какие услуги самые популярные?",
    "Анализ времени ожидания",
    "Рекомендации по оптимизации"
  ];

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="max-w-full mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Административная панель</h1>
          <p className="mt-2 text-gray-600">Управление системой и аналитика</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Упрощенная навигация */}
          <TabsList className="grid w-full grid-cols-8 h-12">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              <span className="hidden sm:inline">Обзор</span>
            </TabsTrigger>
            <TabsTrigger value="operators" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Операторы</span>
            </TabsTrigger>
            <TabsTrigger value="services" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Услуги</span>
            </TabsTrigger>
            <TabsTrigger value="departments" className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              <span className="hidden sm:inline">Отделения</span>
            </TabsTrigger>
            <TabsTrigger value="schedule" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">График</span>
            </TabsTrigger>
            <TabsTrigger value="display" className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              <span className="hidden sm:inline">Дисплей</span>
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              <span className="hidden sm:inline">Безопасность</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Аналитика</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {/* Operator Status Overview */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <UserCircle className="h-5 w-5" />
                      Статус операторов
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <OperatorStatusOverview />
                  </CardContent>
                </Card>
              </div>
              
              {/* Quick Stats */}
              <div className="space-y-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Сегодня</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <QuickStatsToday />
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Система</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <SystemStatus />
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Operators Tab */}
          <TabsContent value="operators" className="space-y-6">
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Управление операторами</CardTitle>
                    <Button 
                      className="bg-primary hover:bg-blue-700"
                      onClick={() => openOperatorDialog()}
                      data-testid="button-add-operator"
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Добавить оператора
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {(operators || []).map((operator: any) => (
                        <div key={operator.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-4">
                            <Avatar>
                              <AvatarFallback>
                                {operator.firstName.charAt(0)}{operator.lastName.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{operator.firstName} {operator.lastName}</p>
                              <p className="text-sm text-gray-600">@{operator.username}</p>
                              {operator.email && (
                                <p className="text-xs text-gray-500">{operator.email}</p>
                              )}
                              <div className="flex items-center space-x-2 mt-1">
                                <Badge variant="secondary">Окно {operator.windowNumber}</Badge>
                                <Badge variant={operator.isActive ? "default" : "secondary"}>
                                  {operator.isActive ? "Активен" : "Неактивен"}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => openOperatorServicesDialog(operator)}
                              data-testid={`button-services-${operator.id}`}
                              title="Управление услугами"
                            >
                              <Settings className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => openOperatorDialog(operator)}
                              data-testid={`button-edit-operator-${operator.id}`}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  data-testid={`button-delete-operator-${operator.id}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Удалить оператора?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Вы действительно хотите удалить оператора {operator.firstName} {operator.lastName}? 
                                    Это действие нельзя отменить.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Отмена</AlertDialogCancel>
                                  <AlertDialogAction 
                                    onClick={() => deleteOperatorMutation.mutate(operator.id)}
                                    className="bg-red-600 hover:bg-red-700"
                                  >
                                    Удалить
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Статистика операторов</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Всего операторов:</span>
                        <span className="font-medium">{(operators || []).length || 0}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Активны сейчас:</span>
                        <span className="font-medium text-green-600">
                          {(operators || []).filter((op: any) => op.isActive).length || 0}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Средняя оценка:</span>
                        <span className="font-medium">4.7⭐</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Предварительные записи</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Ожидают активации:</span>
                        <span className="font-medium text-orange-600">
                          {(appointments || []).filter((app: any) => app.status === 'scheduled').length || 0}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Талоны выданы:</span>
                        <span className="font-medium text-blue-600">
                          {(appointments || []).filter((app: any) => app.status === 'confirmed').length || 0}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Завершены:</span>
                        <span className="font-medium text-green-600">
                          {(appointments || []).filter((app: any) => app.status === 'completed').length || 0}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Всего записей:</span>
                        <span className="font-medium">{(appointments || []).length || 0}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Выданные талоны по записям</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {!tickets || tickets.filter((ticket: any) => ticket.appointmentId).length === 0 ? (
                        <div className="text-gray-500 text-center py-4">
                          <div>Талоны по записям не выданы</div>
                          <div className="text-xs mt-1">
                            Всего талонов: {tickets ? tickets.length : 0}, 
                            С записями: {tickets ? tickets.filter((t: any) => t.appointmentId).length : 0}
                          </div>
                        </div>
                      ) : (
                        tickets
                          .filter((ticket: any) => ticket.appointmentId)
                          .sort((a: any, b: any) => new Date(b.issuedAt).getTime() - new Date(a.issuedAt).getTime())
                          .slice(0, 10)
                          .map((ticket: any) => {
                            const appointment = appointments.find((app: any) => app.id === ticket.appointmentId);
                            const service = services.find((svc: any) => svc.id === ticket.serviceId);
                            return (
                              <div key={ticket.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                <div>
                                  <div className="font-semibold text-lg text-blue-600">
                                    {ticket.ticketNumber}
                                  </div>
                                  <div className="text-sm text-gray-600">
                                    {appointment?.clientName || 'Клиент'}
                                  </div>
                                  <div className="text-xs text-gray-500">
                                    {service?.name || 'Услуга'}
                                  </div>
                                </div>
                                <div className="text-right">
                                  <Badge 
                                    variant={
                                      ticket.status === 'completed' ? 'default' :
                                      ticket.status === 'serving' ? 'secondary' :
                                      ticket.status === 'in_progress' ? 'destructive' : 'outline'
                                    }
                                  >
                                    {ticket.status === 'waiting' ? 'Ожидание' :
                                     ticket.status === 'in_progress' ? 'Вызван' :
                                     ticket.status === 'serving' ? 'Обслуживается' :
                                     ticket.status === 'completed' ? 'Завершён' : ticket.status}
                                  </Badge>
                                  <div className="text-xs text-gray-500 mt-1">
                                    {new Date(ticket.issuedAt).toLocaleTimeString('ru-RU')}
                                  </div>
                                </div>
                              </div>
                            );
                          })
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageCircle className="h-5 w-5" />
                      Связь с операторами
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Выберите оператора</Label>
                      <Select value={selectedOperatorForChat?.id?.toString() || ""} onValueChange={(value) => {
                        const operator = operators?.find((op: any) => op.id.toString() === value);
                        setSelectedOperatorForChat(operator);
                      }}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите оператора" />
                        </SelectTrigger>
                        <SelectContent>
                          {(operators || []).map((operator: any) => (
                            <SelectItem key={operator.id} value={operator.id.toString()}>
                              <div className="flex items-center gap-2">
                                <div className={`w-2 h-2 rounded-full ${operator.isActive ? 'bg-green-500' : 'bg-gray-300'}`} />
                                {operator.firstName} {operator.lastName}
                                {operator.isActive && <Badge className="bg-green-500 text-white text-xs">онлайн</Badge>}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {selectedOperatorForChat && (
                      <div className="space-y-3">
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback>
                                {selectedOperatorForChat.firstName?.[0]}{selectedOperatorForChat.lastName?.[0]}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium text-sm">
                                {selectedOperatorForChat.firstName} {selectedOperatorForChat.lastName}
                              </p>
                              <p className="text-xs text-gray-600">Окно № {selectedOperatorForChat.windowNumber}</p>
                            </div>
                            <div className={`ml-auto w-3 h-3 rounded-full ${selectedOperatorForChat.isActive ? 'bg-green-500' : 'bg-red-500'}`} />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Textarea
                            placeholder="Введите сообщение для оператора..."
                            value={operatorChatMessage}
                            onChange={(e) => setOperatorChatMessage(e.target.value)}
                            rows={3}
                          />
                          <Button 
                            onClick={sendMessageToOperator}
                            disabled={!operatorChatMessage.trim() || isSendingMessage}
                            className="w-full"
                          >
                            {isSendingMessage ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Отправка...
                              </>
                            ) : (
                              <>
                                <Send className="mr-2 h-4 w-4" />
                                Отправить сообщение
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Управление услугами</CardTitle>
                <Button 
                  className="bg-primary hover:bg-blue-700"
                  onClick={() => openServiceDialog()}
                  data-testid="button-add-service"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Добавить услугу
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {(services || []).map((service: any) => (
                    <div key={service.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">{service.name}</p>
                        <p className="text-sm text-gray-600">{service.description}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="secondary">Код: {service.serviceCode}</Badge>
                          <Badge variant="outline">Время: {service.estimatedTime} мин</Badge>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => openServiceDialog(service)}
                          data-testid={`button-edit-service-${service.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm"
                              data-testid={`button-delete-service-${service.id}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Удалить услугу?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Вы действительно хотите удалить услугу "{service.name}"? 
                                Это действие нельзя отменить.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Отмена</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => deleteServiceMutation.mutate(service.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Удалить
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Departments Tab */}
          <TabsContent value="departments" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Управление отделениями</CardTitle>
                <Button 
                  className="bg-primary hover:bg-blue-700"
                  onClick={() => openDepartmentDialog()}
                  data-testid="button-add-department"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Добавить отделение
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {(departments || []).map((department: any) => (
                    <div key={department.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">{department.name}</p>
                        <p className="text-sm text-gray-600">{department.address}</p>
                        <p className="text-sm text-gray-600">{department.phone}</p>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => openDepartmentDialog(department)}
                          data-testid={`button-edit-department-${department.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm"
                              data-testid={`button-delete-department-${department.id}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Удалить отделение?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Вы действительно хотите удалить отделение "{department.name}"? 
                                Это действие нельзя отменить.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Отмена</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => deleteDepartmentMutation.mutate(department.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Удалить
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Terminal Settings Tab */}
          <TabsContent value="terminal" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-5 w-5 text-blue-500" />
                  Настройки терминала
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Theme Settings */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <Palette className="h-4 w-4" />
                      Тема и внешний вид
                    </h3>
                    
                    <div>
                      <Label htmlFor="theme">Тема оформления</Label>
                      <Select defaultValue="classic">
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите тему" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="classic">Классическая</SelectItem>
                          <SelectItem value="modern">Современная</SelectItem>
                          <SelectItem value="minimal">Минималистичная</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="bgColor">Фон</Label>
                        <Input
                          id="bgColor"
                          type="color"
                          defaultValue="#ffffff"
                          className="h-10"
                        />
                      </div>
                      <div>
                        <Label htmlFor="textColor">Текст</Label>
                        <Input
                          id="textColor"
                          type="color"
                          defaultValue="#000000"
                          className="h-10"
                        />
                      </div>
                      <div>
                        <Label htmlFor="accentColor">Акцент</Label>
                        <Input
                          id="accentColor"
                          type="color"
                          defaultValue="#0079F2"
                          className="h-10"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Display Settings */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <Timer className="h-4 w-4" />
                      Настройки отображения
                    </h3>
                    
                    <div>
                      <Label htmlFor="orgName">Название организации</Label>
                      <Input
                        id="orgName"
                        defaultValue="ЭЛЕКТРОННАЯ ОЧЕРЕДЬ"
                        placeholder="Введите название"
                      />
                    </div>

                    <div>
                      <Label htmlFor="displayTime">Время показа талона (сек)</Label>
                      <Input
                        id="displayTime"
                        type="number"
                        min="1"
                        max="60"
                        defaultValue="5"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="showWaitTime" defaultChecked />
                        <Label htmlFor="showWaitTime">Показывать время ожидания</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="showPosition" defaultChecked />
                        <Label htmlFor="showPosition">Показывать позицию в очереди</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="enableSound" defaultChecked />
                        <Label htmlFor="enableSound">Звуковые уведомления</Label>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Ticket Template */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Шаблон талона для печати</h3>
                  <Textarea
                    placeholder="Шаблон для печати талона..."
                    rows={10}
                    defaultValue={`================================
{{organizationName}}
================================

ТАЛОН № {{ticketNumber}}

Услуга: {{serviceName}}

Дата: {{date}}
Время: {{time}}

В очереди: {{queueCount}} человек

Приблизительное время ожидания:
{{waitTime}} минут

================================
Сохраните этот талон до вызова
================================`}
                  />
                  <p className="text-sm text-gray-600">
                    Доступные переменные: organizationName, ticketNumber, serviceName, 
                    date, time, queueCount, waitTime
                  </p>
                </div>

                {/* Windows Shortcuts Section */}
                <div className="space-y-4 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <Monitor className="h-5 w-5 text-blue-500" />
                    Создание ярлыков Windows
                  </h3>
                  <p className="text-sm text-gray-600">
                    Создайте ярлыки на рабочем столе для быстрого доступа к различным модулям системы
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    <Button 
                      variant="outline" 
                      className="justify-start h-auto p-3"
                      onClick={() => createWindowsShortcut('terminal', 'Терминал выдачи талонов', '/terminal')}
                      data-testid="button-create-terminal-shortcut"
                    >
                      <div className="text-left">
                        <div className="font-medium">Терминал</div>
                        <div className="text-xs text-gray-500">Выдача талонов</div>
                      </div>
                    </Button>
                    <Button 
                      variant="outline" 
                      className="justify-start h-auto p-3"
                      onClick={() => createWindowsShortcut('display', 'Информационное табло', '/display')}
                      data-testid="button-create-display-shortcut"
                    >
                      <div className="text-left">
                        <div className="font-medium">Табло</div>
                        <div className="text-xs text-gray-500">Информационный дисплей</div>
                      </div>
                    </Button>
                    <Button 
                      variant="outline" 
                      className="justify-start h-auto p-3"
                      onClick={() => createWindowsShortcut('operator', 'Операторский интерфейс', '/operator')}
                      data-testid="button-create-operator-shortcut"
                    >
                      <div className="text-left">
                        <div className="font-medium">Оператор</div>
                        <div className="text-xs text-gray-500">Рабочее место</div>
                      </div>
                    </Button>
                    <Button 
                      variant="outline" 
                      className="justify-start h-auto p-3"
                      onClick={() => createWindowsShortcut('booking', 'Предварительная запись', '/booking')}
                      data-testid="button-create-booking-shortcut"
                    >
                      <div className="text-left">
                        <div className="font-medium">Запись</div>
                        <div className="text-xs text-gray-500">Онлайн бронирование</div>
                      </div>
                    </Button>
                    <Button 
                      variant="outline" 
                      className="justify-start h-auto p-3"
                      onClick={() => createWindowsShortcut('admin', 'Админ-панель', '/admin')}
                      data-testid="button-create-admin-shortcut"
                    >
                      <div className="text-left">
                        <div className="font-medium">Админка</div>
                        <div className="text-xs text-gray-500">Управление системой</div>
                      </div>
                    </Button>
                    <Button 
                      variant="outline" 
                      className="justify-start h-auto p-3 bg-blue-50 border-blue-200"
                      onClick={createAllWindowsShortcuts}
                      data-testid="button-create-all-shortcuts"
                    >
                      <div className="text-left">
                        <div className="font-medium text-blue-700">Все ярлыки</div>
                        <div className="text-xs text-blue-500">Создать все сразу</div>
                      </div>
                    </Button>
                  </div>
                </div>

                {/* Ticket Preview */}
                <div className="space-y-4 p-4 bg-gray-50 rounded-lg border">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <Eye className="h-5 w-5 text-green-500" />
                    Предварительный просмотр талона
                  </h3>
                  <div className="bg-white p-4 border-2 border-dashed border-gray-300 rounded-lg font-mono text-sm">
                    <pre>{ticketPreview}</pre>
                  </div>
                </div>

                <div className="flex justify-end space-x-4">
                  <Button 
                    variant="outline"
                    onClick={generateTicketPreview}
                    data-testid="button-preview-ticket"
                  >
                    <Eye className="mr-2 h-4 w-4" />
                    Обновить предпросмотр
                  </Button>
                  <Button 
                    className="bg-blue-500 hover:bg-blue-600"
                    onClick={() => terminalSettingsMutation.mutate({
                      theme: "classic",
                      displayTimeSeconds: 5,
                      organizationName: "ЭЛЕКТРОННАЯ ОЧЕРЕДЬ",
                      backgroundColor: "#ffffff",
                      textColor: "#000000", 
                      accentColor: "#0079F2",
                      showWaitingTime: true,
                      showQueuePosition: true,
                      enableSound: true
                    })}
                    disabled={terminalSettingsMutation.isPending}
                  >
                    {terminalSettingsMutation.isPending ? "Сохранение..." : "Сохранить настройки"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Display Settings Tab */}
          <TabsContent value="display" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-5 w-5 text-blue-500" />
                  Настройки дисплея очереди
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Organization and Colors */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <Palette className="h-4 w-4" />
                      Организация и цвета
                    </h3>
                    
                    <div>
                      <Label htmlFor="displayOrgName">Название организации</Label>
                      <Input
                        id="displayOrgName"
                        defaultValue="ЭЛЕКТРОННАЯ ОЧЕРЕДЬ"
                        placeholder="Введите название"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="displayBgColor">Фон</Label>
                        <Input
                          id="displayBgColor"
                          type="color"
                          defaultValue="#ffffff"
                          className="h-10"
                        />
                      </div>
                      <div>
                        <Label htmlFor="displayTextColor">Текст</Label>
                        <Input
                          id="displayTextColor"
                          type="color"
                          defaultValue="#000000"
                          className="h-10"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="displayAccentColor">Акцентный</Label>
                        <Input
                          id="displayAccentColor"
                          type="color"
                          defaultValue="#2563eb"
                          className="h-10"
                        />
                      </div>
                      <div>
                        <Label htmlFor="displayHeaderColor">Заголовок</Label>
                        <Input
                          id="displayHeaderColor"
                          type="color"
                          defaultValue="#1e40af"
                          className="h-10"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Display Settings */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <Timer className="h-4 w-4" />
                      Параметры отображения
                    </h3>
                    
                    <div>
                      <Label htmlFor="displayFontSize">Размер шрифта</Label>
                      <Input
                        id="displayFontSize"
                        type="number"
                        min="12"
                        max="24"
                        defaultValue="16"
                      />
                    </div>

                    <div>
                      <Label htmlFor="displayRefreshInterval">Интервал обновления (сек)</Label>
                      <Input
                        id="displayRefreshInterval"
                        type="number"
                        min="1"
                        max="10"
                        defaultValue="3"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="displayShowTime" defaultChecked />
                        <Label htmlFor="displayShowTime">Показывать время</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="displayShowCompleted" defaultChecked />
                        <Label htmlFor="displayShowCompleted">Показывать количество обслуженных</Label>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Preview Section */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Предварительный просмотр</h3>
                  <div 
                    className="p-6 rounded-lg border-2 text-center"
                    style={{ 
                      backgroundColor: '#ffffff',
                      borderColor: '#2563eb',
                      color: '#000000'
                    }}
                  >
                    <div 
                      className="p-4 rounded-lg mb-4 text-white"
                      style={{ backgroundColor: '#1e40af' }}
                    >
                      <h2 className="text-2xl font-bold">ЭЛЕКТРОННАЯ ОЧЕРЕДЬ</h2>
                      <div className="text-lg mt-2">13:30 | 11 августа 2025</div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h3 className="font-bold text-lg mb-2" style={{ color: '#2563eb' }}>
                          СЕЙЧАС ОБСЛУЖИВАЕТСЯ
                        </h3>
                        <div className="p-3 border rounded" style={{ borderColor: '#2563eb' }}>
                          <div className="flex justify-between">
                            <div>
                              <div className="font-semibold">Окно 1</div>
                              <div className="text-xl font-bold">A-01</div>
                            </div>
                            <div className="text-green-500">✓</div>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-bold text-lg mb-2" style={{ color: '#2563eb' }}>
                          ОЧЕРЕДЬ ОЖИДАНИЯ
                        </h3>
                        <div className="space-y-1">
                          <div className="p-2 bg-gray-100 rounded flex justify-between">
                            <span>1. A-02</span>
                            <span className="text-sm">13:25</span>
                          </div>
                          <div className="p-2 bg-gray-100 rounded flex justify-between">
                            <span>2. A-03</span>
                            <span className="text-sm">13:27</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-4">
                  <Button variant="outline" onClick={() => window.open('/display', '_blank')}>
                    Предварительный просмотр
                  </Button>
                  <Button 
                    className="bg-blue-500 hover:bg-blue-600"
                    onClick={async () => {
                      const formData = {
                        organizationName: (document.getElementById('displayOrgName') as HTMLInputElement)?.value || 'ЭЛЕКТРОННАЯ ОЧЕРЕДЬ',
                        backgroundColor: (document.getElementById('displayBgColor') as HTMLInputElement)?.value || '#ffffff',
                        textColor: (document.getElementById('displayTextColor') as HTMLInputElement)?.value || '#000000',
                        accentColor: (document.getElementById('displayAccentColor') as HTMLInputElement)?.value || '#2563eb',
                        headerColor: (document.getElementById('displayHeaderColor') as HTMLInputElement)?.value || '#1e40af',
                        fontSize: parseInt((document.getElementById('displayFontSize') as HTMLInputElement)?.value) || 16,
                        refreshInterval: parseInt((document.getElementById('displayRefreshInterval') as HTMLInputElement)?.value) || 3,
                        showTime: (document.getElementById('displayShowTime') as HTMLInputElement)?.checked ?? true,
                        showCompletedCount: (document.getElementById('displayShowCompleted') as HTMLInputElement)?.checked ?? true
                      };
                      
                      try {
                        const response = await fetch('/api/display-settings', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify(formData)
                        });
                        
                        if (response.ok) {
                          toast({
                            title: "Настройки дисплея сохранены",
                            description: "Настройки дисплея успешно обновлены",
                          });
                        } else {
                          throw new Error('Failed to save');
                        }
                      } catch (error) {
                        toast({
                          title: "Ошибка",
                          description: "Не удалось сохранить настройки дисплея",
                          variant: "destructive",
                        });
                      }
                    }}
                  >
                    Сохранить настройки дисплея
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Ticket Settings Tab */}
          <TabsContent value="tickets" className="space-y-6">
            <TicketSettingsForm />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Users className="h-8 w-8 text-primary" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">В очереди</p>
                      <p className="text-2xl font-bold text-gray-900">{(statistics as any)?.activeQueue || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <BarChart3 className="h-8 w-8 text-green-500" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Обслужено</p>
                      <p className="text-2xl font-bold text-gray-900">{(statistics as any)?.completedToday || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Clock className="h-8 w-8 text-yellow-500" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Среднее время</p>
                      <p className="text-2xl font-bold text-gray-900">{(statistics as any)?.averageWaitTime || 0} мин</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Bot className="h-8 w-8 text-cyan-500" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">ИИ запросы</p>
                      <p className="text-2xl font-bold text-gray-900">{chatHistory.length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-blue-500" />
                    Операционная эффективность
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 gap-2 mb-4">
                    <Link href="/statistics">
                      <Button className="w-full" variant="outline">
                        <BarChart3 className="mr-2 h-4 w-4" />
                        Базовая статистика
                      </Button>
                    </Link>
                    <Link href="/advanced-statistics">
                      <Button className="w-full" variant="default">
                        <TrendingUp className="mr-2 h-4 w-4" />
                        Расширенная аналитика
                      </Button>
                    </Link>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Коэффициент обслуживания</span>
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-green-500 transition-all duration-300" 
                            style={{ 
                              width: `${Math.min(100, ((statistics as any)?.completedToday || 0) / Math.max(1, ((statistics as any)?.activeQueue || 0) + ((statistics as any)?.completedToday || 0)) * 100)}%` 
                            }}
                          />
                        </div>
                        <span className="text-sm font-medium">
                          {Math.round(((statistics as any)?.completedToday || 0) / Math.max(1, ((statistics as any)?.activeQueue || 0) + ((statistics as any)?.completedToday || 0)) * 100)}%
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Активных операторов</span>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold text-blue-600">
                          {(operators || []).filter((op: any) => op.isActive).length}
                        </span>
                        <span className="text-xs text-gray-500">из {(operators || []).length}</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Загрузка системы</span>
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className={`h-full transition-all duration-300 ${
                              ((statistics as any)?.activeQueue || 0) > 10 ? 'bg-red-500' : 
                              ((statistics as any)?.activeQueue || 0) > 5 ? 'bg-yellow-500' : 'bg-green-500'
                            }`}
                            style={{ width: `${Math.min(100, ((statistics as any)?.activeQueue || 0) * 10)}%` }}
                          />
                        </div>
                        <Badge 
                          className={`text-xs ${
                            ((statistics as any)?.activeQueue || 0) > 10 ? 'bg-red-100 text-red-800' : 
                            ((statistics as any)?.activeQueue || 0) > 5 ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                          }`}
                        >
                          {((statistics as any)?.activeQueue || 0) > 10 ? 'Высокая' : 
                           ((statistics as any)?.activeQueue || 0) > 5 ? 'Средняя' : 'Низкая'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-500" />
                    Качество обслуживания
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Средняя оценка</span>
                      <div className="flex items-center gap-2">
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <span key={star} className={`text-lg ${star <= 4 ? 'text-yellow-400' : 'text-gray-300'}`}>⭐</span>
                          ))}
                        </div>
                        <span className="text-sm font-medium">4.2/5</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Время ожидания</span>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-orange-500" />
                        <span className="text-lg font-bold text-orange-600">
                          {(statistics as any)?.averageWaitTime || 0} мин
                        </span>
                        <Badge className={`text-xs ${
                          ((statistics as any)?.averageWaitTime || 0) > 15 ? 'bg-red-100 text-red-800' : 
                          ((statistics as any)?.averageWaitTime || 0) > 10 ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                        }`}>
                          {((statistics as any)?.averageWaitTime || 0) > 15 ? 'Долго' : 
                           ((statistics as any)?.averageWaitTime || 0) > 10 ? 'Норма' : 'Отлично'}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Записей на сегодня</span>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-blue-500" />
                        <span className="text-lg font-bold text-blue-600">
                          {(appointments || []).filter((app: any) => {
                            const today = new Date().toDateString();
                            const appDate = new Date(app.createdAt).toDateString();
                            return appDate === today;
                          }).length}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Security Settings Tab */}
          <TabsContent value="security" className="space-y-6">
            <SecuritySettingsComponent />
          </TabsContent>

          {/* AI Chat Tab - Unified Interface */}
          <TabsContent value="ai-chat" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Bot className="h-5 w-5 text-cyan-500" />
                      ИИ-Помощник
                    </CardTitle>
                    <div className="flex items-center gap-3">
                      {/* Provider Selector */}
                      <Select value={selectedAiProvider} onValueChange={setSelectedAiProvider}>
                        <SelectTrigger className="w-48">
                          <SelectValue placeholder="Выберите ИИ провайдера" />
                        </SelectTrigger>
                        <SelectContent>
                          {aiSettings.filter((s: any) => s.isActive).map((setting: any) => (
                            <SelectItem key={setting.id} value={setting.id.toString()}>
                              {setting.providerType === 'huggingface' ? '🌐' : '🔹'} {setting.settingName}
                            </SelectItem>
                          ))}
                          {aiSettings.filter((s: any) => s.isActive).length === 0 && (
                            <SelectItem value="no-providers" disabled>
                              Нет активных подключений
                            </SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                      
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        {selectedAiProvider ? 'Подключен' : 'Не выбран'}
                      </Badge>
                      
                      {/* Settings Button */}
                      <Dialog open={showAiSettings} onOpenChange={setShowAiSettings}>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            <Settings className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>Настройки ИИ</DialogTitle>
                            <DialogDescription>
                              Управление подключениями к ИИ провайдерам
                            </DialogDescription>
                          </DialogHeader>
                          
                          <div className="space-y-4">
                            <div className="flex justify-between items-center">
                              <h3 className="text-lg font-medium">Активные подключения</h3>
                              <Button onClick={() => openAiSettingsDialog()}>
                                <Plus className="mr-2 h-4 w-4" />
                                Добавить подключение
                              </Button>
                            </div>
                            
                            <div className="grid gap-4">
                              {aiSettings.map((setting: any) => (
                                <Card key={setting.id} className={setting.isActive ? 'border-green-200 bg-green-50' : 'border-gray-200'}>
                                  <CardContent className="p-4">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center space-x-3">
                                        <div className={`w-3 h-3 rounded-full ${setting.isActive ? 'bg-green-500' : 'bg-gray-400'}`} />
                                        <div>
                                          <p className="font-medium">{setting.settingName}</p>
                                          <p className="text-sm text-gray-600">
                                            {setting.providerType} - {setting.modelName}
                                          </p>
                                        </div>
                                      </div>
                                      <div className="flex space-x-2">
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          onClick={() => testAiConnectionMutation.mutate(setting)}
                                          disabled={testAiConnectionMutation.isPending}
                                        >
                                          <Wifi className="h-4 w-4" />
                                        </Button>
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          onClick={() => openAiSettingsDialog(setting)}
                                        >
                                          <Edit className="h-4 w-4" />
                                        </Button>
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>
                              ))}
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardHeader>
                  <CardContent className="flex flex-col h-96">
                    <div className="flex-1 bg-gray-50 p-4 rounded-lg overflow-y-auto mb-4">
                      <div className="space-y-4">
                        {/* Initial AI message */}
                        <div className="flex items-start">
                          <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white text-sm mr-3">
                            <Bot className="h-4 w-4" />
                          </div>
                          <div className="bg-white p-3 rounded-lg shadow-sm max-w-md">
                            <p className="text-sm">Привет! Я ваш ИИ-помощник. Могу помочь с анализом данных очереди, прогнозированием нагрузки и ответами на вопросы о системе.</p>
                          </div>
                        </div>

                        {/* Chat history */}
                        {chatHistory.map((message) => (
                          <div key={message.id} className="space-y-2">
                            <div className="flex items-start justify-end">
                              <div className="bg-primary text-white p-3 rounded-lg shadow-sm max-w-md">
                                <p className="text-sm">{message.query}</p>
                              </div>
                              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm ml-3">
                                <UserCircle className="h-4 w-4" />
                              </div>
                            </div>
                            
                            <div className="flex items-start">
                              <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white text-sm mr-3">
                                <Bot className="h-4 w-4" />
                              </div>
                              <div className="bg-white p-3 rounded-lg shadow-sm max-w-md">
                                <p className="text-sm whitespace-pre-wrap">{message.response}</p>
                              </div>
                            </div>
                          </div>
                        ))}

                        {aiChatMutation.isPending && (
                          <div className="flex items-start">
                            <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white text-sm mr-3">
                              <Bot className="h-4 w-4" />
                            </div>
                            <div className="bg-white p-3 rounded-lg shadow-sm">
                              <p className="text-sm text-gray-500">Генерирую ответ...</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <form onSubmit={handleAiSubmit} className="flex">
                      <Input
                        value={aiQuery}
                        onChange={(e) => setAiQuery(e.target.value)}
                        placeholder="Задайте вопрос ИИ-помощнику..."
                        className="flex-1 rounded-r-none"
                        disabled={aiChatMutation.isPending || !selectedAiProvider}
                      />
                      <Button 
                        type="submit" 
                        className="bg-cyan-500 hover:bg-cyan-600 rounded-l-none"
                        disabled={!aiQuery.trim() || aiChatMutation.isPending || !selectedAiProvider}
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Готовые запросы</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {quickQueries.map((query, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          className="w-full justify-start text-sm"
                          onClick={() => setAiQuery(query)}
                          disabled={!selectedAiProvider}
                        >
                          {query}
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>


              </div>
            </div>
          </TabsContent>


          {/* Enhanced Import/Export Tab with Database Backup */}
          <TabsContent value="import-export" className="space-y-6">
            {/* Database Backup Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Резервное копирование базы данных
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Описание резервной копии</Label>
                      <Input
                        placeholder="Еженедельная резервная копия"
                        value={backupDescription}
                        onChange={(e) => setBackupDescription(e.target.value)}
                        data-testid="input-backup-description"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button 
                        onClick={handleCreateBackup}
                        disabled={isCreatingBackup}
                        className="w-full"
                        data-testid="button-create-backup"
                      >
                        {isCreatingBackup ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Создание...
                          </>
                        ) : (
                          <>
                            <Database className="mr-2 h-4 w-4" />
                            Создать резервную копию
                          </>
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Автоматические резервные копии</Label>
                      <Switch 
                        checked={autoBackupEnabled}
                        onCheckedChange={setAutoBackupEnabled}
                        data-testid="switch-auto-backup"
                      />
                    </div>
                    <p className="text-sm text-gray-600">
                      {autoBackupEnabled ? 
                        "Автоматические еженедельные резервные копии включены" : 
                        "Автоматические резервные копии отключены"
                      }
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-600">
                    <Trash className="h-5 w-5" />
                    Очистка базы данных
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>PIN-код подтверждения</Label>
                    <Input
                      type="password"
                      placeholder="Введите PIN (по умолчанию: 2025)"
                      value={clearDbPin}
                      onChange={(e) => setClearDbPin(e.target.value)}
                      data-testid="input-clear-db-pin"
                    />
                  </div>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        variant="destructive" 
                        className="w-full"
                        disabled={!clearDbPin}
                        data-testid="button-clear-database"
                      >
                        <Trash className="mr-2 h-4 w-4" />
                        Очистить базу данных
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Подтверждение очистки</AlertDialogTitle>
                        <AlertDialogDescription>
                          Вы уверены, что хотите очистить базу данных? Это действие удалит все талоны, записи, статистику и историю операций. 
                          Критически важные данные (операторы, услуги, настройки) будут сохранены.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Отмена</AlertDialogCancel>
                        <AlertDialogAction onClick={handleClearDatabase} className="bg-red-600 hover:bg-red-700">
                          Очистить
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </CardContent>
              </Card>
            </div>

            {/* Data Import/Export Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileDown className="h-5 w-5" />
                    Экспорт данных
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Тип данных</Label>
                    <Select value={exportType} onValueChange={setExportType}>
                      <SelectTrigger data-testid="select-export-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="appointments">Записи на прием</SelectItem>
                        <SelectItem value="tickets">Талоны</SelectItem>
                        <SelectItem value="statistics">Статистика</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Дата начала</Label>
                      <Input
                        type="date"
                        value={exportStartDate}
                        onChange={(e) => setExportStartDate(e.target.value)}
                        data-testid="input-export-start-date"
                      />
                    </div>
                    <div>
                      <Label>Дата окончания</Label>
                      <Input
                        type="date"
                        value={exportEndDate}
                        onChange={(e) => setExportEndDate(e.target.value)}
                        data-testid="input-export-end-date"
                      />
                    </div>
                  </div>

                  <Button 
                    onClick={handleExport}
                    disabled={isExporting}
                    className="w-full"
                    data-testid="button-export"
                  >
                    {isExporting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Экспорт...
                      </>
                    ) : (
                      <>
                        <Download className="mr-2 h-4 w-4" />
                        Экспорт
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileUp className="h-5 w-5" />
                    Импорт данных
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="import-file">Выберите файл</Label>
                    <Input
                      id="import-file"
                      type="file"
                      accept=".csv,.json,.xlsx"
                      onChange={handleFileSelect}
                      data-testid="input-import-file"
                    />
                  </div>
                  
                  <div>
                    <Label>Тип данных для импорта</Label>
                    <Select value={importType} onValueChange={setImportType}>
                      <SelectTrigger data-testid="select-import-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="appointments">Записи на прием</SelectItem>
                        <SelectItem value="tickets">Талоны (с проверкой дублирования)</SelectItem>
                        <SelectItem value="operators">Операторы</SelectItem>
                        <SelectItem value="services">Услуги</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch 
                      checked={preventDuplicates}
                      onCheckedChange={setPreventDuplicates}
                      data-testid="switch-prevent-duplicates"
                    />
                    <Label className="text-sm">Предотвращать дублирование записей</Label>
                  </div>

                  <Button
                    onClick={handleImport}
                    disabled={!importFile || isImporting}
                    className="w-full"
                    data-testid="button-import"
                  >
                    {isImporting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Импорт...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        Импорт {preventDuplicates && "(с защитой от дублей)"}
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Backup History and Operations Log */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <History className="h-5 w-5" />
                    История резервных копий
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {databaseBackups.map((backup) => (
                      <div key={backup.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-sm">backup_{backup.id}.sql</p>
                          <p className="text-xs text-gray-600">
                            {backup.description} • {backup.size}
                          </p>
                          <p className="text-xs text-gray-500">
                            {backup.timestamp}
                          </p>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteBackup(backup.id)}
                          data-testid={`button-delete-backup-${backup.id}`}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                    {databaseBackups.length === 0 && (
                      <div className="text-center py-4 text-gray-500">
                        Резервные копии отсутствуют
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>История операций импорт/экспорт</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {importExportLogs.map((log) => (
                      <div key={log.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-sm">
                            {log.type === 'import' ? 'Импорт' : 'Экспорт'} - {log.dataType}
                          </p>
                          <p className="text-xs text-gray-600">
                            Записей: {log.recordsCount || 0}
                          </p>
                          <p className="text-xs text-gray-500">{log.timestamp}</p>
                        </div>
                        <Badge className={log.success ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                          {log.success ? 'Успешно' : 'Ошибка'}
                        </Badge>
                      </div>
                    ))}
                    {importExportLogs.length === 0 && (
                      <div className="text-center py-4 text-gray-500">
                        История операций пуста
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Email Settings Tab */}
          <TabsContent value="email-settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="h-5 w-5" />
                  Настройки электронной почты
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Form {...emailForm}>
                  <form onSubmit={emailForm.handleSubmit(handleEmailSubmit)} className="space-y-4">
                    <FormField
                      control={emailForm.control}
                      name="smtpHost"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>SMTP сервер</FormLabel>
                          <FormControl>
                            <Input placeholder="smtp.gmail.com" {...field} data-testid="input-smtp-host" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={emailForm.control}
                      name="smtpPort"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>SMTP порт</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="587" 
                              {...field}
                              value={field.value?.toString() || ''}
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 587)}
                              data-testid="input-smtp-port"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={emailForm.control}
                      name="smtpUser"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Логин</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="user@example.com" {...field} data-testid="input-smtp-username" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={emailForm.control}
                      name="smtpPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Пароль</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} data-testid="input-smtp-password" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={emailForm.control}
                      name="fromEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Отправитель (email)</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="noreply@example.com" {...field} data-testid="input-from-email" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={emailForm.control}
                      name="fromName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Имя отправителя</FormLabel>
                          <FormControl>
                            <Input placeholder="Система очередей" {...field} data-testid="input-from-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      data-testid="button-save-email-settings"
                    >
                      Сохранить
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Voice Settings Tab */}
          <TabsContent value="voice" className="space-y-6">
            <VoiceSettingsEnhanced />
          </TabsContent>

          {/* Display Boards Tab */}
          <TabsContent value="display-boards" className="space-y-6">
            <DisplayBoardSettings />
          </TabsContent>

          {/* Help Tab */}
          <TabsContent value="help" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <HelpCircle className="h-5 w-5 text-blue-500" />
                  Справка по системе управления очередями
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="text-center">
                    <Link href="/help">
                      <Button size="lg" className="bg-primary hover:bg-blue-700">
                        <HelpCircle className="mr-2 h-5 w-5" />
                        Открыть полную справку
                      </Button>
                    </Link>
                    <p className="text-sm text-gray-600 mt-2">
                      Откроется подробное руководство по использованию всех модулей системы
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <Card className="p-4 border-blue-100 bg-blue-50">
                      <div className="flex items-center gap-3 mb-3">
                        <Home className="h-8 w-8 text-blue-600" />
                        <div>
                          <h3 className="font-semibold text-blue-900">Главная панель</h3>
                          <p className="text-sm text-blue-700">Обзор системы и статистика</p>
                        </div>
                      </div>
                      <ul className="text-sm text-blue-800 space-y-1">
                        <li>• Текущая очередь</li>
                        <li>• Статистика за день</li>
                        <li>• Навигация по модулям</li>
                      </ul>
                    </Card>

                    <Card className="p-4 border-green-100 bg-green-50">
                      <div className="flex items-center gap-3 mb-3">
                        <CalendarPlus className="h-8 w-8 text-green-600" />
                        <div>
                          <h3 className="font-semibold text-green-900">Предварительная запись</h3>
                          <p className="text-sm text-green-700">Онлайн-бронирование услуг</p>
                        </div>
                      </div>
                      <ul className="text-sm text-green-800 space-y-1">
                        <li>• Выбор услуги и времени</li>
                        <li>• Получение PIN-кода</li>
                        <li>• SMS/Email уведомления</li>
                      </ul>
                    </Card>

                    <Card className="p-4 border-orange-100 bg-orange-50">
                      <div className="flex items-center gap-3 mb-3">
                        <Monitor className="h-8 w-8 text-orange-600" />
                        <div>
                          <h3 className="font-semibold text-orange-900">Терминал</h3>
                          <p className="text-sm text-orange-700">Выдача талонов посетителям</p>
                        </div>
                      </div>
                      <ul className="text-sm text-orange-800 space-y-1">
                        <li>• Выбор услуги</li>
                        <li>• Ввод PIN-кода записи</li>
                        <li>• Печать талонов</li>
                      </ul>
                    </Card>

                    <Card className="p-4 border-purple-100 bg-purple-50">
                      <div className="flex items-center gap-3 mb-3">
                        <UserCheck className="h-8 w-8 text-purple-600" />
                        <div>
                          <h3 className="font-semibold text-purple-900">Оператор</h3>
                          <p className="text-sm text-purple-700">Обслуживание клиентов</p>
                        </div>
                      </div>
                      <ul className="text-sm text-purple-800 space-y-1">
                        <li>• Вызов клиентов</li>
                        <li>• Управление очередью</li>
                        <li>• Сбор оценок</li>
                      </ul>
                    </Card>

                    <Card className="p-4 border-indigo-100 bg-indigo-50">
                      <div className="flex items-center gap-3 mb-3">
                        <Tv className="h-8 w-8 text-indigo-600" />
                        <div>
                          <h3 className="font-semibold text-indigo-900">Табло</h3>
                          <p className="text-sm text-indigo-700">Информационный дисплей</p>
                        </div>
                      </div>
                      <ul className="text-sm text-indigo-800 space-y-1">
                        <li>• Отображение очереди</li>
                        <li>• Голосовые объявления</li>
                        <li>• Информация для посетителей</li>
                      </ul>
                    </Card>

                    <Card className="p-4 border-teal-100 bg-teal-50">
                      <div className="flex items-center gap-3 mb-3">
                        <Users className="h-8 w-8 text-teal-600" />
                        <div>
                          <h3 className="font-semibold text-teal-900">Админ зала</h3>
                          <p className="text-sm text-teal-700">Управление записями</p>
                        </div>
                      </div>
                      <ul className="text-sm text-teal-800 space-y-1">
                        <li>• Просмотр записей</li>
                        <li>• Выдача талонов</li>
                        <li>• Контроль посещений</li>
                      </ul>
                    </Card>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Быстрые ссылки</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <Link href="/statistics">
                        <Button variant="outline" size="sm" className="w-full">
                          <BarChart3 className="mr-2 h-4 w-4" />
                          Статистика
                        </Button>
                      </Link>
                      <Link href="/advanced-statistics">
                        <Button variant="outline" size="sm" className="w-full">
                          <TrendingUp className="mr-2 h-4 w-4" />
                          Аналитика
                        </Button>
                      </Link>
                      <Link href="/display">
                        <Button variant="outline" size="sm" className="w-full">
                          <Tv className="mr-2 h-4 w-4" />
                          Табло
                        </Button>
                      </Link>
                      <Link href="/">
                        <Button variant="outline" size="sm" className="w-full">
                          <Home className="mr-2 h-4 w-4" />
                          Главная
                        </Button>
                      </Link>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h3 className="font-semibold text-blue-900 mb-2">Техническая информация</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-blue-800">
                      <div>
                        <strong>Системные требования:</strong>
                        <ul className="mt-1 space-y-1">
                          <li>• Windows 10+ или Ubuntu 20.04+</li>
                          <li>• Node.js 18+ для разработки</li>
                          <li>• PostgreSQL 12+ база данных</li>
                        </ul>
                      </div>
                      <div>
                        <strong>Аппаратные интеграции:</strong>
                        <ul className="mt-1 space-y-1">
                          <li>• Термопринтеры 80мм рулон</li>
                          <li>• Электронные табло COM port</li>
                          <li>• RHVoice голосовые объявления</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Operator Dialog */}
        <Dialog open={showOperatorDialog} onOpenChange={setShowOperatorDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingOperator ? 'Редактировать оператора' : 'Добавить оператора'}
              </DialogTitle>
            </DialogHeader>
            <Form {...operatorForm}>
              <form onSubmit={operatorForm.handleSubmit(handleOperatorSubmit)} className="space-y-4">
                <FormField
                  control={operatorForm.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Имя</FormLabel>
                      <FormControl>
                        <Input placeholder="Иван" {...field} data-testid="input-operator-firstname" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={operatorForm.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Фамилия</FormLabel>
                      <FormControl>
                        <Input placeholder="Иванов" {...field} data-testid="input-operator-lastname" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={operatorForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Имя пользователя</FormLabel>
                      <FormControl>
                        <Input placeholder="ivanov_ivan" {...field} data-testid="input-operator-username" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={operatorForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email (опционально)</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="ivan@example.com" {...field} data-testid="input-operator-email" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={operatorForm.control}
                  name="departmentId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Отделение</FormLabel>
                      <Select onValueChange={(value) => field.onChange(Number(value))} value={field.value?.toString()}>
                        <FormControl>
                          <SelectTrigger data-testid="select-operator-department">
                            <SelectValue placeholder="Выберите отделение" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {departments.map((dept: any) => (
                            <SelectItem key={dept.id} value={dept.id.toString()}>
                              {dept.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={operatorForm.control}
                  name="windowNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Номер окна</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="1" 
                          {...field}
                          value={field.value?.toString() || ''}
                          onChange={(e) => field.onChange(Number(e.target.value))}
                          data-testid="input-operator-window"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={operatorForm.control}
                  name="passwordHash"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Пароль</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Введите пароль" {...field} data-testid="input-operator-password" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setShowOperatorDialog(false)}>
                    Отмена
                  </Button>
                  <Button type="submit" data-testid="button-save-operator">
                    {editingOperator ? 'Обновить' : 'Создать'}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Service Dialog */}
        <Dialog open={showServiceDialog} onOpenChange={setShowServiceDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingService ? 'Редактировать услугу' : 'Добавить услугу'}
              </DialogTitle>
            </DialogHeader>
            <Form {...serviceForm}>
              <form onSubmit={serviceForm.handleSubmit(handleServiceSubmit)} className="space-y-4">
                <FormField
                  control={serviceForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Название</FormLabel>
                      <FormControl>
                        <Input placeholder="Консультация" {...field} data-testid="input-service-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Описание</FormLabel>
                      <FormControl>
                        <Input placeholder="Описание услуги" {...field} data-testid="input-service-description" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="estimatedTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Время (мин)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="15" 
                          {...field}
                          value={field.value?.toString() || ''}
                          onChange={(e) => field.onChange(Number(e.target.value))}
                          data-testid="input-service-time"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="departmentId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Отделение</FormLabel>
                      <Select onValueChange={(value) => field.onChange(Number(value))} value={field.value?.toString()}>
                        <FormControl>
                          <SelectTrigger data-testid="select-service-department">
                            <SelectValue placeholder="Выберите отделение" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {departments.map((dept: any) => (
                            <SelectItem key={dept.id} value={dept.id.toString()}>
                              {dept.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="serviceCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Код услуги</FormLabel>
                      <FormControl>
                        <Input placeholder="A1" {...field} data-testid="input-service-code" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setShowServiceDialog(false)}>
                    Отмена
                  </Button>
                  <Button type="submit" data-testid="button-save-service">
                    {editingService ? 'Обновить' : 'Создать'}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Department Dialog */}
        <Dialog open={showDepartmentDialog} onOpenChange={setShowDepartmentDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingDepartment ? 'Редактировать отделение' : 'Добавить отделение'}
              </DialogTitle>
            </DialogHeader>
            <Form {...departmentForm}>
              <form onSubmit={departmentForm.handleSubmit(handleDepartmentSubmit)} className="space-y-4">
                <FormField
                  control={departmentForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Название</FormLabel>
                      <FormControl>
                        <Input placeholder="Отдел документооборота" {...field} data-testid="input-department-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={departmentForm.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Адрес</FormLabel>
                      <FormControl>
                        <Input placeholder="ул. Центральная, 1" {...field} data-testid="input-department-address" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={departmentForm.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Телефон</FormLabel>
                      <FormControl>
                        <Input placeholder="+7(800)123-45-67" {...field} data-testid="input-department-phone" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setShowDepartmentDialog(false)}>
                    Отмена
                  </Button>
                  <Button type="submit" data-testid="button-save-department">
                    {editingDepartment ? 'Обновить' : 'Создать'}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Operator Services Dialog */}
        <Dialog open={showOperatorServicesDialog} onOpenChange={setShowOperatorServicesDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                Управление услугами оператора
              </DialogTitle>
              <DialogDescription>
                Выберите услуги, которые может выполнять {selectedOperatorForServices?.firstName} {selectedOperatorForServices?.lastName}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="max-h-60 overflow-y-auto space-y-2">
                {services && services.map((service: any) => (
                  <div key={service.id} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`service-${service.id}`}
                      checked={operatorServices.includes(service.id)}
                      onChange={() => toggleOperatorService(service.id)}
                      className="rounded border-gray-300"
                      data-testid={`checkbox-service-${service.id}`}
                    />
                    <label 
                      htmlFor={`service-${service.id}`} 
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                    >
                      {service.name}
                      <div className="text-xs text-gray-500">{service.description}</div>
                    </label>
                  </div>
                ))}
              </div>
              <div className="flex justify-end space-x-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowOperatorServicesDialog(false)}
                  data-testid="button-cancel-operator-services"
                >
                  Отмена
                </Button>
                <Button 
                  onClick={() => {
                    if (selectedOperatorForServices) {
                      updateOperatorServicesMutation.mutate({
                        operatorId: selectedOperatorForServices.id,
                        serviceIds: operatorServices
                      });
                    }
                  }}
                  disabled={updateOperatorServicesMutation.isPending}
                  data-testid="button-save-operator-services"
                >
                  {updateOperatorServicesMutation.isPending ? 'Сохранение...' : 'Сохранить'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* AI Settings Dialog */}
        <Dialog open={showAiSettingsDialog} onOpenChange={setShowAiSettingsDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingAiSetting ? 'Редактировать настройки ИИ' : 'Добавить настройки ИИ'}
              </DialogTitle>
            </DialogHeader>
            <Form {...aiSettingsForm}>
              <form onSubmit={aiSettingsForm.handleSubmit(handleAiSettingsSubmit)} className="space-y-4">
                <FormField
                  control={aiSettingsForm.control}
                  name="settingName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Название подключения</FormLabel>
                      <FormControl>
                        <Input placeholder="Локальный Ollama" {...field} data-testid="input-ai-setting-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={aiSettingsForm.control}
                  name="providerType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Тип провайдера</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ai-provider-type">
                            <SelectValue placeholder="Выберите провайдера" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="ollama">Ollama</SelectItem>
                          <SelectItem value="openai">OpenAI</SelectItem>
                          <SelectItem value="anthropic">Anthropic</SelectItem>
                          <SelectItem value="gemini">Google Gemini</SelectItem>
                          <SelectItem value="huggingface">Hugging Face</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={aiSettingsForm.control}
                  name="modelName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Название модели</FormLabel>
                      <FormControl>
                        <Input placeholder="llama3.1:8b" {...field} data-testid="input-ai-model-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={aiSettingsForm.control}
                  name="temperature"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Температура (0-100)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="0" 
                          max="100" 
                          placeholder="70" 
                          {...field} 
                          onChange={(e) => field.onChange(Number(e.target.value))}
                          data-testid="input-ai-temperature" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={aiSettingsForm.control}
                  name="context"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Контекст системы (опционально)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Вы помощник системы электронной очереди..."
                          {...field} 
                          data-testid="input-ai-context" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setShowAiSettingsDialog(false)}>
                    Отмена
                  </Button>
                  <Button type="submit" data-testid="button-save-ai-settings">
                    {editingAiSetting ? 'Обновить' : 'Создать'}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
