import React, { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Navigation from "@/components/layout/navigation";
import { 
  MessageSquare, Send, Users, Clock, CheckCircle, 
  AlertCircle, Loader2, ArrowLeft, RefreshCw 
} from "lucide-react";
import { format } from "date-fns";

interface Message {
  id: number;
  senderId: number;
  senderName: string;
  receiverId?: number | null;
  message: string;
  createdAt: string;
  isRead: boolean;
  messageType: 'broadcast' | 'direct';
}

interface Operator {
  id: number;
  firstName: string;
  lastName: string;
  windowNumber: number;
  role: string;
  isOnline?: boolean;
}

export default function OperatorChat() {
  const { toast } = useToast();
  const [newMessage, setNewMessage] = useState("");
  const [selectedRecipient, setSelectedRecipient] = useState<string>("broadcast");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Data fetching
  const { data: operators = [], isLoading: operatorsLoading } = useQuery({
    queryKey: ['/api/operators'],
    refetchInterval: 30000, // Refresh operator list every 30 seconds
  });

  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/operator-messages'],
    refetchInterval: 5000, // Refresh messages every 5 seconds
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: any) => {
      const response = await apiRequest('POST', '/api/operator-messages', messageData);
      return response.json();
    },
    onSuccess: () => {
      setNewMessage("");
      queryClient.invalidateQueries({ queryKey: ['/api/operator-messages'] });
      toast({
        title: "Сообщение отправлено",
        description: "Сообщение успешно доставлено",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось отправить сообщение",
        variant: "destructive",
      });
    },
  });

  // Mark messages as read mutation  
  const markAsReadMutation = useMutation({
    mutationFn: async (messageIds: number[]) => {
      const response = await apiRequest('PATCH', '/api/operator-messages/mark-read', { messageIds });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/operator-messages'] });
    },
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Mark unread messages as read when component loads
  useEffect(() => {
    if (messages && messages.length > 0) {
      const unreadMessages = messages
        .filter((msg: Message) => !msg.isRead && msg.senderId !== 0) // Assuming admin has ID 0
        .map((msg: Message) => msg.id);
      
      if (unreadMessages.length > 0) {
        markAsReadMutation.mutate(unreadMessages);
      }
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const messageData = {
      senderId: 2, // System operator ID (существующий в базе)
      senderName: "Администратор",
      receiverId: selectedRecipient === "broadcast" ? null : parseInt(selectedRecipient),
      message: newMessage,
      messageType: selectedRecipient === "broadcast" ? "broadcast" : "direct",
    };

    sendMessageMutation.mutate(messageData);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getMessageTime = (timestamp: string) => {
    return format(new Date(timestamp), 'HH:mm');
  };

  const getMessageDate = (timestamp: string) => {
    return format(new Date(timestamp), 'dd.MM.yyyy');
  };

  if (operatorsLoading || messagesLoading) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin" />
            <span className="ml-2">Загрузка чата...</span>
          </div>
        </div>
      </div>
    );
  }

  const onlineOperators = operators?.filter((op: Operator) => op.isOnline) || [];
  const totalOperators = operators?.length || 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Чат с операторами</h1>
            <p className="mt-2 text-gray-600">
              Общение с операторами в реальном времени
            </p>
          </div>
          <Button
            variant="outline"
            onClick={() => {
              queryClient.invalidateQueries({ queryKey: ['/api/operator-messages'] });
              queryClient.invalidateQueries({ queryKey: ['/api/operators'] });
            }}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Обновить
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Operators List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Операторы
                <Badge variant="secondary">
                  {onlineOperators.length}/{totalOperators}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-3 border rounded-lg bg-blue-50">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="font-medium">Всем операторам</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Массовая рассылка</p>
                </div>
                
                {operators?.map((operator: Operator) => (
                  <div 
                    key={operator.id} 
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="text-xs">
                          {operator.firstName?.[0]}{operator.lastName?.[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-sm">
                          {operator.firstName} {operator.lastName}
                        </p>
                        <p className="text-xs text-gray-500">
                          Окно {operator.windowNumber}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${operator.isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                      <Badge variant={operator.role === 'admin' ? 'default' : 'secondary'} className="text-xs">
                        {operator.role === 'admin' ? 'Админ' : 'Оператор'}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Chat Messages */}
          <Card className="lg:col-span-3">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Сообщения
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col h-96">
              {/* Messages Area */}
              <div className="flex-1 overflow-y-auto p-4 bg-gray-50 rounded-lg mb-4 space-y-4">
                {messages && messages.length > 0 ? (
                  messages.map((message: Message, index: number) => {
                    const showDate = index === 0 || 
                      getMessageDate(message.createdAt) !== getMessageDate(messages[index - 1]?.createdAt);
                    
                    return (
                      <div key={message.id}>
                        {showDate && (
                          <div className="text-center text-xs text-gray-500 my-2">
                            {getMessageDate(message.createdAt)}
                          </div>
                        )}
                        
                        <div className="flex items-start space-x-3">
                          <Avatar className="w-8 h-8">
                            <AvatarFallback className="text-xs">
                              {message.senderName === 'Администратор' ? 'А' : 
                               message.senderName?.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-sm">
                                {message.senderName}
                              </span>
                              {message.messageType === 'broadcast' && (
                                <Badge variant="outline" className="text-xs">
                                  Всем
                                </Badge>
                              )}
                              {message.receiverId && (
                                <Badge variant="secondary" className="text-xs">
                                  → Приватное
                                </Badge>
                              )}
                              <span className="text-xs text-gray-500">
                                {getMessageTime(message.createdAt)}
                              </span>
                            </div>
                            
                            <div className="bg-white p-3 rounded-lg shadow-sm">
                              <p className="text-sm whitespace-pre-wrap">{message.message}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-500">
                    <div className="text-center">
                      <MessageSquare className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>Пока нет сообщений</p>
                      <p className="text-sm">Начните общение с операторами</p>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input */}
              <div className="space-y-3">
                <Select value={selectedRecipient} onValueChange={setSelectedRecipient}>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите получателя" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="broadcast">Всем операторам</SelectItem>
                    {operators?.map((operator: Operator) => (
                      <SelectItem key={operator.id} value={operator.id.toString()}>
                        {operator.firstName} {operator.lastName} (Окно {operator.windowNumber})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="flex gap-2">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Введите сообщение..."
                    className="flex-1"
                    disabled={sendMessageMutation.isPending}
                  />
                  <Button 
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim() || sendMessageMutation.isPending}
                  >
                    {sendMessageMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}