import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
// Navigation removed for security - no access to other parts of system
import { Ticket, Key, List, ChevronRight, Printer, Settings } from "lucide-react";

export default function Terminal() {
  const { toast } = useToast();
  const [mode, setMode] = useState<'select' | 'service' | 'pin' | 'printing'>('select');
  const [selectedService, setSelectedService] = useState<any>(null);
  const [pinCode, setPinCode] = useState('');
  const [newTicket, setNewTicket] = useState<any>(null);

  // Генерируем стабильный ID терминала (принудительно новый формат)
  const [terminalId] = useState(() => {
    // Удаляем старые ID с проблемными символами
    const oldId = localStorage.getItem('terminal_id');
    if (oldId && (oldId.includes('(') || oldId.includes(')') || oldId.includes('/'))) {
      localStorage.removeItem('terminal_id');
    }
    
    let id = localStorage.getItem('terminal_id');
    if (!id) {
      // Создаем простой уникальный ID без специальных символов
      id = `terminal_${Math.random().toString(36).substr(2, 9)}_${Date.now()}`;
      localStorage.setItem('terminal_id', id);
    }
    console.log('Terminal ID:', id);
    return id;
  });
  
  const [isRedirecting, setIsRedirecting] = useState(false);
  
  const { data: terminalConfig } = useQuery({
    queryKey: ['/api/terminal-settings', terminalId],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/terminal-settings/${terminalId}`);
        if (response.status === 404) {
          // Если настройки не найдены, перенаправляем на страницу настройки
          console.log('Настройки терминала не найдены, переходим к настройке');
          setIsRedirecting(true);
          window.location.href = '/terminal-setup';
          return null;
        }
        if (!response.ok) throw new Error('Failed to fetch');
        return response.json();
      } catch (error) {
        setIsRedirecting(true);
        window.location.href = '/terminal-setup';
        return null;
      }
    },
    enabled: !isRedirecting,
    retry: false
  });

  const { data: services = [] } = useQuery({
    queryKey: ['/api/services', terminalConfig?.departmentId],
    queryFn: async () => {
      if (!terminalConfig || !terminalConfig.departmentId) {
        return [];
      }
      // Получаем только услуги для данного отделения
      const response = await fetch(`/api/services?departmentId=${terminalConfig.departmentId}`);
      return response.json();
    },
    enabled: !!terminalConfig?.departmentId && !isRedirecting
  });

  const { data: activeTickets = [] } = useQuery({
    queryKey: ['/api/tickets?status=active'],
    queryFn: async () => {
      const response = await fetch('/api/tickets?status=active');
      return response.json();
    },
    enabled: !isRedirecting
  });

  const createTicketMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/tickets', data);
      return response.json();
    },
    onSuccess: (ticket) => {
      console.log('Ticket created successfully:', ticket);
      setNewTicket(ticket);
      setMode('printing');
      // Автоматическая печать талона
      printTicket(ticket);
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
      
      // Возврат к главному экрану через настроенное время
      const displayTime = (terminalConfig?.displayTimeSeconds || 10) * 1000; // Увеличил время показа
      setTimeout(() => {
        setMode('select');
        setSelectedService(null);
        setNewTicket(null);
      }, displayTime);
    },
    onError: (error) => {
      console.error('Ticket creation error:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось выдать талон",
        variant: "destructive",
      });
    },
  });

  const validatePinMutation = useMutation({
    mutationFn: async (pin: string) => {
      const response = await apiRequest('GET', `/api/appointments/pin/${pin}`);
      return response.json();
    },
    onSuccess: (appointment) => {
      // Создаем талон для записи
      createTicketMutation.mutate({
        serviceId: appointment.serviceId,
        departmentId: appointment.departmentId,
        appointmentId: appointment.id,
        status: 'waiting',
      });
      setPinCode('');
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Неверный PIN-код или запись не найдена",
        variant: "destructive",
      });
      setPinCode('');
    },
  });

  const handleServiceSelect = (service: any) => {
    console.log('Service selected:', service);
    setSelectedService(service);
    // Создаем талон для выбранной услуги
    const ticketData = {
      serviceId: service.id,
      departmentId: service.departmentId || terminalConfig?.departmentId,
      status: 'waiting',
    };
    console.log('Creating ticket with data:', ticketData);
    createTicketMutation.mutate(ticketData);
  };

  const handlePinSubmit = () => {
    // Проверяем на специальный код для настройки
    if (pinCode.trim() === '2025') {
      // Сбрасываем ID и настройки для повторной настройки
      localStorage.removeItem('terminal_id');
      queryClient.clear();
      window.location.href = '/terminal-setup';
      return;
    }

    if (pinCode.trim()) {
      validatePinMutation.mutate(pinCode.trim());
    }
  };

  const printTicket = async (ticket: any) => {
    console.log('Printing ticket:', ticket);
    
    try {
      // Отправляем команду на печать на сервер
      const response = await fetch('/api/print-ticket', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ticketData: {
            ticketNumber: ticket.ticketNumber,
            serviceName: selectedService?.name || ticket.serviceName || 'Услуга',
            queuePosition: activeTickets.length + 1,
            estimatedWaitTime: selectedService?.estimatedTime || 15,
            issuedAt: new Date().toLocaleString('ru-RU'),
            terminalId: terminalId
          }
        })
      });

      if (response.ok) {
        const result = await response.json();
        toast({
          title: "Талон напечатан",
          description: `Талон ${ticket.ticketNumber} отправлен на печать`,
          duration: 3000,
        });
      } else {
        throw new Error('Ошибка печати');
      }
    } catch (error) {
      console.error('Print error:', error);
      toast({
        title: "Талон готов",
        description: `Талон ${ticket.ticketNumber} для услуги "${selectedService?.name || 'Выбранная услуга'}"`,
        duration: 3000,
      });
    }
  };

  // Если происходит редирект, показываем сообщение
  if (isRedirecting) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-900 mx-auto mb-4"></div>
          <p className="text-gray-600">Переход к настройке...</p>
        </div>
      </div>
    );
  }

  // Если терминал не настроен, показываем загрузку
  if (!terminalConfig) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Настройка терминала...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100" 
         style={{ backgroundColor: terminalConfig.backgroundColor || '#ffffff' }}>
      {/* Navigation removed for security */}
      

      
      {/* Header */}
      <div className="text-center py-8">
        <h1 className="text-4xl font-bold" 
            style={{ color: terminalConfig.textColor || '#000000' }}>
          {terminalConfig.organizationName || 'ЭЛЕКТРОННАЯ ОЧЕРЕДЬ'}
        </h1>
        <p className="text-lg mt-2 text-gray-600">
          Выберите способ получения талона
        </p>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 pb-8">
        {mode === 'select' && (
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Услуги */}
            <Card className="p-8 hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setMode('service')}>
              <CardContent className="text-center">
                <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6"
                     style={{ backgroundColor: `${terminalConfig.accentColor}20` }}>
                  <List className="w-10 h-10" 
                        style={{ color: terminalConfig.accentColor || '#0079F2' }} />
                </div>
                <h2 className="text-2xl font-semibold mb-4">Выбрать услугу</h2>
                <p className="text-gray-600 mb-6">
                  Выберите нужную услугу из списка доступных
                </p>
                <Button className="w-full" size="lg">
                  <ChevronRight className="w-5 h-5 ml-2" />
                  Продолжить
                </Button>
              </CardContent>
            </Card>

            {/* PIN-код */}
            <Card className="p-8 hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setMode('pin')}>
              <CardContent className="text-center">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Key className="w-10 h-10 text-green-600" />
                </div>
                <h2 className="text-2xl font-semibold mb-4">У меня есть PIN</h2>
                <p className="text-gray-600 mb-6">
                  Введите PIN-код из предварительной записи
                </p>
                <Button className="w-full" size="lg" variant="outline">
                  <ChevronRight className="w-5 h-5 ml-2" />
                  Ввести PIN
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {mode === 'service' && (
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <Button 
                variant="outline" 
                onClick={() => setMode('select')}
                className="mb-4"
              >
                ← Назад
              </Button>
              <h2 className="text-2xl font-semibold">Выберите услугу</h2>
            </div>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {(services as any[]).map((service: any) => (
                <Card 
                  key={service.id}
                  className="p-6 hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => handleServiceSelect(service)}
                >
                  <CardContent>
                    <h3 className="font-semibold mb-2">{service.name}</h3>
                    <p className="text-sm text-gray-600 mb-4">{service.description}</p>
                    <p className="text-sm">
                      Время ожидания: ~{service.estimatedTime || 15} мин
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {(services as any[]).length === 0 && (
              <div className="text-center py-12">
                <p className="text-lg text-gray-500">Нет доступных услуг для данного отделения</p>
              </div>
            )}
          </div>
        )}

        {mode === 'pin' && (
          <div className="max-w-md mx-auto">
            <div className="mb-6">
              <Button 
                variant="outline" 
                onClick={() => setMode('select')}
                className="mb-4"
              >
                ← Назад
              </Button>
            </div>

            <Card className="p-8">
              <CardContent>
                <div className="text-center mb-6">
                  <Key className="w-16 h-16 text-green-600 mx-auto mb-4" />
                  <h2 className="text-xl font-semibold mb-2">Введите PIN-код</h2>
                  <p className="text-gray-600">
                    Введите PIN-код из SMS или электронной почты
                  </p>
                </div>

                <div className="space-y-4">
                  <Input
                    type="text"
                    placeholder="Введите PIN-код"
                    value={pinCode}
                    onChange={(e) => setPinCode(e.target.value.toUpperCase())}
                    className="text-center text-xl"
                    maxLength={8}
                    data-testid="input-pin-code"
                  />
                  
                  <Button
                    onClick={handlePinSubmit}
                    disabled={!pinCode.trim() || validatePinMutation.isPending}
                    className="w-full"
                    size="lg"
                    data-testid="button-validate-pin"
                  >
                    {validatePinMutation.isPending ? "Проверка..." : "Получить талон"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {mode === 'printing' && newTicket && (
          <div className="max-w-md mx-auto text-center">
            <Card className="p-8 border-2 border-green-200 shadow-lg">
              <CardContent>
                <div className="mb-6">
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                    <Ticket className="w-10 h-10 text-green-600" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2 text-green-700">Талон выдан успешно!</h2>
                </div>

                <div className="bg-gradient-to-br from-blue-50 to-green-50 p-8 rounded-lg mb-6 border-2 border-dashed border-green-300">
                  <div className="text-6xl font-bold mb-4" 
                       style={{ color: terminalConfig.accentColor || '#0079F2' }}>
                    {newTicket.ticketNumber}
                  </div>
                  <p className="text-xl font-semibold mb-2">{selectedService?.name}</p>
                  <p className="text-lg text-gray-700 mb-2">
                    Время выдачи: {new Date().toLocaleTimeString()}
                  </p>
                  <p className="text-lg text-gray-700">
                    Дата: {new Date().toLocaleDateString()}
                  </p>
                </div>

                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200 mb-4">
                  <p className="text-lg font-semibold text-gray-800">
                    📢 Ожидайте вызова на табло
                  </p>
                </div>

                {(activeTickets as any[]).length > 0 && (
                  <p className="text-lg text-blue-600 font-medium">
                    Перед вами в очереди: {(activeTickets as any[]).length} человек
                  </p>
                )}

                <div className="mt-6 p-4 bg-gray-100 rounded-lg">
                  <p className="text-sm text-gray-600">
                    Возврат к главному экрану через {terminalConfig?.displayTimeSeconds || 10} секунд...
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}