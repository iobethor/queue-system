import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { CalendarCheck, CheckCircle, Clock, User } from "lucide-react";

const bookingSchema = z.object({
  serviceId: z.number(),
  departmentId: z.number(),
  clientName: z.string().min(2, "ФИО должно содержать минимум 2 символа"),
  clientPhone: z.string().min(10, "Некорректный номер телефона"),
  clientEmail: z.string().email("Некорректный email").optional().or(z.literal("")),
  appointmentDate: z.string(),
  appointmentTime: z.string(),
  additionalInfo: z.string().optional(),
  notifySms: z.boolean().default(false),
  notifyEmail: z.boolean().default(false),
});

type BookingForm = z.infer<typeof bookingSchema>;

export default function Booking() {
  const { toast } = useToast();
  const [createdAppointment, setCreatedAppointment] = useState<any>(null);

  // 1. Перенесите инициализацию формы НАВЕРХ
  const form = useForm<BookingForm>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      appointmentDate: new Date().toISOString().split("T")[0],
      notifySms: false,
      notifyEmail: false,
    },
  });

  // 2. Теперь можно использовать form.watch()
  const selectedDepartmentId = form.watch("departmentId");
  const selectedDate = form.watch("appointmentDate");

  // 3. Остальные хуки (useQuery) - после формы
  const { data: departments } = useQuery({
    queryKey: ["/api/departments"],
  });

  const { data: services } = useQuery({
    queryKey: ["/api/services"],
  });
  // Fetch department schedule when department is selected
  const { data: departmentSchedule } = useQuery({
    queryKey: ['/api/departments', selectedDepartmentId, 'schedule'],
    queryFn: async () => {
      if (!selectedDepartmentId) return null;
      const response = await fetch(`/api/departments/${selectedDepartmentId}`);
      return response.json();
    },
    enabled: !!selectedDepartmentId,
  });

  // Generate time slots based on department schedule
  const generateTimeSlots = () => {
    if (!departmentSchedule || !selectedDate) {
      // Default fallback slots
      return [
        "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", 
        "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", 
        "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", 
        "17:00", "17:30"
      ];
    }

    const date = new Date(selectedDate);
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayName = dayNames[date.getDay()];

    const schedule = departmentSchedule.workSchedule?.[dayName];
    if (!schedule?.isWorkingDay) {
      return []; // No slots for non-working days
    }

    const startTime = schedule.startTime || '09:00';
    const endTime = schedule.endTime || '18:00';

    // Generate 30-minute slots between start and end time
    const slots = [];
    let currentTime = new Date(`2024-01-01T${startTime}:00`);
    const endDateTime = new Date(`2024-01-01T${endTime}:00`);

    while (currentTime < endDateTime) {
      const timeString = currentTime.toTimeString().slice(0, 5);
      slots.push(timeString);
      currentTime.setMinutes(currentTime.getMinutes() + 30);
    }

    return slots;
  };

  const availableTimeSlots = generateTimeSlots();



  

  const createAppointmentMutation = useMutation({
    mutationFn: async (data: BookingForm) => {
      // Check working hours before creating appointment
      try {
        const checkResponse = await fetch(`/api/departments/${data.departmentId}/is-working`);
        const workingStatus = await checkResponse.json();

        if (!workingStatus.isWorking) {
          let reason = 'Отделение сейчас не работает';
          switch (workingStatus.reason) {
            case 'holiday':
              reason = 'Сегодня праздничный день';
              break;
            case 'non_working_day':
              reason = 'Сегодня выходной день';
              break;
            case 'outside_hours':
              reason = 'Отделение закрыто (вне рабочих часов)';
              break;
          }
          throw new Error(reason);
        }
      } catch (error) {
        // If working hours check fails, continue with booking but log the error
        console.warn('Could not check working hours:', error);
      }

      const response = await apiRequest('POST', '/api/appointments', data);
      return response.json();
    },
    onSuccess: (appointment) => {
      setCreatedAppointment(appointment);
      toast({
        title: "Запись создана!",
        description: `PIN-код: ${appointment.pinCode}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать запись",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BookingForm) => {
    createAppointmentMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Изолированный заголовок без навигации */}
      <div className="bg-white shadow-lg border-b-2 border-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center h-16">
            <div className="text-center">
              <div className="flex items-center justify-center gap-3">
                <CalendarCheck className="h-8 w-8 text-blue-600" />
                <h1 className="text-2xl font-bold text-gray-900">Веб-запись на прием</h1>
              </div>
              <p className="text-sm text-gray-600 mt-1">Roskazna • Большая Марьянская 9/1</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-4 sm:mb-6 text-center">
          <p className="text-lg text-gray-700">Предварительная запись клиентов через интернет</p>
          <p className="text-sm text-gray-500 mt-2">Заполните форму ниже для записи на прием</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Booking Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Форма записи</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="serviceId">Выберите услугу</Label>
                      <Select onValueChange={(value) => form.setValue('serviceId', parseInt(value))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите услугу" />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.isArray(services) && services.map((service: any) => (
                            <SelectItem key={service.id} value={service.id.toString()}>
                              {service.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="departmentId">Отделение</Label>
                      <Select onValueChange={(value) => form.setValue('departmentId', parseInt(value))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите отделение" />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.isArray(departments) && departments.map((dept: any) => (
                            <SelectItem key={dept.id} value={dept.id.toString()}>
                              {dept.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="appointmentDate">Дата</Label>
                      <Input
                        id="appointmentDate"
                        type="date"
                        {...form.register('appointmentDate')}
                        min={new Date().toISOString().split('T')[0]}
                        onChange={(e) => {
                          const dateValue = e.target.value;
                          form.setValue('appointmentDate', dateValue);

                          // Clear time selection when date changes
                          form.setValue('appointmentTime', '');

                          // Check if selected date is a working day based on department schedule
                          if (departmentSchedule && dateValue) {
                            const selectedDate = new Date(dateValue);
                            const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
                            const dayName = dayNames[selectedDate.getDay()];
                            const schedule = departmentSchedule.workSchedule?.[dayName];

                            if (!schedule?.isWorkingDay) {
                              toast({
                                title: "Выходной день",
                                description: "Выберите рабочий день согласно расписанию отделения",
                                variant: "destructive",
                              });
                            }
                          }
                        }}
                      />
                    </div>
                    <div>
                      <Label htmlFor="appointmentTime">Время</Label>
                      <Select onValueChange={(value) => form.setValue('appointmentTime', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите время" />
                        </SelectTrigger>
                        <SelectContent>
                          {availableTimeSlots.length > 0 ? (
                            availableTimeSlots.map((time) => (
                              <SelectItem key={time} value={time}>
                                {time} - свободно
                              </SelectItem>
                            ))
                          ) : (
                            <SelectItem value="" disabled>
                              {selectedDepartmentId && selectedDate ? 'Выходной день' : 'Выберите отделение и дату'}
                            </SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="clientName">ФИО</Label>
                    <Input
                      id="clientName"
                      placeholder="Иванов Иван Иванович"
                      {...form.register('clientName')}
                    />
                    {form.formState.errors.clientName && (
                      <p className="text-sm text-red-500 mt-1">{form.formState.errors.clientName.message}</p>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="clientPhone">Телефон</Label>
                      <Input
                        id="clientPhone"
                        placeholder="+7 (999) 123-45-67"
                        {...form.register('clientPhone')}
                      />
                      {form.formState.errors.clientPhone && (
                        <p className="text-sm text-red-500 mt-1">{form.formState.errors.clientPhone.message}</p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="clientEmail">Email (необязательно)</Label>
                      <Input
                        id="clientEmail"
                        type="email"
                        placeholder="ivan@example.com"
                        {...form.register('clientEmail')}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="additionalInfo">Дополнительная информация</Label>
                    <Textarea
                      id="additionalInfo"
                      placeholder="Укажите детали вашего вопроса..."
                      {...form.register('additionalInfo')}
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="notifyEmail"
                        checked={form.watch('notifyEmail')}
                        onCheckedChange={(checked) => form.setValue('notifyEmail', !!checked)}
                      />
                      <Label htmlFor="notifyEmail">Получать Email уведомления</Label>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={createAppointmentMutation.isPending}
                  >
                    <CalendarCheck className="mr-2 h-4 w-4" />
                    {createAppointmentMutation.isPending ? 'Создание записи...' : 'Записаться на прием'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Booking Info */}
          <div className="space-y-6">
            {createdAppointment && (
              <Card className="border-green-200 bg-green-50">
                <CardHeader>
                  <CardTitle className="text-green-800">Запись создана!</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-green-700">PIN-код:</span>
                      <span className="font-bold text-lg">{createdAppointment.pinCode}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-700">Дата:</span>
                      <span className="font-medium">{createdAppointment.appointmentDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-700">Время:</span>
                      <span className="font-medium">{createdAppointment.appointmentTime}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle className="text-blue-800">Информация о записи</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-blue-700">Доступные слоты:</span>
                    <span className="font-medium">15 из 20</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-700">Время обслуживания:</span>
                    <span className="font-medium">≈ 15 мин</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Инструкции для записи</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Заполните все обязательные поля формы</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-blue-500" />
                    <span>Сохраните PIN-код для подтверждения записи</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-purple-500" />
                    <span>Приходите за 10 минут до назначенного времени</span>
                  </div>
                </div>

              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
