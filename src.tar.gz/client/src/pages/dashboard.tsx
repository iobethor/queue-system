
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Navigation from "@/components/layout/navigation";
import { 
  Users, CheckCircle, Clock, Bot, 
  CalendarPlus, Monitor, Headset, Tv, Settings, Calendar
} from "lucide-react";

export default function Dashboard() {
  const { data: statistics } = useQuery({
    queryKey: ['/api/statistics'],
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['/api/appointments'],
  });

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Панель управления системой</h1>
          <p className="mt-2 text-sm sm:text-base text-gray-600">Центральное управление электронной очередью с интеграцией ИИ</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 sm:gap-6 mb-6 sm:mb-8">
          <Card className="border-l-4 border-primary">
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Users className="h-8 w-8 text-primary" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">В очереди сейчас</p>
                  <p className="text-2xl font-bold text-gray-900">{(statistics as any)?.activeQueue || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-green-500">
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <CheckCircle className="h-8 w-8 text-green-500" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Обслужено сегодня</p>
                  <p className="text-2xl font-bold text-gray-900">{(statistics as any)?.completedToday || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-yellow-500">
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Clock className="h-8 w-8 text-yellow-500" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Среднее время ожидания</p>
                  <p className="text-2xl font-bold text-gray-900">{(statistics as any)?.averageWaitTime || 0} мин</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-cyan-500">
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Bot className="h-8 w-8 text-cyan-500" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">ИИ помощник</p>
                  <p className="text-2xl font-bold text-gray-900">Активен</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Link href="/hall-admin">
            <Card className="border-l-4 border-purple-500 hover:bg-gray-50 cursor-pointer transition-colors" data-testid="card-appointments">
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Calendar className="h-8 w-8 text-purple-500" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Предварительные записи</p>
                    <p className="text-2xl font-bold text-gray-900">{(appointments as any[])?.length || 0}</p>
                    <p className="text-xs text-gray-500 mt-1">Нажмите для управления</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Module Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <CalendarPlus className="h-8 w-8 text-primary mr-4" />
                <h3 className="text-xl font-semibold text-gray-900">Веб-запись</h3>
              </div>
              <p className="text-gray-600 mb-4">Предварительная запись клиентов через веб-интерфейс с выбором услуг и времени</p>
              <Link href="/booking">
                <Button className="w-full bg-primary hover:bg-blue-700">
                  Открыть модуль
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Monitor className="h-8 w-8 text-green-500 mr-4" />
                <h3 className="text-xl font-semibold text-gray-900">Терминал</h3>
              </div>
              <p className="text-gray-600 mb-4">Выдача талонов для клиентов на месте с поддержкой PIN-кодов и QR</p>
              <Link href="/terminal">
                <Button className="w-full bg-green-500 hover:bg-green-600">
                  Открыть модуль
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Headset className="h-8 w-8 text-yellow-500 mr-4" />
                <h3 className="text-xl font-semibold text-gray-900">Рабочее место</h3>
              </div>
              <p className="text-gray-600 mb-4">Интерфейс оператора для управления очередью и обслуживания клиентов</p>
              <Link href="/operator">
                <Button className="w-full bg-yellow-500 hover:bg-yellow-600">
                  Открыть модуль
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Tv className="h-8 w-8 text-red-500 mr-4" />
                <h3 className="text-xl font-semibold text-gray-900">Информационное табло</h3>
              </div>
              <p className="text-gray-600 mb-4">Публичное табло для отображения текущей очереди и вызовов</p>
              <Link href="/display">
                <Button className="w-full bg-red-500 hover:bg-red-600">
                  Открыть модуль
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Users className="h-8 w-8 text-purple-500 mr-4" />
                <h3 className="text-xl font-semibold text-gray-900">Администратор зала</h3>
              </div>
              <p className="text-gray-600 mb-4">Управление предварительными записями и выдача талонов клиентам</p>
              <Link href="/hall-admin">
                <Button className="w-full bg-purple-500 hover:bg-purple-600">
                  Открыть модуль
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Settings className="h-8 w-8 text-gray-500 mr-4" />
                <h3 className="text-xl font-semibold text-gray-900">Администрирование</h3>
              </div>
              <p className="text-gray-600 mb-4">Настройка системы, управление пользователями и анализ данных с ИИ</p>
              <Link href="/admin">
                <Button className="w-full bg-gray-500 hover:bg-gray-600">
                  Открыть модуль
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}