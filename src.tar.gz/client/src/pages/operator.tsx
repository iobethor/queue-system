import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Navigation from "@/components/layout/navigation";
import { useWebSocket } from "@/hooks/use-websocket";
import { useSound } from "@/hooks/use-sound";
import { speechService } from "@/services/speechService";
import { 
  Play, Check, RotateCcw, ArrowRightLeft, 
  Phone, Pause, AlertTriangle, Star, LogIn,
  MessageCircle, Send, Clock, FileText, Mail, MailOpen
} from "lucide-react";

export default function Operator() {
  const { toast } = useToast();
  const { playSound } = useSound();
  const [currentTicket, setCurrentTicket] = useState<any>(null);
  const [operatorId, setOperatorId] = useState<number | null>(null);
  const [showLoginDialog, setShowLoginDialog] = useState(true);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [windowNumber, setWindowNumber] = useState('');
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<number | null>(null);
  const [transferTicketId, setTransferTicketId] = useState<number | null>(null);
  const [showTransferDialog, setShowTransferDialog] = useState(false);
  const [targetOperatorId, setTargetOperatorId] = useState<number | null>(null);
  
  // States for break management
  const [showBreakDialog, setShowBreakDialog] = useState(false);
  const [breakReason, setBreakReason] = useState('');
  const [isOnBreak, setIsOnBreak] = useState(false);
  
  // States for mini-chat
  const [showChatDialog, setShowChatDialog] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [chatReceiverId, setChatReceiverId] = useState<number | null>(null);
  
  // States for message center
  const [showMessageDialog, setShowMessageDialog] = useState(false);
  const [unreadMessagesCount, setUnreadMessagesCount] = useState(0);
  const [operatorReplyMessage, setOperatorReplyMessage] = useState('');
  
  // WebSocket подключение для real-time обновлений
  useWebSocket('operator', operatorId || 0);

  const { data: activeTickets } = useQuery({
    queryKey: ['/api/tickets?status=active', selectedDepartmentId],
    queryFn: () => {
      const url = selectedDepartmentId 
        ? `/api/tickets?status=active&departmentId=${selectedDepartmentId}`
        : '/api/tickets?status=active';
      return fetch(url).then(res => res.json());
    },
    refetchInterval: 5000,
    enabled: !!operatorId && !!selectedDepartmentId,
  });

  const { data: operator } = useQuery({
    queryKey: ['/api/operators', operatorId],
    queryFn: () => fetch(`/api/operators/${operatorId}`).then(res => res.json()),
    enabled: !!operatorId,
  });

  const { data: allOperators } = useQuery({
    queryKey: ['/api/operators'],
    queryFn: () => fetch('/api/operators').then(res => res.json()),
    enabled: !!operatorId,
    refetchInterval: 10000,
  });

  // Query for operator status
  const { data: operatorStatus } = useQuery({
    queryKey: ['/api/operator-status', operatorId],
    refetchInterval: 10000,
    enabled: !!operatorId,
  });

  // Query for chat messages
  const { data: chatMessages } = useQuery({
    queryKey: ['/api/operator-chat', operatorId],
    refetchInterval: 5000,
    enabled: !!operatorId && showChatDialog,
  });

  // Query for unread messages count
  const { data: unreadMessages } = useQuery({
    queryKey: ['/api/operator-messages/unread', operatorId],
    queryFn: async () => {
      const response = await fetch(`/api/operator-messages/unread/${operatorId}`);
      return response.json();
    },
    refetchInterval: 3000,
    enabled: !!operatorId,
  });

  // Query for operator messages
  const { data: operatorMessages } = useQuery({
    queryKey: ['/api/operator-messages', operatorId],
    queryFn: async () => {
      const response = await fetch(`/api/operator-messages/${operatorId}`);
      return response.json();
    },
    refetchInterval: 5000,
    enabled: !!operatorId,
  });

  // Update unread messages count
  useEffect(() => {
    if (unreadMessages) {
      setUnreadMessagesCount(unreadMessages.count || 0);
    }
  }, [unreadMessages]);

  // Mark messages as read mutation
  const markMessagesAsReadMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('PUT', `/api/operator-messages/read/${operatorId}`, {});
      return response.json();
    },
    onSuccess: () => {
      setUnreadMessagesCount(0);
      queryClient.invalidateQueries({ queryKey: ['/api/operator-messages/unread', operatorId] });
      queryClient.invalidateQueries({ queryKey: ['/api/operator-messages', operatorId] });
      toast({
        title: "Сообщения отмечены как прочитанные",
      });
    },
  });

  // Send reply to admin mutation
  const sendReplyMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest('POST', '/api/operator-messages/send', {
        senderId: operatorId,
        message: message
      });
      return response.json();
    },
    onSuccess: () => {
      setOperatorReplyMessage('');
      toast({
        title: "Сообщение отправлено",
        description: "Ваш ответ отправлен администратору зала",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка отправки",
        description: "Не удалось отправить сообщение администратору зала",
        variant: "destructive",
      });
    },
  });

  const handleSendReplyToAdmin = () => {
    if (operatorReplyMessage.trim()) {
      sendReplyMutation.mutate(operatorReplyMessage.trim());
    }
  };

  // Query for departments (для выбора в форме авторизации)
  const { data: departments } = useQuery({
    queryKey: ['/api/departments'],
    enabled: showLoginDialog,
  });

  // Update break status based on operator status
  useEffect(() => {
    if (operatorStatus) {
      setIsOnBreak(operatorStatus.status === 'break');
    }
  }, [operatorStatus]);

  const loginMutation = useMutation({
    mutationFn: async ({ username, password, windowNumber, departmentId }: { username: string; password: string; windowNumber: number; departmentId: number }) => {
      const response = await apiRequest('POST', '/api/operators/login', { 
        username, 
        passwordHash: password,
        windowNumber,
        departmentId
      });
      return response.json();
    },
    onSuccess: (operatorData) => {
      setOperatorId(operatorData.id);
      setShowLoginDialog(false);
      toast({
        title: "Вход выполнен",
        description: `Добро пожаловать, ${operatorData.firstName} ${operatorData.lastName}`,
      });
    },
    onError: () => {
      toast({
        title: "Ошибка входа",
        description: "Неверные данные авторизации",
        variant: "destructive",
      });
    },
  });

  // Break management mutations
  const takeBreakMutation = useMutation({
    mutationFn: async (reason: string) => {
      const response = await apiRequest('POST', `/api/operator-status/${operatorId}/break`, { reason });
      return response.json();
    },
    onSuccess: () => {
      setIsOnBreak(true);
      setShowBreakDialog(false);
      setBreakReason('');
      toast({
        title: "Перерыв начат",
        description: "Вы находитесь на перерыве. Новые клиенты не будут назначены.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/operator-status'] });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось начать перерыв",
        variant: "destructive",
      });
    },
  });

  const endBreakMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', `/api/operator-status/${operatorId}/end-break`, {});
      return response.json();
    },
    onSuccess: () => {
      setIsOnBreak(false);
      toast({
        title: "Перерыв завершен",
        description: "Вы снова доступны для обслуживания клиентов",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/operator-status'] });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось завершить перерыв",
        variant: "destructive",
      });
    },
  });

  // Chat message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ receiverId, message }: { receiverId: number; message: string }) => {
      const response = await apiRequest('POST', '/api/operator-chat', {
        senderId: operatorId,
        receiverId,
        message,
        messageType: 'text'
      });
      return response.json();
    },
    onSuccess: () => {
      setChatMessage('');
      toast({
        title: "Сообщение отправлено",
        description: "Ваше сообщение доставлено коллеге",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/operator-chat'] });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось отправить сообщение",
        variant: "destructive",
      });
    },
  });

  const callTicketMutation = useMutation({
    mutationFn: async (ticketId: number) => {
      const response = await apiRequest('POST', `/api/tickets/${ticketId}/call`, {
        operatorId: operatorId,
        callType: 'first_call'
      });
      return response.json();
    },
    onSuccess: async (data, ticketId) => {
      // Устанавливаем обновленный талон как текущий
      if (data.ticket) {
        setCurrentTicket(data.ticket);
        playSound('call');
        
        // Голосовое объявление
        try {
          const operatorName = `${(operator as any)?.firstName || ''} ${(operator as any)?.lastName || ''}`.trim();
          await speechService.announceTicket(
            data.ticket.ticketNumber,
            operatorName,
            (operator as any)?.windowNumber
          );
        } catch (error) {
          console.log('Голосовое объявление недоступно:', error);
        }
        
        toast({
          title: "Клиент вызван",
          description: `Талон ${data.ticket.ticketNumber} вызван на окно ${(operator as any)?.windowNumber}`,
        });
      }
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
    },
  });

  const updateTicketMutation = useMutation({
    mutationFn: async ({ ticketId, status }: { ticketId: number; status: string }) => {
      const updateData: any = { status };
      
      if (status === 'serving') {
        updateData.servedAt = true; // Сервер создаст дату
        updateData.operatorId = operatorId;
      } else if (status === 'completed') {
        updateData.completedAt = true; // Сервер создаст дату
        updateData.operatorId = operatorId;
      }
      
      const response = await apiRequest('PUT', `/api/tickets/${ticketId}`, updateData);
      return response.json();
    },
    onSuccess: (data, variables) => {
      if (variables.status === 'completed') {
        setCurrentTicket(null);
        toast({
          title: "Обслуживание завершено",
          description: "Клиент обслужен",
        });
      } else if (variables.status === 'serving') {
        setCurrentTicket(data.ticket || data);
        toast({
          title: "Обслуживание начато",
          description: "Клиент находится на обслуживании",
        });
      }
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
    },
  });

  const waitingTickets = (activeTickets as any)?.filter((ticket: any) => ticket.status === 'waiting') || [];
  const inProgressTicket = (activeTickets as any)?.find((ticket: any) => 
    ticket.status === 'in_progress' && ticket.operatorId === operatorId
  );
  const servingTicket = (activeTickets as any)?.find((ticket: any) => 
    ticket.status === 'serving' && ticket.operatorId === operatorId
  );

  const transferTicketMutation = useMutation({
    mutationFn: async ({ ticketId, targetOperatorId }: { ticketId: number; targetOperatorId: number }) => {
      const response = await apiRequest('PUT', `/api/tickets/${ticketId}`, {
        operatorId: targetOperatorId,
        status: 'waiting'
      });
      return response.json();
    },
    onSuccess: () => {
      setCurrentTicket(null); // Убираем из текущего оператора
      setShowTransferDialog(false);
      setTransferTicketId(null);
      setTargetOperatorId(null);
      toast({
        title: "Клиент переадресован",
        description: "Клиент успешно переадресован другому оператору",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
    },
  });

  const handleLogin = () => {
    if (loginUsername && loginPassword && windowNumber && selectedDepartmentId) {
      loginMutation.mutate({ 
        username: loginUsername, 
        password: loginPassword, 
        windowNumber: parseInt(windowNumber),
        departmentId: selectedDepartmentId
      });
    }
  };

  const handleTakeBreak = () => {
    if (!isOnBreak) {
      setShowBreakDialog(true);
    } else {
      endBreakMutation.mutate();
    }
  };

  const handleConfirmBreak = () => {
    takeBreakMutation.mutate(breakReason);
  };

  const handleSendMessage = () => {
    if (chatMessage.trim() && chatReceiverId) {
      sendMessageMutation.mutate({ receiverId: chatReceiverId, message: chatMessage.trim() });
    }
  };

  const handleOpenChat = () => {
    setShowChatDialog(true);
    // По умолчанию выбираем первого доступного оператора
    const firstOperator = (allOperators as any)?.find((op: any) => op.id !== operatorId && op.isActive);
    if (firstOperator) {
      setChatReceiverId(firstOperator.id);
    }
  };

  const handleTransfer = (ticketId: number) => {
    setTransferTicketId(ticketId);
    setShowTransferDialog(true);
  };

  const confirmTransfer = () => {
    if (transferTicketId && targetOperatorId) {
      transferTicketMutation.mutate({ ticketId: transferTicketId, targetOperatorId });
    }
  };

  const handleCallTicket = (ticketId: number) => {
    callTicketMutation.mutate(ticketId);
  };

  const handleStartService = () => {
    if (currentTicket || inProgressTicket) {
      const ticket = currentTicket || inProgressTicket;
      updateTicketMutation.mutate({
        ticketId: ticket.id,
        status: 'serving'
      });
    }
  };

  const handleCompleteService = () => {
    if (currentTicket || inProgressTicket || servingTicket) {
      const ticket = currentTicket || inProgressTicket || servingTicket;
      updateTicketMutation.mutate({
        ticketId: ticket.id,
        status: 'completed'
      });
    }
  };

  const displayTicket = currentTicket || inProgressTicket || servingTicket;

  return (
    <div className="min-h-screen">
      <div className="bg-white shadow-lg border-b-2 border-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-gray-900">Рабочее место оператора</h1>
              {operatorId && operator && (
                <div className="ml-6 text-sm text-gray-600">
                  <span>Оператор: {operator.firstName} {operator.lastName}</span>
                  {operator.windowNumber && (
                    <span className="ml-3">Окно: {operator.windowNumber}</span>
                  )}
                </div>
              )}
            </div>
            
            {operatorId && (
              <div className="flex items-center space-x-3">
                {/* Messages Button */}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowMessageDialog(true)}
                  className="relative"
                  data-testid="button-messages"
                >
                  {unreadMessagesCount > 0 ? (
                    <MailOpen className="h-4 w-4 mr-2 text-orange-600" />
                  ) : (
                    <Mail className="h-4 w-4 mr-2 text-gray-600" />
                  )}
                  Сообщения
                  {unreadMessagesCount > 0 && (
                    <Badge 
                      variant="destructive" 
                      className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
                    >
                      {unreadMessagesCount}
                    </Badge>
                  )}
                </Button>
                
                {/* Status indicator */}
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${
                    isOnBreak ? 'bg-yellow-500' : 'bg-green-500'
                  }`}></div>
                  <span className="text-sm text-gray-600">
                    {isOnBreak ? 'На перерыве' : 'Активен'}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {!operatorId ? (
          <div className="text-center py-8">
            <p className="text-gray-500">Войдите в систему для работы с очередью</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Current Client */}
          <div className="lg:col-span-2">
            <Card className="mb-6">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Текущий клиент</CardTitle>
                  <div className="flex space-x-2">
                    <Badge variant="secondary">Окно {(operator as any)?.windowNumber || '?'}</Badge>
                    {operator && (
                      <Badge variant="outline">{(operator as any)?.firstName} {(operator as any)?.lastName}</Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {displayTicket ? (
                  <>
                    <div className="bg-blue-50 p-6 rounded-lg mb-6 text-center">
                      <h3 className="text-4xl font-bold text-primary mb-2">{displayTicket.ticketNumber}</h3>
                      {/* Здесь можно добавить информацию об услуге */}
                      <p className="text-gray-600">Время в очереди: ~ мин</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-6">
                      {displayTicket.status === 'in_progress' && (
                        <Button 
                          onClick={handleStartService}
                          className="bg-primary hover:bg-blue-700"
                          disabled={updateTicketMutation.isPending}
                        >
                          <Play className="mr-2 h-4 w-4" />
                          Начать обслуживание
                        </Button>
                      )}
                      
                      {displayTicket.status === 'serving' && (
                        <Button 
                          onClick={handleCompleteService}
                          className="bg-green-500 hover:bg-green-600"
                          disabled={updateTicketMutation.isPending}
                        >
                          <Check className="mr-2 h-4 w-4" />
                          Завершить
                        </Button>
                      )}
                      
                      <Button 
                        variant="outline"
                        onClick={() => handleCallTicket(displayTicket.id)}
                        disabled={callTicketMutation.isPending}
                      >
                        <RotateCcw className="mr-2 h-4 w-4" />
                        Повторный вызов
                      </Button>
                      
                      <Button 
                        variant="outline"
                        onClick={() => handleTransfer(displayTicket.id)}
                      >
                        <ArrowRightLeft className="mr-2 h-4 w-4" />
                        Перевести
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-4">Нет активного клиента</p>
                    <p className="text-sm text-gray-400">Вызовите следующего клиента из очереди</p>
                  </div>
                )}

                {/* AI Assistant Placeholder */}
                <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
                  <div className="flex items-center mb-3">
                    <div className="w-6 h-6 bg-cyan-500 rounded-full flex items-center justify-center text-white text-xs mr-2">
                      AI
                    </div>
                    <h4 className="font-semibold text-cyan-700">ИИ-Помощник</h4>
                  </div>
                  <div className="space-y-2 text-sm">
                    <p className="text-gray-700"><strong>Рекомендация:</strong> Для данной услуги потребуется паспорт</p>
                    <p className="text-gray-700"><strong>Среднее время:</strong> 15 минут на обслуживание</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Service Rating */}
            <Card>
              <CardHeader>
                <CardTitle>Оценка обслуживания</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <span className="text-gray-600">Средняя оценка:</span>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <span className="text-lg font-semibold">4.8</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Queue Management */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Очередь</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {waitingTickets.slice(0, 5).map((ticket: any) => (
                    <div key={ticket.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div>
                        <p className="font-medium">{ticket.ticketNumber}</p>
                        <p className="text-sm text-gray-600">Ожидает</p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => handleCallTicket(ticket.id)}
                        disabled={callTicketMutation.isPending}
                      >
                        <Phone className="mr-1 h-3 w-3" />
                        Вызвать
                      </Button>
                    </div>
                  ))}
                  
                  {waitingTickets.length === 0 && (
                    <p className="text-center text-gray-500 py-4">Очередь пуста</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Статистика дня</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Обслужено:</span>
                    <span className="font-medium">37</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Среднее время:</span>
                    <span className="font-medium">14 мин</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Оценка:</span>
                    <span className="font-medium">4.8 ⭐</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Быстрые действия</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full justify-start"
                    onClick={handleTakeBreak}
                    disabled={takeBreakMutation.isPending || endBreakMutation.isPending}
                    data-testid="button-take-break"
                  >
                    {isOnBreak ? (
                      <>
                        <Clock className="mr-2 h-4 w-4 text-green-500" />
                        Завершить перерыв
                      </>
                    ) : (
                      <>
                        <Pause className="mr-2 h-4 w-4 text-yellow-500" />
                        Взять перерыв
                      </>
                    )}
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full justify-start"
                    onClick={handleOpenChat}
                    data-testid="button-open-chat"
                  >
                    <MessageCircle className="mr-2 h-4 w-4 text-blue-500" />
                    Чат с коллегами
                  </Button>

                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full justify-start relative"
                    onClick={() => setShowMessageDialog(true)}
                    data-testid="button-open-messages"
                  >
                    {unreadMessagesCount > 0 ? (
                      <MailOpen className="mr-2 h-4 w-4 text-red-500" />
                    ) : (
                      <Mail className="mr-2 h-4 w-4 text-blue-500" />
                    )}
                    Сообщения от админа
                    {unreadMessagesCount > 0 && (
                      <Badge variant="destructive" className="ml-auto text-xs px-1 py-0 h-5 min-w-5">
                        {unreadMessagesCount}
                      </Badge>
                    )}
                  </Button>
                </div>
                {isOnBreak && operatorStatus?.breakReason && (
                  <div className="mt-3 p-2 bg-yellow-50 rounded-lg border border-yellow-200">
                    <p className="text-sm text-yellow-700">
                      <strong>На перерыве:</strong> {operatorStatus.breakReason}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          </div>
        )}

        {/* Login Dialog */}
        <Dialog open={showLoginDialog} onOpenChange={() => {}}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Вход в систему</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Имя пользователя</label>
                <Input
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                  placeholder="ivanov"
                  data-testid="input-operator-username-login"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Пароль</label>
                <Input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Введите пароль"
                  data-testid="input-operator-password-login"
                  onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Отделение</label>
                <Select value={selectedDepartmentId?.toString()} onValueChange={(value) => setSelectedDepartmentId(Number(value))}>
                  <SelectTrigger data-testid="select-department-login">
                    <SelectValue placeholder="Выберите отделение" />
                  </SelectTrigger>
                  <SelectContent>
                    {departments?.map((department: any) => (
                      <SelectItem key={department.id} value={department.id.toString()}>
                        {department.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Номер окна</label>
                <Input
                  type="number"
                  value={windowNumber}
                  onChange={(e) => setWindowNumber(e.target.value)}
                  placeholder="1"
                  min="1"
                  max="99"
                  data-testid="input-operator-window-login"
                  onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                />
              </div>
              <Button 
                onClick={handleLogin}
                disabled={loginMutation.isPending || !loginUsername || !loginPassword || !windowNumber || !selectedDepartmentId}
                className="w-full"
                data-testid="button-operator-login"
              >
                <LogIn className="mr-2 h-4 w-4" />
                {loginMutation.isPending ? 'Вход...' : 'Войти'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Transfer Dialog */}
        <Dialog open={showTransferDialog} onOpenChange={setShowTransferDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Переадресация клиента</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Выберите оператора</label>
                <Select onValueChange={(value) => setTargetOperatorId(Number(value))}>
                  <SelectTrigger data-testid="select-target-operator">
                    <SelectValue placeholder="Выберите оператора" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.isArray(allOperators) && (allOperators as any).filter((op: any) => op.id !== operatorId && op.isActive)
                      .map((operator: any) => (
                        <SelectItem key={operator.id} value={operator.id.toString()}>
                          {operator.firstName} {operator.lastName} - Окно {operator.windowNumber}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => setShowTransferDialog(false)}
                  data-testid="button-cancel-transfer"
                >
                  Отмена
                </Button>
                <Button 
                  onClick={confirmTransfer}
                  disabled={!targetOperatorId || transferTicketMutation.isPending}
                  data-testid="button-confirm-transfer"
                >
                  {transferTicketMutation.isPending ? 'Переадресация...' : 'Переадресовать'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Break Dialog */}
        <Dialog open={showBreakDialog} onOpenChange={setShowBreakDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Взять перерыв</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Причина перерыва</label>
                <Textarea
                  value={breakReason}
                  onChange={(e) => setBreakReason(e.target.value)}
                  placeholder="Например: Обеденный перерыв, Технический перерыв..."
                  className="min-h-20"
                  data-testid="textarea-break-reason"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => setShowBreakDialog(false)}
                  data-testid="button-cancel-break"
                >
                  Отмена
                </Button>
                <Button 
                  onClick={handleConfirmBreak}
                  disabled={!breakReason.trim() || takeBreakMutation.isPending}
                  data-testid="button-confirm-break"
                >
                  <Pause className="mr-2 h-4 w-4" />
                  {takeBreakMutation.isPending ? 'Оформление...' : 'Начать перерыв'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Chat Dialog */}
        <Dialog open={showChatDialog} onOpenChange={setShowChatDialog}>
          <DialogContent className="max-w-md max-h-[70vh]">
            <DialogHeader className="pb-2">
              <DialogTitle className="text-lg">Чат с коллегами</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <Select 
                value={chatReceiverId?.toString()} 
                onValueChange={(value) => setChatReceiverId(Number(value))}
              >
                <SelectTrigger className="h-8" data-testid="select-chat-receiver">
                  <SelectValue placeholder="Выберите коллегу" />
                </SelectTrigger>
                <SelectContent>
                  {Array.isArray(allOperators) && (allOperators as any).filter((op: any) => op.id !== operatorId && op.isActive)
                    .map((operator: any) => (
                      <SelectItem key={operator.id} value={operator.id.toString()}>
                        {operator.firstName} {operator.lastName} - Окно {operator.windowNumber}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>

              <div className="border rounded p-2 h-32 overflow-y-auto bg-gray-50 text-sm">
                {(chatMessages as any)?.length > 0 ? (
                  (chatMessages as any).map((msg: any) => (
                    <div 
                      key={msg.id} 
                      className={`mb-2 p-1 rounded text-xs ${
                        msg.senderId === operatorId 
                          ? 'bg-blue-500 text-white ml-4 text-right' 
                          : 'bg-white mr-4'
                      }`}
                    >
                      <p>{msg.message}</p>
                      <p className="text-xs opacity-75">
                        {new Date(msg.createdAt).toLocaleTimeString('ru-RU', {hour: '2-digit', minute: '2-digit'})}
                      </p>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-gray-500 py-6 text-xs">
                    Нет сообщений
                  </p>
                )}
              </div>

              <div className="flex space-x-2">
                <Input
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  placeholder="Сообщение..."
                  className="flex-1 h-8 text-sm"
                  data-testid="textarea-chat-message"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!chatMessage.trim() || !chatReceiverId || sendMessageMutation.isPending}
                  size="sm"
                  className="h-8 px-2"
                  data-testid="button-send-message"
                >
                  <Send className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Messages Dialog */}
        <Dialog open={showMessageDialog} onOpenChange={(open) => {
          setShowMessageDialog(open);
          if (!open) {
            markMessagesAsReadMutation.mutate();
            setOperatorReplyMessage('');
          }
        }}>
          <DialogContent className="max-w-sm max-h-[60vh] p-4">
            <DialogHeader className="pb-2">
              <DialogTitle className="text-base flex items-center gap-2">
                <Mail className="h-4 w-4" />
                Сообщения админа
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-1 max-h-60 overflow-y-auto pr-1">
              {operatorMessages && operatorMessages.length > 0 ? (
                operatorMessages.map((msg: any) => (
                  <div key={msg.id} className={`flex items-start space-x-2 p-2 rounded text-xs ${
                    msg.isRead ? 'bg-gray-50' : 'bg-blue-50'
                  }`}>
                    <div className="w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                      А
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-xs truncate">{msg.senderName}</span>
                        <span className="text-xs text-gray-500 ml-2">
                          {new Date(msg.createdAt).toLocaleTimeString('ru-RU', {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                      <p className="text-gray-700 text-xs leading-tight break-words">{msg.message}</p>
                      {!msg.isRead && (
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-1"></div>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4">
                  <Mail className="w-6 h-6 text-gray-300 mx-auto mb-1" />
                  <p className="text-gray-500 text-xs">Нет сообщений</p>
                </div>
              )}
            </div>

            <div className="border-t pt-2 mt-2">
              <div className="flex justify-center">
                <Button
                  onClick={() => {
                    setShowMessageDialog(false);
                  }}
                  size="sm"
                  className="h-8 text-xs px-3"
                  variant="outline"
                >
                  <MailOpen className="h-3 w-3 mr-1" />
                  Закрыть
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
