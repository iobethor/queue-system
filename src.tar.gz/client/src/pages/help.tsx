import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Navigation from "@/components/layout/navigation";
import { 
  BookOpen, Users, Calendar, Ticket, Monitor, Settings, 
  BarChart3, UserCheck, Phone, Mail, Clock, MapPin,
  Printer, Wifi, Database, Shield, Mic, Volume2, 
  Download, Upload, PieChart, TrendingUp, Bot, FileText,
  CheckCircle, AlertCircle, Eye, Edit, Trash2, Plus,
  Search, Filter, RefreshCw, Star, Camera, Headphones
} from "lucide-react";

export default function Help() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Справка по системе управления очередями</h1>
          <p className="mt-2 text-gray-600">Подробное руководство по использованию всех модулей системы</p>
        </div>

        {/* Overview */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Общее описание системы
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-4">
              Система управления очередями - это комплексное решение для автоматизации работы государственных и коммерческих учреждений. 
              Система включает в себя веб-интерфейс для предварительной записи, терминалы выдачи талонов, рабочие места операторов, 
              информационные табло и административную панель управления.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">Основные возможности</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Онлайн-запись через веб-интерфейс</li>
                  <li>• Выдача талонов на терминалах</li>
                  <li>• Управление очередью операторами</li>
                  <li>• Информационные табло</li>
                  <li>• Детальная аналитика и отчеты</li>
                </ul>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <h4 className="font-semibold text-green-900 mb-2">Технологии</h4>
                <ul className="text-sm text-green-800 space-y-1">
                  <li>• React + TypeScript</li>
                  <li>• Express.js backend</li>
                  <li>• PostgreSQL база данных</li>
                  <li>• WebSocket для реального времени</li>
                  <li>• ИИ-помощник на базе Ollama</li>
                </ul>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <h4 className="font-semibold text-purple-900 mb-2">Интеграции</h4>
                <ul className="text-sm text-purple-800 space-y-1">
                  <li>• Термопринтеры 80мм</li>
                  <li>• Электронные табло COM port</li>
                  <li>• RHVoice голосовые объявления</li>
                  <li>• Windows/Linux развертывание</li>
                  <li>• Автозапуск киосков</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Modules Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Dashboard Module */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-600" />
                Главная панель (Dashboard)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Центральная панель управления с общей статистикой и быстрым доступом ко всем модулям.</p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-900">Основные функции:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Отображение текущей очереди</li>
                    <li>• Статистика за сегодня</li>
                    <li>• Среднее время обслуживания</li>
                    <li>• Быстрая навигация по модулям</li>
                    <li>• Статус системы в реальном времени</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Статистические карточки:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Активная очередь - количество ожидающих</li>
                    <li>• Обслужено сегодня - завершенные талоны</li>
                    <li>• Среднее время - время ожидания</li>
                    <li>• Средняя оценка - рейтинг обслуживания</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Booking Module */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-green-600" />
                Предварительная запись (Booking)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Веб-интерфейс для онлайн-записи клиентов на услуги с выбором даты, времени и получением PIN-кода.</p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-900">Процесс записи:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Выбор отделения и услуги</li>
                    <li>• Указание даты и времени</li>
                    <li>• Ввод контактных данных</li>
                    <li>• Получение уникального PIN-кода</li>
                    <li>• Отправка SMS/Email уведомлений</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Дополнительные возможности:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Просмотр доступного времени</li>
                    <li>• Выбор льготной категории</li>
                    <li>• Добавление комментариев</li>
                    <li>• Печать талона по PIN-коду</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Terminal Module */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Printer className="h-5 w-5 text-orange-600" />
                Терминал выдачи талонов (Terminal)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Интерфейс для самостоятельного получения талонов посетителями без предварительной записи.</p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-900">Способы получения талона:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Выбор услуги из списка</li>
                    <li>• Ввод PIN-кода предварительной записи</li>
                    <li>• Автоматическая печать на термопринтере</li>
                    <li>• Отображение номера в очереди</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Функции терминала:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Простой интерфейс с крупными кнопками</li>
                    <li>• Поддержка сенсорных экранов</li>
                    <li>• Предварительный просмотр талона</li>
                    <li>• Настройка принтера и порта</li>
                    <li>• Работа в режиме киоска</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Operator Module */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="h-5 w-5 text-purple-600" />
                Рабочее место оператора (Operator)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Интерфейс для операторов с возможностью управления очередью, вызовом клиентов и обслуживанием.</p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-900">Основные действия:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Вызов следующего клиента</li>
                    <li>• Повторный вызов</li>
                    <li>• Завершение обслуживания</li>
                    <li>• Перенаправление к другому оператору</li>
                    <li>• Установка статусов (перерыв, обед)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Информация о клиенте:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Номер талона и время ожидания</li>
                    <li>• Данные предварительной записи</li>
                    <li>• История обслуживания</li>
                    <li>• Льготная категория</li>
                    <li>• Сбор оценки качества услуг</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Display Module */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Monitor className="h-5 w-5 text-indigo-600" />
                Информационное табло (Display)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Экран для отображения текущей очереди, вызываемых номеров и информации для посетителей.</p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-900">Отображаемая информация:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Активные талоны в очереди</li>
                    <li>• Номер вызываемого клиента</li>
                    <li>• Номер окна оператора</li>
                    <li>• Время и дата</li>
                    <li>• Объявления и новости</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Дополнительные возможности:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Голосовые объявления RHVoice</li>
                    <li>• Настройка языка и голоса</li>
                    <li>• Полноэкранный режим</li>
                    <li>• Автообновление каждые 2 секунды</li>
                    <li>• Настройка цветовой схемы</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Hall Admin Module */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-teal-600" />
                Администратор зала (Hall Admin)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Интерфейс для администратора зала с управлением предварительными записями и выдачей талонов.</p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-900">Управление записями:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Просмотр всех записей на дату</li>
                    <li>• Подтверждение записей</li>
                    <li>• Выдача талонов по записи</li>
                    <li>• Изменение статусов записей</li>
                    <li>• Отметка о неявке клиентов</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Фильтрация и поиск:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Поиск по имени, телефону, PIN</li>
                    <li>• Фильтр по статусу записи</li>
                    <li>• Выбор даты для просмотра</li>
                    <li>• Статистика записей за день</li>
                    <li>• Экспорт данных</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Admin Module */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-red-600" />
                Администрирование (Admin)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Полная административная панель для настройки системы, управления пользователями и конфигурации.</p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-900">Управление данными:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Отделения и услуги</li>
                    <li>• Операторы и их права доступа</li>
                    <li>• Настройки терминалов</li>
                    <li>• Конфигурация табло</li>
                    <li>• Голосовые настройки RHVoice</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">ИИ и интеграции:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Настройка моделей Ollama</li>
                    <li>• Управление контекстами ИИ</li>
                    <li>• Настройка электронной почты</li>
                    <li>• Импорт/экспорт данных</li>
                    <li>• Резервное копирование</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Statistics Module */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="h-5 w-5 text-yellow-600" />
                Статистика (Statistics)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Детальная аналитика работы системы с графиками, отчетами и ключевыми показателями.</p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-900">Основные метрики:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Количество обслуженных клиентов</li>
                    <li>• Среднее время ожидания</li>
                    <li>• Время обслуживания по услугам</li>
                    <li>• Загрузка операторов</li>
                    <li>• Рейтинги качества обслуживания</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Визуализация данных:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Графики по дням, неделям, месяцам</li>
                    <li>• Диаграммы распределения услуг</li>
                    <li>• Тепловые карты загруженности</li>
                    <li>• Сравнительные отчеты</li>
                    <li>• Экспорт в Excel/PDF</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Advanced Statistics Module */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-pink-600" />
                Расширенная аналитика (Advanced Statistics)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Углубленная бизнес-аналитика с ИИ-инсайтами, прогнозированием и детальными отчетами.</p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-900">ИИ-анализ:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Автоматические инсайты Ollama</li>
                    <li>• Прогнозирование нагрузки</li>
                    <li>• Рекомендации по оптимизации</li>
                    <li>• Анализ пиковых периодов</li>
                    <li>• Выявление проблемных зон</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Детальные отчеты:</h4>
                  <ul className="text-sm text-gray-700 mt-2 space-y-1">
                    <li>• Производительность операторов</li>
                    <li>• Эффективность обслуживания</li>
                    <li>• Анализ качества услуг</li>
                    <li>• Сравнение с предыдущими периодами</li>
                    <li>• Кастомизируемые дашборды</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Technical Information */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Техническая информация
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Системные требования</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Windows 10+ или Ubuntu 20.04+</li>
                  <li>• Node.js 18+ для разработки</li>
                  <li>• PostgreSQL 12+ база данных</li>
                  <li>• 4GB RAM минимум</li>
                  <li>• Доступ к интернету</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Аппаратные интеграции</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Термопринтеры 80мм рулон</li>
                  <li>• Электронные табло COM port</li>
                  <li>• Сенсорные терминалы</li>
                  <li>• Аудиосистема для объявлений</li>
                  <li>• Веб-камеры (опционально)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Безопасность</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Хеширование паролей</li>
                  <li>• Сессионная аутентификация</li>
                  <li>• Ролевая модель доступа</li>
                  <li>• HTTPS поддержка</li>
                  <li>• Резервное копирование</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Deployment Information */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5" />
              Развертывание системы
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Windows развертывание</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Скрипты создания ярлыков (launch-scripts/)</li>
                  <li>• Автозапуск киосков и табло</li>
                  <li>• Полноэкранный режим браузера</li>
                  <li>• Поддержка нескольких мониторов</li>
                  <li>• Интеграция с Windows службами</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Ubuntu развертывание</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Автоматическая установка ubuntu-deploy-rhvoice.sh</li>
                  <li>• Nginx reverse proxy настройка</li>
                  <li>• Systemd сервисы</li>
                  <li>• UFW firewall конфигурация</li>
                  <li>• Автоматическое резервное копирование</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Hotkeys and Tips */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Headphones className="h-5 w-5" />
              Горячие клавиши и советы
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Горячие клавиши оператора</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• <kbd className="bg-gray-100 px-2 py-1 rounded">Space</kbd> - Вызвать следующего</li>
                  <li>• <kbd className="bg-gray-100 px-2 py-1 rounded">R</kbd> - Повторный вызов</li>
                  <li>• <kbd className="bg-gray-100 px-2 py-1 rounded">Enter</kbd> - Завершить обслуживание</li>
                  <li>• <kbd className="bg-gray-100 px-2 py-1 rounded">Esc</kbd> - Отменить действие</li>
                  <li>• <kbd className="bg-gray-100 px-2 py-1 rounded">F1</kbd> - Помощь</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Рекомендации по использованию</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Регулярно обновляйте статистику</li>
                  <li>• Настройте автоматические уведомления</li>
                  <li>• Используйте фильтры для быстрого поиска</li>
                  <li>• Делайте резервные копии данных</li>
                  <li>• Обучите персонал работе с системой</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Support Information */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="h-5 w-5" />
              Поддержка и контакты
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <Phone className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <h4 className="font-semibold text-blue-900">Техническая поддержка</h4>
                <p className="text-sm text-blue-800 mt-1">Круглосуточная поддержка по техническим вопросам</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <Mail className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <h4 className="font-semibold text-green-900">Email поддержка</h4>
                <p className="text-sm text-green-800 mt-1">Ответ в течение 24 часов</p>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <FileText className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <h4 className="font-semibold text-purple-900">Документация</h4>
                <p className="text-sm text-purple-800 mt-1">Подробные инструкции и API документация</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}