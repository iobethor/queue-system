import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import Navigation from "@/components/layout/navigation";
import { 
  FileText, FileSpreadsheet, Download, Users, Timer, Clock, TrendingUp, CalendarDays, Search, 
  UserCheck, Activity, BarChart3, PieChart, LineChart, AlertTriangle, CheckCircle, XCircle,
  Monitor, Cpu, HardDrive, Wifi, TrendingDown, Star, Award, Target, Zap
} from "lucide-react";
import { useToast } from '@/hooks/use-toast';
import { format, subDays } from "date-fns";

interface AdvancedStatisticsFilters {
  dateFrom: string;
  dateTo: string;
  serviceId?: number;
  operatorId?: number;
  departmentId?: number;
  reportType: string;
}

interface OperatorPerformance {
  id: number;
  name: string;
  avgServiceTime: number;
  avgWaitTime: number;
  clientsServed: number;
  abandonedClients: number;
  idleTime: number;
  rating: number;
  transfersCount: number;
  successRate: number;
  efficiency: number;
}

interface QueueAnalytics {
  serviceId: number;
  serviceName: string;
  peakHours: string[];
  avgWaitTime: number;
  currentClients: number;
  totalClients: number;
  popularity: number;
  avgProcessingTime: number;
  trend: string;
}

interface ClientBehavior {
  totalClients: number;
  avgWaitTime: number;
  repeatVisitors: number;
  abandonmentRate: number;
  satisfactionRate: number;
  priorityClients: number;
  regularClients: number;
}

interface SystemHealth {
  terminalUsage: number;
  systemUptime: number;
  displayActivity: number;
  errorCount: number;
  printingIssues: number;
  connectionIssues: number;
}

export default function AdvancedStatistics() {
  const [filters, setFilters] = useState<AdvancedStatisticsFilters>({
    dateFrom: format(subDays(new Date(), 30), 'yyyy-MM-dd'),
    dateTo: format(new Date(), 'yyyy-MM-dd'),
    reportType: 'operators'
  });

  const [showResults, setShowResults] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  // Загрузка базовых данных
  const { data: services = [] } = useQuery({
    queryKey: ['/api/services'],
  });

  const { data: operators = [] } = useQuery({
    queryKey: ['/api/operators'],
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['/api/departments'],
  });

  // Загрузка расширенной статистики
  const { data: advancedStats, isLoading } = useQuery({
    queryKey: ['/api/statistics/advanced', filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== '') {
          params.append(key, value.toString());
        }
      });
      
      const response = await fetch(`/api/statistics/advanced?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch advanced statistics');
      return response.json();
    },
    enabled: showResults,
  });

  const handleFilterChange = (key: keyof AdvancedStatisticsFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setShowResults(false);
  };

  const handleShowStatistics = () => {
    setShowResults(true);
  };

  const exportReport = async (format: 'pdf' | 'excel' | 'csv') => {
    if (!showResults) {
      alert('Сначала сгенерируйте отчет');
      return;
    }

    try {
      setIsExporting(true);
      
      // Подготавливаем данные для экспорта
      const exportData = {
        filters,
        statistics: advancedStats,
        reportType: 'advanced',
        generatedAt: new Date().toISOString()
      };

      const response = await fetch(`/api/statistics/export/${format}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(exportData)
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Export failed');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `advanced_statistics_${new Date().toISOString().split('T')[0]}.${format === 'excel' ? 'xlsx' : format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Экспорт успешен",
        description: `Отчет сохранен как ${format.toUpperCase()}`
      });
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: "Ошибка экспорта",
        description: error instanceof Error ? error.message : "Не удалось экспортировать отчет",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };

  const renderOperatorReports = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <UserCheck className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Активных операторов</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.operatorSummary?.activeCount || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Timer className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Среднее время обслуживания</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.operatorSummary?.avgServiceTime || 0} мин
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Award className="h-8 w-8 text-yellow-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Лучший рейтинг</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.operatorSummary?.bestRating || 0}/5
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Target className="h-8 w-8 text-purple-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Средняя эффективность</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.operatorSummary?.avgEfficiency || 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Детальная таблица операторов */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="mr-2 h-5 w-5" />
            Подробная статистика по операторам
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-50">
                  <th className="border border-gray-300 px-4 py-2 text-left">Оператор</th>
                  <th className="border border-gray-300 px-4 py-2 text-center">Обслужено</th>
                  <th className="border border-gray-300 px-4 py-2 text-center">Среднее время</th>
                  <th className="border border-gray-300 px-4 py-2 text-center">Время ожидания</th>
                  <th className="border border-gray-300 px-4 py-2 text-center">Процент отказов</th>
                  <th className="border border-gray-300 px-4 py-2 text-center">Простой</th>
                  <th className="border border-gray-300 px-4 py-2 text-center">Рейтинг</th>
                  <th className="border border-gray-300 px-4 py-2 text-center">Эффективность</th>
                </tr>
              </thead>
              <tbody>
                {(advancedStats?.operatorPerformance || []).map((op: OperatorPerformance) => (
                  <tr key={op.id} className="hover:bg-gray-50">
                    <td className="border border-gray-300 px-4 py-2 font-medium">{op.name}</td>
                    <td className="border border-gray-300 px-4 py-2 text-center">{op.clientsServed}</td>
                    <td className="border border-gray-300 px-4 py-2 text-center">{op.avgServiceTime} мин</td>
                    <td className="border border-gray-300 px-4 py-2 text-center">{op.avgWaitTime} мин</td>
                    <td className="border border-gray-300 px-4 py-2 text-center">
                      <Badge variant={op.abandonedClients > 10 ? "destructive" : "secondary"}>
                        {((op.abandonedClients / (op.clientsServed + op.abandonedClients)) * 100).toFixed(1)}%
                      </Badge>
                    </td>
                    <td className="border border-gray-300 px-4 py-2 text-center">{op.idleTime} ч</td>
                    <td className="border border-gray-300 px-4 py-2 text-center">
                      <div className="flex items-center justify-center">
                        <Star className="h-4 w-4 text-yellow-400 mr-1" />
                        {op.rating.toFixed(1)}
                      </div>
                    </td>
                    <td className="border border-gray-300 px-4 py-2 text-center">
                      <div className="flex items-center justify-center">
                        <Progress value={op.efficiency} className="w-16 mr-2" />
                        {op.efficiency}%
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderQueueReports = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Activity className="h-8 w-8 text-red-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Активных очередей</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.queueSummary?.activeQueues || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Clock className="h-8 w-8 text-orange-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Среднее ожидание</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.queueSummary?.avgWaitTime || 0} мин
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <TrendingUp className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Самая популярная услуга</p>
                <p className="text-sm font-bold text-gray-900">
                  {advancedStats?.queueSummary?.mostPopularService || 'Н/Д'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <BarChart3 className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Пиковый час</p>
                <p className="text-sm font-bold text-gray-900">
                  {advancedStats?.queueSummary?.peakHour || 'Н/Д'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Анализ очередей по услугам */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <PieChart className="mr-2 h-5 w-5" />
            Анализ очередей по услугам
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {(advancedStats?.queueAnalytics || []).map((queue: QueueAnalytics) => (
              <div key={queue.serviceId} className="p-4 border rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium">{queue.serviceName}</h4>
                  <Badge variant={queue.trend === 'up' ? 'default' : queue.trend === 'down' ? 'destructive' : 'secondary'}>
                    {queue.trend === 'up' ? <TrendingUp className="h-3 w-3 mr-1" /> : 
                     queue.trend === 'down' ? <TrendingDown className="h-3 w-3 mr-1" /> : null}
                    {queue.trend}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Текущих клиентов</p>
                    <p className="font-semibold">{queue.currentClients}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Всего за период</p>
                    <p className="font-semibold">{queue.totalClients}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Среднее ожидание</p>
                    <p className="font-semibold">{queue.avgWaitTime} мин</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Время обработки</p>
                    <p className="font-semibold">{queue.avgProcessingTime} мин</p>
                  </div>
                </div>
                <div className="mt-3">
                  <p className="text-xs text-gray-600">Пиковые часы: {queue.peakHours.join(', ')}</p>
                  <div className="flex items-center mt-1">
                    <span className="text-xs text-gray-600 mr-2">Популярность:</span>
                    <Progress value={queue.popularity} className="flex-1" />
                    <span className="text-xs ml-2">{queue.popularity}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderClientReports = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-indigo-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Всего клиентов</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.clientBehavior?.totalClients || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Timer className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Среднее ожидание</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.clientBehavior?.avgWaitTime || 0} мин
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <XCircle className="h-8 w-8 text-red-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Процент отказов</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.clientBehavior?.abandonmentRate || 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <CheckCircle className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Удовлетворенность</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.clientBehavior?.satisfactionRate || 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Детальный анализ поведения клиентов */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Категории клиентов</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Повторные посетители</span>
                <Badge variant="secondary">
                  {advancedStats?.clientBehavior?.repeatVisitors || 0}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Приоритетные клиенты</span>
                <Badge variant="default">
                  {advancedStats?.clientBehavior?.priorityClients || 0}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Обычные клиенты</span>
                <Badge variant="outline">
                  {advancedStats?.clientBehavior?.regularClients || 0}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Динамика обслуживания</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {(advancedStats?.clientDynamics || []).map((day: any, index: number) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-sm">{day.date}</span>
                  <div className="flex items-center space-x-2">
                    <Progress value={day.completionRate} className="w-20" />
                    <span className="text-sm">{day.completionRate}%</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderSystemReports = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Monitor className="h-8 w-8 text-cyan-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Время работы системы</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.systemHealth?.systemUptime || 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Cpu className="h-8 w-8 text-purple-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Загрузка терминалов</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.systemHealth?.terminalUsage || 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Wifi className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Активность дисплеев</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.systemHealth?.displayActivity || 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <AlertTriangle className="h-8 w-8 text-red-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Количество ошибок</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.systemHealth?.errorCount || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Детальная информация о состоянии системы */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <HardDrive className="mr-2 h-5 w-5" />
              Аппаратная диагностика
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span>Проблемы с печатью</span>
                <Badge variant={advancedStats?.systemHealth?.printingIssues > 5 ? "destructive" : "secondary"}>
                  {advancedStats?.systemHealth?.printingIssues || 0}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Проблемы с подключением</span>
                <Badge variant={advancedStats?.systemHealth?.connectionIssues > 3 ? "destructive" : "secondary"}>
                  {advancedStats?.systemHealth?.connectionIssues || 0}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Общая стабильность</span>
                <div className="flex items-center">
                  <Progress 
                    value={100 - (advancedStats?.systemHealth?.errorCount || 0)} 
                    className="w-20 mr-2" 
                  />
                  <span className="text-sm">
                    {100 - (advancedStats?.systemHealth?.errorCount || 0)}%
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Логи последних ошибок</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {(advancedStats?.systemLogs || []).map((log: any, index: number) => (
                <div key={index} className="text-xs p-2 bg-gray-50 rounded">
                  <div className="flex justify-between">
                    <span className="font-mono">{log.timestamp}</span>
                    <Badge variant="outline" className="text-xs">
                      {log.level}
                    </Badge>
                  </div>
                  <p className="mt-1 text-gray-700">{log.message}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderPredictiveReports = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <LineChart className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Прогноз на завтра</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.predictions?.tomorrowForecast || 0} клиентов
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <UserCheck className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Рекомендуемо операторов</p>
                <p className="text-2xl font-bold text-gray-900">
                  {advancedStats?.predictions?.recommendedOperators || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Zap className="h-8 w-8 text-yellow-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Пиковое время</p>
                <p className="text-xl font-bold text-gray-900">
                  {advancedStats?.predictions?.expectedPeakTime || 'Н/Д'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Прогнозы и рекомендации */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="mr-2 h-5 w-5" />
            Аналитические прогнозы и рекомендации
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-3">Прогноз загруженности</h4>
              <div className="space-y-3">
                {(advancedStats?.predictions?.weeklyForecast || []).map((day: any, index: number) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-sm">{day.day}</span>
                    <div className="flex items-center space-x-2">
                      <Progress value={day.expectedLoad} className="w-20" />
                      <span className="text-sm">{day.expectedLoad}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-3">Рекомендации по оптимизации</h4>
              <div className="space-y-2">
                {(advancedStats?.recommendations || []).map((rec: any, index: number) => (
                  <div key={index} className="p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-blue-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-blue-800">{rec.title}</p>
                        <p className="text-xs text-blue-600">{rec.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Расширенная аналитика и отчетность</h1>
          <p className="text-gray-600">Комплексный анализ работы системы управления очередями</p>
        </div>

        {/* Фильтры */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Search className="mr-2 h-5 w-5" />
              Параметры анализа
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
              <div>
                <Label htmlFor="dateFrom">Дата начала</Label>
                <Input
                  id="dateFrom"
                  type="date"
                  value={filters.dateFrom}
                  onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                  data-testid="input-date-from"
                />
              </div>

              <div>
                <Label htmlFor="dateTo">Дата окончания</Label>
                <Input
                  id="dateTo"
                  type="date"
                  value={filters.dateTo}
                  onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                  data-testid="input-date-to"
                />
              </div>

              <div>
                <Label htmlFor="service">Услуга</Label>
                <Select onValueChange={(value) => handleFilterChange('serviceId', value === 'all' ? undefined : parseInt(value))}>
                  <SelectTrigger data-testid="select-service">
                    <SelectValue placeholder="Все услуги" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все услуги</SelectItem>
                    {(services as any[]).map((service: any) => (
                      <SelectItem key={service.id} value={service.id.toString()}>
                        {service.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="operator">Оператор</Label>
                <Select onValueChange={(value) => handleFilterChange('operatorId', value === 'all' ? undefined : parseInt(value))}>
                  <SelectTrigger data-testid="select-operator">
                    <SelectValue placeholder="Все операторы" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все операторы</SelectItem>
                    {(operators as any[]).map((operator: any) => (
                      <SelectItem key={operator.id} value={operator.id.toString()}>
                        {operator.firstName} {operator.lastName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="department">Отдел</Label>
                <Select onValueChange={(value) => handleFilterChange('departmentId', value === 'all' ? undefined : parseInt(value))}>
                  <SelectTrigger data-testid="select-department">
                    <SelectValue placeholder="Все отделы" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все отделы</SelectItem>
                    {(departments as any[]).map((dept: any) => (
                      <SelectItem key={dept.id} value={dept.id.toString()}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button 
                  onClick={handleShowStatistics}
                  className="w-full"
                  data-testid="button-show-statistics"
                >
                  <BarChart3 className="mr-2 h-4 w-4" />
                  Показать отчеты
                </Button>
              </div>
            </div>

            {/* Кнопки экспорта */}
            {showResults && (
              <div className="mt-4 pt-4 border-t">
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    onClick={() => exportReport('pdf')}
                    disabled={isExporting}
                    data-testid="button-export-pdf"
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    PDF
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => exportReport('excel')}
                    disabled={isExporting}
                    data-testid="button-export-excel"
                  >
                    <FileSpreadsheet className="mr-2 h-4 w-4" />
                    Excel
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => exportReport('csv')}
                    disabled={isExporting}
                    data-testid="button-export-csv"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    CSV
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Результаты */}
        {isLoading && (
          <Card className="mb-8">
            <CardContent className="pt-6">
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                <span className="ml-4 text-lg">Анализ данных...</span>
              </div>
            </CardContent>
          </Card>
        )}

        {showResults && !isLoading && (
          <Tabs defaultValue="operators" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="operators" className="flex items-center">
                <UserCheck className="mr-2 h-4 w-4" />
                Операторы
              </TabsTrigger>
              <TabsTrigger value="queues" className="flex items-center">
                <Activity className="mr-2 h-4 w-4" />
                Очереди
              </TabsTrigger>
              <TabsTrigger value="clients" className="flex items-center">
                <Users className="mr-2 h-4 w-4" />
                Клиенты
              </TabsTrigger>
              <TabsTrigger value="system" className="flex items-center">
                <Monitor className="mr-2 h-4 w-4" />
                Система
              </TabsTrigger>
              <TabsTrigger value="predictions" className="flex items-center">
                <LineChart className="mr-2 h-4 w-4" />
                Прогнозы
              </TabsTrigger>
            </TabsList>

            <TabsContent value="operators">
              {renderOperatorReports()}
            </TabsContent>

            <TabsContent value="queues">
              {renderQueueReports()}
            </TabsContent>

            <TabsContent value="clients">
              {renderClientReports()}
            </TabsContent>

            <TabsContent value="system">
              {renderSystemReports()}
            </TabsContent>

            <TabsContent value="predictions">
              {renderPredictiveReports()}
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}