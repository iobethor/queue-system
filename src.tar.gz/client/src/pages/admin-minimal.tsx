import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navigation from "@/components/layout/navigation";
import { Users, Building2, Settings, Ticket, Calendar } from "lucide-react";

export default function AdminMinimal() {
  const [activeTab, setActiveTab] = useState("overview");

  // Test data queries
  const { data: operators } = useQuery({
    queryKey: ['/api/operators'],
  });

  const { data: departments } = useQuery({
    queryKey: ['/api/departments'],
  });

  const { data: services } = useQuery({
    queryKey: ['/api/services'],
  });

  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="container mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">Администрирование</h1>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Обзор</TabsTrigger>
            <TabsTrigger value="management">Управление</TabsTrigger>
            <TabsTrigger value="settings">Настройки</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Операторы
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">
                    {(operators as any[])?.length || 0}
                  </p>
                  <p className="text-sm text-gray-600">Всего операторов</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="h-5 w-5" />
                    Отделения
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">
                    {(departments as any[])?.length || 0}
                  </p>
                  <p className="text-sm text-gray-600">Всего отделений</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Ticket className="h-5 w-5" />
                    Услуги
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">
                    {(services as any[])?.length || 0}
                  </p>
                  <p className="text-sm text-gray-600">Всего услуг</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="management" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Операторы</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {(operators as any[])?.map((operator: any) => (
                    <div key={operator.id} className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <p className="font-medium">{operator.firstName} {operator.lastName}</p>
                        <p className="text-sm text-gray-600">Окно {operator.windowNumber}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Изменить
                      </Button>
                    </div>
                  ))}
                  <Button className="w-full">
                    <Users className="h-4 w-4 mr-2" />
                    Добавить оператора
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Отделения</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {(departments as any[])?.map((department: any) => (
                    <div key={department.id} className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <p className="font-medium">{department.name}</p>
                        <p className="text-sm text-gray-600">{department.location}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Изменить
                      </Button>
                    </div>
                  ))}
                  <Button className="w-full">
                    <Building2 className="h-4 w-4 mr-2" />
                    Добавить отделение
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Настройки системы
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button variant="outline" className="h-20 flex flex-col">
                    <Calendar className="h-6 w-6 mb-2" />
                    График работы
                  </Button>
                  <Button variant="outline" className="h-20 flex flex-col">
                    <Settings className="h-6 w-6 mb-2" />
                    Терминал
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}