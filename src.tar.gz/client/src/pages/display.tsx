import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useWebSocket } from "@/hooks/use-websocket";
import { Button } from "@/components/ui/button";
import { Clock, Users, CheckCircle, Settings } from "lucide-react";
import { queryClient } from "@/lib/queryClient";

export default function Display() {
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // WebSocket подключение для real-time обновлений
  useWebSocket('display');

  // Генерируем стабильный ID дисплея (принудительно новый формат)
  const [displayId] = useState(() => {
    // Удаляем старые ID с проблемными символами
    const oldId = localStorage.getItem('display_id');
    if (oldId && (oldId.includes('(') || oldId.includes(')') || oldId.includes('/'))) {
      localStorage.removeItem('display_id');
    }
    
    let id = localStorage.getItem('display_id');
    if (!id) {
      // Создаем простой уникальный ID без специальных символов
      id = `display_${Math.random().toString(36).substr(2, 9)}_${Date.now()}`;
      localStorage.setItem('display_id', id);
    }
    console.log('Display ID:', id);
    return id;
  });
  
  const [isRedirecting, setIsRedirecting] = useState(false);
  
  const { data: displayConfig } = useQuery({
    queryKey: ['/api/display-settings', displayId],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/display-settings/${displayId}`);
        if (response.status === 404) {
          // Если настройки не найдены, перенаправляем на страницу настройки
          console.log('Настройки дисплея не найдены, переходим к настройке');
          setIsRedirecting(true);
          window.location.href = '/display-setup';
          return null;
        }
        if (!response.ok) throw new Error('Failed to fetch');
        return response.json();
      } catch (error) {
        setIsRedirecting(true);
        window.location.href = '/display-setup';
        return null;
      }
    },
    enabled: !isRedirecting,
    retry: false
  });

  // Загрузка активных талонов для конкретного отделения
  const { data: activeTickets = [] } = useQuery({
    queryKey: ['/api/tickets', displayConfig?.departmentId],
    queryFn: async () => {
      if (!displayConfig || !displayConfig.departmentId) {
        return [];
      }
      // Получаем только талоны для данного отделения
      const response = await fetch(`/api/tickets?departmentId=${displayConfig.departmentId}&status=active`);
      return response.json();
    },
    refetchInterval: ((displayConfig as any)?.refreshInterval || 3) * 1000,
    enabled: !!displayConfig?.departmentId && !isRedirecting
  });

  // Загрузка операторов для конкретного отделения
  const { data: operators = [] } = useQuery({
    queryKey: ['/api/operators', displayConfig?.departmentId],
    queryFn: async () => {
      if (!displayConfig || !displayConfig.departmentId) {
        return [];
      }
      // Получаем только операторов для данного отделения
      const response = await fetch(`/api/operators?departmentId=${displayConfig.departmentId}`);
      return response.json();
    },
    enabled: !!displayConfig?.departmentId && !isRedirecting
  });

  // Загрузка статистики
  const { data: statistics } = useQuery({
    queryKey: ['/api/statistics'],
    refetchInterval: 30000, // обновляем каждые 30 секунд
    enabled: !isRedirecting
  });

  // Обновление времени каждую секунду
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Фильтрация талонов
  const servingTickets = (activeTickets as any[]).filter((ticket: any) => ticket.status === 'serving');
  const calledTickets = (activeTickets as any[]).filter((ticket: any) => ticket.status === 'in_progress' || ticket.status === 'called');
  const waitingTickets = (activeTickets as any[]).filter((ticket: any) => ticket.status === 'waiting');

  // Получение оператора по ID
  const getOperatorWindow = (operatorId: number) => {
    const operator = (operators as any[]).find((op: any) => op.id === operatorId);
    return operator ? operator.windowNumber : '?';
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ru-RU', { 
      hour: '2-digit', 
      minute: '2-digit'
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  // Применяем настройки стиля
  const styles = {
    backgroundColor: (displayConfig as any)?.backgroundColor || '#ffffff',
    color: (displayConfig as any)?.textColor || '#000000',
    fontSize: `${(displayConfig as any)?.fontSize || 16}px`
  };

  const headerColor = (displayConfig as any)?.headerColor || '#1e40af';

  // Если происходит редирект, показываем сообщение
  if (isRedirecting) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-900 mx-auto mb-4"></div>
          <p className="text-gray-600">Переход к настройке...</p>
        </div>
      </div>
    );
  }

  // Если дисплей не настроен, показываем загрузку
  if (!displayConfig) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Настройка дисплея...</p>
        </div>
      </div>
    );
  }

  const accentColor = (displayConfig as any)?.accentColor || '#2563eb';

  return (
    <div className="min-h-screen flex flex-col" style={styles}>
      {/* Reconfigure Button */}
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            // Сбрасываем ID и настройки для повторной настройки
            localStorage.removeItem('display_id');
            // Также очищаем кеш запросов
            queryClient.clear();
            window.location.href = '/display-setup';
          }}
          className="p-2 bg-white/90 hover:bg-white rounded-full shadow-lg"
          data-testid="button-reconfigure-display"
        >
          <Settings className="w-4 h-4" />
        </Button>
      </div>

      {/* Header */}
      <div className="text-center py-4 sm:py-6 lg:py-8 shadow-lg" style={{ backgroundColor: headerColor, color: '#ffffff' }}>
        <h1 className="text-2xl sm:text-3xl lg:text-5xl font-bold mb-2">
          {(displayConfig as any)?.organizationName || 'ЭЛЕКТРОННАЯ ОЧЕРЕДЬ'}
        </h1>
        {(displayConfig as any)?.showTime && (
          <div className="text-lg sm:text-xl lg:text-2xl mt-2 sm:mt-4">
            <span className="font-semibold">{formatTime(currentTime)}</span>
            <span className="mx-2 sm:mx-4">|</span>
            <span>{formatDate(currentTime)}</span>
          </div>
        )}
      </div>

      {/* Main Content - Двухколоночный макет */}
      <div className="flex-1 grid grid-cols-2 gap-6 p-6">
        
        {/* Left Column - Called and Serving Tickets */}
        <div className="space-y-6">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6" style={{ color: accentColor }}>
              ВЫЗВАННЫЕ
            </h2>
          </div>
          
          <div className="space-y-4 max-h-[600px] overflow-y-auto">
            {/* Serving Tickets - сейчас обслуживаются */}
            {servingTickets.map((ticket: any) => (
              <div 
                key={ticket.id}
                className="p-6 rounded-lg border-4 shadow-lg"
                style={{ 
                  borderColor: '#10b981',
                  backgroundColor: '#dcfce7'
                }}
              >
                <div className="text-center">
                  <div className="text-5xl font-bold mb-2" style={{ color: '#065f46' }}>
                    {ticket.ticketNumber}
                  </div>
                  <div className="text-2xl font-semibold mb-2" style={{ color: accentColor }}>
                    Окно {getOperatorWindow(ticket.operatorId)}
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                    <span className="text-lg font-medium text-green-700">Обслуживается</span>
                  </div>
                </div>
              </div>
            ))}

            {/* Called Tickets - вызванные */}
            {calledTickets.map((ticket: any) => (
              <div 
                key={ticket.id}
                className="p-6 rounded-lg border-4 shadow-lg animate-pulse"
                style={{ 
                  borderColor: '#f59e0b',
                  backgroundColor: '#fef3c7'
                }}
              >
                <div className="text-center">
                  <div className="text-5xl font-bold mb-2 text-orange-900">
                    {ticket.ticketNumber}
                  </div>
                  <div className="text-2xl font-semibold mb-2" style={{ color: accentColor }}>
                    Окно {getOperatorWindow(ticket.operatorId)}
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-bold">!</span>
                    </div>
                    <span className="text-lg font-medium text-orange-700">Вызван</span>
                  </div>
                </div>
              </div>
            ))}

            {/* Если нет вызванных талонов */}
            {servingTickets.length === 0 && calledTickets.length === 0 && (
              <div className="text-center py-12">
                <p className="text-xl opacity-60">Нет вызванных талонов</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column - Waiting Queue */}
        <div className="space-y-6">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6" style={{ color: accentColor }}>
              ОЖИДАЮТ
            </h2>
          </div>

          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            {waitingTickets.length > 0 ? (
              waitingTickets.slice(0, 15).map((ticket: any, index: number) => (
                <div 
                  key={ticket.id}
                  className="p-4 rounded-lg border shadow-sm"
                  style={{ 
                    borderColor: ((displayConfig as any)?.textColor || '#000000') + '20',
                    backgroundColor: ((displayConfig as any)?.backgroundColor === '#ffffff') ? '#f1f5f9' : '#334155'
                  }}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold"
                        style={{ backgroundColor: accentColor }}
                      >
                        {index + 1}
                      </div>
                      <div>
                        <div className="text-lg font-semibold">
                          {ticket.ticketNumber}
                        </div>
                        <div className="text-sm opacity-70">
                          {ticket.serviceName || 'Услуга'}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm opacity-70">
                        {new Date(ticket.issuedAt).toLocaleTimeString('ru-RU', { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <Users className="h-16 w-16 mx-auto mb-4" style={{ color: ((displayConfig as any)?.textColor || '#000000') + '40' }} />
                <p className="text-xl" style={{ color: ((displayConfig as any)?.textColor || '#000000') + '80' }}>
                  Очередь пуста
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="py-4 px-8 border-t" style={{ borderColor: ((displayConfig as any)?.textColor || '#000000') + '20' }}>
        <div className="flex justify-between items-center text-lg">
          {(displayConfig as any)?.showTime && (
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5" style={{ color: accentColor }} />
              <span>{formatTime(currentTime)}</span>
            </div>
          )}
          
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5" style={{ color: accentColor }} />
              <span>В очереди: {waitingTickets.length}</span>
            </div>
            
            {(displayConfig as any)?.showCompletedCount && statistics && (
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" style={{ color: '#10b981' }} />
                <span>Обслужено сегодня: {(statistics as any)?.completedToday || 0}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}