import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Monitor, MapPin, Settings, Check } from "lucide-react";

export default function TerminalSetup() {
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<number | null>(null);
  const [location, setLocation] = useState("");
  const { toast } = useToast();
  
  // Генерируем стабильный ID терминала (принудительно новый формат)
  const [terminalId] = useState(() => {
    // Удаляем старые ID с проблемными символами
    const oldId = localStorage.getItem('terminal_id');
    if (oldId && (oldId.includes('(') || oldId.includes(')') || oldId.includes('/'))) {
      localStorage.removeItem('terminal_id');
    }
    
    let id = localStorage.getItem('terminal_id');
    if (!id) {
      // Создаем простой уникальный ID без специальных символов
      id = `terminal_${Math.random().toString(36).substr(2, 9)}_${Date.now()}`;
      localStorage.setItem('terminal_id', id);
    }
    console.log('Terminal setup ID:', id);
    return id;
  });

  const { data: departments } = useQuery({
    queryKey: ['/api/departments'],
  });

  const { data: currentSettings, refetch: refetchSettings } = useQuery({
    queryKey: ['/api/terminal-settings', terminalId],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/terminal-settings/${terminalId}`);
        if (response.status === 404) {
          return null; // Терминал не настроен
        }
        if (!response.ok) throw new Error('Failed to fetch');
        return response.json();
      } catch (error) {
        return null;
      }
    }
  });

  const configureTerminalMutation = useMutation({
    mutationFn: async (data: { departmentId: number; location: string }) => {
      const response = await apiRequest('POST', '/api/terminal-settings/configure', {
        terminalId,
        departmentId: data.departmentId,
        location: data.location,
        isConfigured: true
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Терминал настроен",
        description: "Настройка терминала завершена успешно",
      });
      refetchSettings();
      // Перенаправляем на страницу терминала через 2 секунды
      setTimeout(() => {
        window.location.href = '/terminal';
      }, 2000);
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось настроить терминал",
        variant: "destructive",
      });
    },
  });

  const handleConfigure = () => {
    if (selectedDepartmentId && location.trim()) {
      configureTerminalMutation.mutate({
        departmentId: selectedDepartmentId,
        location: location.trim()
      });
    }
  };

  // Если терминал уже настроен, показываем информацию и кнопку для продолжения
  if (currentSettings && currentSettings.isConfigured) {
    const department = (departments as any)?.find((d: any) => d.id === currentSettings.departmentId);
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-xl">Терминал настроен</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div>
              <p className="text-sm text-gray-600">Отделение:</p>
              <p className="font-semibold">{department?.name || 'Не найдено'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Расположение:</p>
              <p className="font-semibold">{currentSettings.location || 'Не указано'}</p>
            </div>
            <Button
              onClick={() => window.location.href = '/terminal'}
              className="w-full"
              data-testid="button-continue-terminal"
            >
              Перейти к терминалу
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                // Сбрасываем ID и настройки для повторной настройки
                localStorage.removeItem('terminal_id');
                queryClient.clear();
                window.location.reload();
              }}
              className="w-full"
              data-testid="button-reconfigure-terminal"
            >
              Настроить заново
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
            <Monitor className="w-8 h-8 text-blue-600" />
          </div>
          <CardTitle className="text-xl">Настройка терминала</CardTitle>
          <p className="text-sm text-gray-600">
            Укажите отделение и расположение для данного терминала
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="department">Отделение</Label>
            <Select 
              value={selectedDepartmentId?.toString()} 
              onValueChange={(value) => setSelectedDepartmentId(Number(value))}
            >
              <SelectTrigger data-testid="select-department-terminal">
                <SelectValue placeholder="Выберите отделение" />
              </SelectTrigger>
              <SelectContent>
                {(departments as any)?.map((department: any) => (
                  <SelectItem key={department.id} value={department.id.toString()}>
                    {department.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Расположение терминала</Label>
            <div className="relative">
              <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                id="location"
                placeholder="Например: Главный холл, 1 этаж"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="pl-10"
                data-testid="input-terminal-location"
              />
            </div>
          </div>

          <div className="pt-4">
            <Button
              onClick={handleConfigure}
              disabled={!selectedDepartmentId || !location.trim() || configureTerminalMutation.isPending}
              className="w-full"
              data-testid="button-configure-terminal"
            >
              {configureTerminalMutation.isPending ? (
                <>
                  <Settings className="w-4 h-4 mr-2 animate-spin" />
                  Настройка...
                </>
              ) : (
                <>
                  <Settings className="w-4 h-4 mr-2" />
                  Настроить терминал
                </>
              )}
            </Button>
          </div>

          <div className="text-xs text-gray-500 text-center mt-4 bg-gray-50 p-2 rounded">
            <p className="mb-1"><strong>Информация об устройстве:</strong></p>
            <p>ID терминала: {terminalId}</p>
            <p className="mt-1 text-xs">После настройки этот терминал будет работать только с выбранным отделением</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}