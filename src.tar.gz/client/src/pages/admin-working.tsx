import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navigation from "@/components/layout/navigation";
import { Users, Building2, Settings, Ticket, Calendar, Plus, Edit, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";

export default function AdminWorking() {
  const [activeTab, setActiveTab] = useState("overview");
  const [editingOperator, setEditingOperator] = useState<any>(null);
  const [editingDepartment, setEditingDepartment] = useState<any>(null);
  const [editingService, setEditingService] = useState<any>(null);

  const queryClient = useQueryClient();

  // API queries
  const { data: operators } = useQuery({
    queryKey: ['/api/operators'],
  });

  const { data: departments } = useQuery({
    queryKey: ['/api/departments'],
  });

  const { data: services } = useQuery({
    queryKey: ['/api/services'],
  });

  // Operator mutations
  const createOperatorMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/operators', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/operators'] });
      setEditingOperator(null);
    },
  });

  const updateOperatorMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => apiRequest('PUT', `/api/operators/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/operators'] });
      setEditingOperator(null);
    },
  });

  const deleteOperatorMutation = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/operators/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/operators'] });
    },
  });

  // Department mutations
  const createDepartmentMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/departments', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/departments'] });
      setEditingDepartment(null);
    },
  });

  const updateDepartmentMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => apiRequest('PUT', `/api/departments/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/departments'] });
      setEditingDepartment(null);
    },
  });

  const deleteDepartmentMutation = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/departments/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/departments'] });
    },
  });

  // Service mutations
  const createServiceMutation = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/services', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      setEditingService(null);
    },
  });

  const updateServiceMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => apiRequest('PUT', `/api/services/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      setEditingService(null);
    },
  });

  const deleteServiceMutation = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/services/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
    },
  });

  const handleOperatorSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      firstName: formData.get('firstName'),
      lastName: formData.get('lastName'),
      windowNumber: parseInt(formData.get('windowNumber') as string),
      username: formData.get('username'),
      password: formData.get('password'),
    };

    if (editingOperator?.id) {
      updateOperatorMutation.mutate({ id: editingOperator.id, data });
    } else {
      createOperatorMutation.mutate(data);
    }
  };

  const handleDepartmentSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get('name'),
      location: formData.get('location'),
    };

    if (editingDepartment?.id) {
      updateDepartmentMutation.mutate({ id: editingDepartment.id, data });
    } else {
      createDepartmentMutation.mutate(data);
    }
  };

  const handleServiceSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get('name'),
      description: formData.get('description'),
      estimatedTime: parseInt(formData.get('estimatedTime') as string),
      departmentId: parseInt(formData.get('departmentId') as string),
      letterCode: formData.get('letterCode'),
    };

    if (editingService?.id) {
      updateServiceMutation.mutate({ id: editingService.id, data });
    } else {
      createServiceMutation.mutate(data);
    }
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="container mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">Администрирование</h1>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Обзор</TabsTrigger>
            <TabsTrigger value="operators">Операторы</TabsTrigger>
            <TabsTrigger value="departments">Отделения</TabsTrigger>
            <TabsTrigger value="services">Услуги</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Операторы
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">
                    {(operators as any[])?.length || 0}
                  </p>
                  <p className="text-sm text-gray-600">Всего операторов</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="h-5 w-5" />
                    Отделения
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">
                    {(departments as any[])?.length || 0}
                  </p>
                  <p className="text-sm text-gray-600">Всего отделений</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Ticket className="h-5 w-5" />
                    Услуги
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">
                    {(services as any[])?.length || 0}
                  </p>
                  <p className="text-sm text-gray-600">Всего услуг</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="operators" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Операторы</h2>
              <Button onClick={() => setEditingOperator({})}>
                <Plus className="h-4 w-4 mr-2" />
                Добавить оператора
              </Button>
            </div>

            {editingOperator && (
              <Card>
                <CardHeader>
                  <CardTitle>
                    {editingOperator.id ? 'Редактировать оператора' : 'Добавить оператора'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleOperatorSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">Имя</Label>
                        <Input
                          id="firstName"
                          name="firstName"
                          defaultValue={editingOperator.firstName || ''}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Фамилия</Label>
                        <Input
                          id="lastName"
                          name="lastName"
                          defaultValue={editingOperator.lastName || ''}
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="windowNumber">Номер окна</Label>
                      <Input
                        id="windowNumber"
                        name="windowNumber"
                        type="number"
                        defaultValue={editingOperator.windowNumber || ''}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="username">Логин</Label>
                      <Input
                        id="username"
                        name="username"
                        defaultValue={editingOperator.username || ''}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="password">Пароль</Label>
                      <Input
                        id="password"
                        name="password"
                        type="password"
                        placeholder={editingOperator.id ? 'Оставьте пустым, чтобы не менять' : ''}
                        required={!editingOperator.id}
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button type="submit">
                        {editingOperator.id ? 'Обновить' : 'Создать'}
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setEditingOperator(null)}>
                        Отмена
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            <div className="space-y-4">
              {(operators as any[])?.map((operator: any) => (
                <Card key={operator.id}>
                  <CardContent className="flex items-center justify-between p-4">
                    <div>
                      <p className="font-medium">{operator.firstName} {operator.lastName}</p>
                      <p className="text-sm text-gray-600">Окно {operator.windowNumber} • {operator.username}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingOperator(operator)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deleteOperatorMutation.mutate(operator.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="departments" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Отделения</h2>
              <Button onClick={() => setEditingDepartment({})}>
                <Plus className="h-4 w-4 mr-2" />
                Добавить отделение
              </Button>
            </div>

            {editingDepartment && (
              <Card>
                <CardHeader>
                  <CardTitle>
                    {editingDepartment.id ? 'Редактировать отделение' : 'Добавить отделение'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleDepartmentSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Название</Label>
                      <Input
                        id="name"
                        name="name"
                        defaultValue={editingDepartment.name || ''}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="location">Адрес</Label>
                      <Input
                        id="location"
                        name="location"
                        defaultValue={editingDepartment.location || ''}
                        required
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button type="submit">
                        {editingDepartment.id ? 'Обновить' : 'Создать'}
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setEditingDepartment(null)}>
                        Отмена
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            <div className="space-y-4">
              {(departments as any[])?.map((department: any) => (
                <Card key={department.id}>
                  <CardContent className="flex items-center justify-between p-4">
                    <div>
                      <p className="font-medium">{department.name}</p>
                      <p className="text-sm text-gray-600">{department.location}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingDepartment(department)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deleteDepartmentMutation.mutate(department.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="services" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Услуги</h2>
              <Button onClick={() => setEditingService({})}>
                <Plus className="h-4 w-4 mr-2" />
                Добавить услугу
              </Button>
            </div>

            {editingService && (
              <Card>
                <CardHeader>
                  <CardTitle>
                    {editingService.id ? 'Редактировать услугу' : 'Добавить услугу'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleServiceSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Название</Label>
                      <Input
                        id="name"
                        name="name"
                        defaultValue={editingService.name || ''}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="description">Описание</Label>
                      <Textarea
                        id="description"
                        name="description"
                        defaultValue={editingService.description || ''}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="estimatedTime">Время обслуживания (мин)</Label>
                        <Input
                          id="estimatedTime"
                          name="estimatedTime"
                          type="number"
                          defaultValue={editingService.estimatedTime || ''}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="letterCode">Буквенный код</Label>
                        <Input
                          id="letterCode"
                          name="letterCode"
                          defaultValue={editingService.letterCode || ''}
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="departmentId">Отделение</Label>
                      <select
                        id="departmentId"
                        name="departmentId"
                        className="w-full border rounded p-2"
                        defaultValue={editingService.departmentId || ''}
                        required
                      >
                        <option value="">Выберите отделение</option>
                        {(departments as any[])?.map((dept: any) => (
                          <option key={dept.id} value={dept.id}>
                            {dept.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="flex gap-2">
                      <Button type="submit">
                        {editingService.id ? 'Обновить' : 'Создать'}
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setEditingService(null)}>
                        Отмена
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            <div className="space-y-4">
              {(services as any[])?.map((service: any) => (
                <Card key={service.id}>
                  <CardContent className="flex items-center justify-between p-4">
                    <div>
                      <p className="font-medium">{service.name}</p>
                      <p className="text-sm text-gray-600">
                        {service.description} • {service.estimatedTime} мин • Код: {service.letterCode}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingService(service)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deleteServiceMutation.mutate(service.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}