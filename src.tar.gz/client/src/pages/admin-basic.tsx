import React from "react";

export default function AdminBasic() {
  const handleButtonClick = () => {
    alert("Кнопка нажата!");
  };

  return (
    <div>
      <h1>Простая админ панель</h1>
      <button onClick={handleButtonClick}>Тест кнопки</button>
      <div>
        <p>Если эта кнопка работает, то проблема в других компонентах.</p>
      </div>
    </div>
  );
}