import React, { useState } from "react";

export default function TestClick() {
  const [clicked, setClicked] = useState(false);

  const handleClick = () => {
    console.log("Button clicked!");
    setClicked(!clicked);
    alert("Кнопка работает!");
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Тест кликов</h1>
      <button 
        onClick={handleClick}
        style={{
          padding: "10px 20px",
          backgroundColor: clicked ? "green" : "blue",
          color: "white",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
          fontSize: "16px"
        }}
      >
        {clicked ? "Работает!" : "Кликните здесь"}
      </button>
      <p>Состояние: {clicked ? "Нажато" : "Не нажато"}</p>
    </div>
  );
}