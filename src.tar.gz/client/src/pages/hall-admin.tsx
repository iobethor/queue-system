import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Navigation from "@/components/layout/navigation";
import { 
  Calendar, Clock, User, Phone, Mail, MapPin, 
  Ticket, AlertCircle, Users,
  Settings, Plus, Search, Filter
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function HallAdmin() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("scheduled");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  // Queries
  const { data: appointments = [] as any[], isLoading: appointmentsLoading, refetch: refetchAppointments } = useQuery({
    queryKey: ['/api/appointments'],
    refetchInterval: 2000,
    staleTime: 0,
    gcTime: 0,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });

  const { data: services = [] as any[] } = useQuery({
    queryKey: ['/api/services'],
  });

  const { data: departments = [] as any[] } = useQuery({
    queryKey: ['/api/departments'],
  });

  const { data: tickets = [] as any[] } = useQuery({
    queryKey: ['/api/tickets'],
    refetchInterval: 2000,
  });

  // Mutations
  const issueTicketMutation = useMutation({
    mutationFn: async (appointmentId: number) => {
      const response = await apiRequest('POST', `/api/appointments/${appointmentId}/issue-ticket`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Ошибка выдачи талона');
      }
      return response.json();
    },
    onSuccess: async (data, appointmentId) => {
      await queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      await queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
      await refetchAppointments();
      toast({
        title: "Талон выдан",
        description: `Выдан талон ${data.ticket.ticketNumber}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось выдать талон",
        variant: "destructive",
      });
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const response = await apiRequest('PUT', `/api/appointments/${id}`, { status });
      if (!response.ok) throw new Error('Ошибка обновления статуса');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      toast({
        title: "Статус обновлен",
        description: "Статус записи успешно обновлен",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить статус",
        variant: "destructive",
      });
    },
  });

  // Filter appointments
  const filteredAppointments = appointments.filter((appointment: any) => {
    const matchesSearch = searchTerm === "" || 
      appointment.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      appointment.clientPhone?.includes(searchTerm) ||
      appointment.pinCode.includes(searchTerm);
    
    const matchesStatus = statusFilter === "all" || appointment.status === statusFilter;
    
    // Show appointments for selected date AND pending appointments for future dates
    const appointmentDate = appointment.appointmentDate;
    const today = new Date().toISOString().split('T')[0];
    const matchesDate = appointmentDate === selectedDate || 
      (appointment.status === 'scheduled' && appointmentDate >= today);
    
    return matchesSearch && matchesStatus && matchesDate;
  });

  const getServiceName = (serviceId: number) => {
    const service = services.find((s: any) => s.id === serviceId);
    return service?.name || "Неизвестная услуга";
  };

  const getDepartmentName = (departmentId: number) => {
    const department = departments.find((d: any) => d.id === departmentId);
    return department?.name || "Неизвестное отделение";
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      scheduled: { color: "bg-blue-100 text-blue-800", text: "Запланировано" },
      completed: { color: "bg-gray-100 text-gray-800", text: "Завершено" },
      cancelled: { color: "bg-red-100 text-red-800", text: "Отменено" },
      no_show: { color: "bg-yellow-100 text-yellow-800", text: "Не явился" },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.scheduled;
    return <Badge className={config.color}>{config.text}</Badge>;
  };

  const todayStats = {
    total: filteredAppointments.length,
    scheduled: appointments.filter((a: any) => a.status === 'scheduled').length,
    completed: appointments.filter((a: any) => a.appointmentDate === selectedDate && a.status === 'completed').length,
    noShow: appointments.filter((a: any) => a.appointmentDate === selectedDate && a.status === 'no_show').length,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Администратор зала</h1>
              <p className="mt-2 text-gray-600">Управление предварительными записями и выдача талонов</p>
            </div>
            <Button 
              variant="outline"
              onClick={async () => {
                await queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
                await refetchAppointments();
                toast({
                  title: "Данные обновлены",
                  description: "Принудительное обновление выполнено",
                });
              }}
            >
              🔄 Обновить данные
            </Button>
          </div>
        </div>



        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Всего записей</p>
                  <p className="text-3xl font-bold text-blue-600">{todayStats.total}</p>
                </div>
                <Users className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Новые записи</p>
                  <p className="text-3xl font-bold text-blue-600">{todayStats.scheduled}</p>
                </div>
                <Calendar className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Завершены</p>
                  <p className="text-3xl font-bold text-gray-600">{todayStats.completed}</p>
                </div>
                <Ticket className="h-8 w-8 text-gray-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Не явились</p>
                  <p className="text-3xl font-bold text-yellow-600">{todayStats.noShow}</p>
                </div>
                <AlertCircle className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Дата
                </label>
                <Input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  data-testid="input-date-filter"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Поиск
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Имя, телефон или PIN"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Статус
                </label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger data-testid="select-status-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все статусы</SelectItem>
                    <SelectItem value="scheduled">Запланировано</SelectItem>
                    <SelectItem value="completed">Завершено</SelectItem>
                    <SelectItem value="cancelled">Отменено</SelectItem>
                    <SelectItem value="no_show">Не явился</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("");
                    setStatusFilter("all");
                    setSelectedDate(new Date().toISOString().split('T')[0]);
                  }}
                  data-testid="button-reset-filters"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Сбросить
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Color Legend */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-sm">Условные обозначения</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-cyan-100 border border-cyan-200 rounded"></div>
                <span className="text-xs">Запланировано</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-blue-100 border border-blue-200 rounded"></div>
                <span className="text-xs">Талон выдан</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-red-100 border border-red-200 rounded"></div>
                <span className="text-xs">Не явился</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-green-100 border border-green-200 rounded"></div>
                <span className="text-xs">Завершено</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-gray-100 border border-gray-200 rounded"></div>
                <span className="text-xs">Отменено</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Appointments List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Предварительные записи ({filteredAppointments.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {appointmentsLoading ? (
              <div className="text-center py-8">Загрузка записей...</div>
            ) : filteredAppointments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                Нет записей по выбранным фильтрам
              </div>
            ) : (
              <div className="space-y-4">
                {filteredAppointments.map((appointment: any) => {
                  // Определяем цвет подсветки в зависимости от статуса
                  const getCardBgColor = (status: string) => {
                    switch (status) {
                      case 'scheduled': return 'bg-cyan-50 border-cyan-200'; // Голубой - активен
                      case 'confirmed': return 'bg-blue-50 border-blue-200'; // Синий - выдан
                      case 'no_show': return 'bg-red-50 border-red-200'; // Красный - не явился
                      case 'cancelled': return 'bg-gray-50 border-gray-200'; // Серый - отменен
                      case 'completed': return 'bg-green-50 border-green-200'; // Зеленый - завершен
                      default: return 'bg-white border-gray-200';
                    }
                  };

                  // Найти связанный талон для подтвержденных записей
                  const relatedTicket = tickets?.find((ticket: any) => ticket.appointmentId === appointment.id);

                  return (
                    <div 
                      key={appointment.id} 
                      className={`border rounded-lg p-4 transition-colors ${getCardBgColor(appointment.status)}`}
                      data-testid={`appointment-card-${appointment.id}`}
                    >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <User className="h-4 w-4 text-gray-500" />
                              <span className="font-semibold">{appointment.clientName}</span>
                            </div>
                            <div className="text-sm text-gray-600">
                              PIN: <span className="font-mono bg-gray-100 px-2 py-1 rounded">{appointment.pinCode}</span>
                              {relatedTicket && (
                                <div className="mt-1 flex items-center gap-1">
                                  <Ticket className="h-3 w-3 text-blue-600" />
                                  <span className="text-blue-600 font-medium text-xs">
                                    Талон: {relatedTicket.ticketNumber}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                          
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Phone className="h-4 w-4 text-gray-500" />
                              <span className="text-sm">{appointment.clientPhone || "Не указан"}</span>
                            </div>
                            {appointment.clientEmail && (
                              <div className="flex items-center gap-2">
                                <Mail className="h-4 w-4 text-gray-500" />
                                <span className="text-sm">{appointment.clientEmail}</span>
                              </div>
                            )}
                          </div>
                          
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Clock className="h-4 w-4 text-gray-500" />
                              <span className="text-sm">{appointment.appointmentTime}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Settings className="h-4 w-4 text-gray-500" />
                              <span className="text-sm">{getServiceName(appointment.serviceId)}</span>
                            </div>
                          </div>
                          
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <MapPin className="h-4 w-4 text-gray-500" />
                              <span className="text-sm">{getDepartmentName(appointment.departmentId)}</span>
                            </div>
                            {getStatusBadge(appointment.status)}
                          </div>
                        </div>
                        
                        {appointment.additionalInfo && (
                          <div className="mt-3 p-3 bg-blue-50 rounded text-sm">
                            <strong>Дополнительная информация:</strong> {appointment.additionalInfo}
                          </div>
                        )}
                      </div>
                      
                      <div className="flex flex-col gap-2 ml-4">
                        {appointment.status === 'scheduled' ? (
                          <>
                            <Button
                              size="sm"
                              onClick={() => issueTicketMutation.mutate(appointment.id)}
                              disabled={issueTicketMutation.isPending}
                              data-testid={`button-issue-ticket-${appointment.id}`}
                            >
                              <Ticket className="h-4 w-4 mr-2" />
                              Выдать талон
                            </Button>
                            
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateStatusMutation.mutate({ id: appointment.id, status: 'no_show' })}
                              disabled={updateStatusMutation.isPending}
                              data-testid={`button-no-show-${appointment.id}`}
                            >
                              <AlertCircle className="h-4 w-4 mr-2" />
                              Не явился
                            </Button>
                          </>
                        ) : (
                          <div className="text-sm text-gray-500">
                            {appointment.status === 'completed' ? 'Обслужен' : 
                             appointment.status === 'no_show' ? 'Не явился' : 
                             appointment.status === 'cancelled' ? 'Отменен' : 'Неизвестный статус'}
                          </div>
                        )}
                      </div>
                    </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}