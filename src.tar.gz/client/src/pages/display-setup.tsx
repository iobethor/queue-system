import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Monitor, MapPin, Settings, Check } from "lucide-react";

export default function DisplaySetup() {
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<number | null>(null);
  const [location, setLocation] = useState("");
  const { toast } = useToast();
  
  // Генерируем стабильный ID дисплея (принудительно новый формат)
  const [displayId] = useState(() => {
    // Удаляем старые ID с проблемными символами
    const oldId = localStorage.getItem('display_id');
    if (oldId && (oldId.includes('(') || oldId.includes(')') || oldId.includes('/'))) {
      localStorage.removeItem('display_id');
    }
    
    let id = localStorage.getItem('display_id');
    if (!id) {
      // Создаем простой уникальный ID без специальных символов
      id = `display_${Math.random().toString(36).substr(2, 9)}_${Date.now()}`;
      localStorage.setItem('display_id', id);
    }
    console.log('Display setup ID:', id);
    return id;
  });

  const { data: departments } = useQuery({
    queryKey: ['/api/departments'],
  });

  const { data: currentSettings, refetch: refetchSettings } = useQuery({
    queryKey: ['/api/display-settings', displayId],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/display-settings/${displayId}`);
        if (response.status === 404) {
          return null; // Дисплей не настроен
        }
        if (!response.ok) throw new Error('Failed to fetch');
        return response.json();
      } catch (error) {
        return null;
      }
    }
  });

  const configureDisplayMutation = useMutation({
    mutationFn: async (data: { departmentId: number; location: string }) => {
      const response = await apiRequest('POST', '/api/display-settings/configure', {
        displayId,
        departmentId: data.departmentId,
        location: data.location,
        isActive: true
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Дисплей настроен",
        description: "Настройка дисплея завершена успешно",
      });
      refetchSettings();
      // Перенаправляем на страницу дисплея через 2 секунды
      setTimeout(() => {
        window.location.href = '/display';
      }, 2000);
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось настроить дисплей",
        variant: "destructive",
      });
    },
  });

  const handleConfigure = () => {
    if (selectedDepartmentId && location.trim()) {
      configureDisplayMutation.mutate({
        departmentId: selectedDepartmentId,
        location: location.trim()
      });
    }
  };

  // Если дисплей уже настроен, показываем информацию и кнопку для продолжения
  if (currentSettings && currentSettings.isActive) {
    const department = (departments as any)?.find((d: any) => d.id === currentSettings.departmentId);
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-xl">Дисплей настроен</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div>
              <p className="text-sm text-gray-600">Отделение:</p>
              <p className="font-semibold">{department?.name || 'Не найдено'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Расположение:</p>
              <p className="font-semibold">{currentSettings.location || 'Не указано'}</p>
            </div>
            <Button
              onClick={() => window.location.href = '/display'}
              className="w-full"
              data-testid="button-continue-display"
            >
              Перейти к дисплею
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                // Сбрасываем ID и настройки для повторной настройки
                localStorage.removeItem('display_id');
                queryClient.clear();
                window.location.reload();
              }}
              className="w-full"
              data-testid="button-reconfigure-display"
            >
              Настроить заново
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
            <Monitor className="w-8 h-8 text-blue-600" />
          </div>
          <CardTitle className="text-xl">Настройка дисплея</CardTitle>
          <p className="text-sm text-gray-600">
            Укажите отделение и расположение для данного дисплея
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="department">Отделение</Label>
            <Select 
              value={selectedDepartmentId?.toString()} 
              onValueChange={(value) => setSelectedDepartmentId(Number(value))}
            >
              <SelectTrigger data-testid="select-department-display">
                <SelectValue placeholder="Выберите отделение" />
              </SelectTrigger>
              <SelectContent>
                {(departments as any)?.map((department: any) => (
                  <SelectItem key={department.id} value={department.id.toString()}>
                    {department.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Расположение дисплея</Label>
            <div className="relative">
              <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                id="location"
                placeholder="Например: Главное табло, 2 этаж"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="pl-10"
                data-testid="input-display-location"
              />
            </div>
          </div>

          <div className="pt-4">
            <Button
              onClick={handleConfigure}
              disabled={!selectedDepartmentId || !location.trim() || configureDisplayMutation.isPending}
              className="w-full"
              data-testid="button-configure-display"
            >
              {configureDisplayMutation.isPending ? (
                <>
                  <Settings className="w-4 h-4 mr-2 animate-spin" />
                  Настройка...
                </>
              ) : (
                <>
                  <Settings className="w-4 h-4 mr-2" />
                  Настроить дисплей
                </>
              )}
            </Button>
          </div>

          <div className="text-xs text-gray-500 text-center mt-4 bg-gray-50 p-2 rounded">
            <p className="mb-1"><strong>Информация об устройстве:</strong></p>
            <p>ID дисплея: {displayId}</p>
            <p className="mt-1 text-xs">После настройки этот дисплей будет показывать только талоны выбранного отделения</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}