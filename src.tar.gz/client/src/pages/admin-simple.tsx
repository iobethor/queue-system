import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Navigation from "@/components/layout/navigation";

export default function AdminSimple() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="container mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">Администрирование (Простое)</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Операторы</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Управление операторами системы</p>
              <Button className="mt-4">Открыть</Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Отделения</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Управление отделениями</p>
              <Button className="mt-4">Открыть</Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Услуги</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Управление услугами</p>
              <Button className="mt-4">Открыть</Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>График работы</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Настройка графика работы</p>
              <Button className="mt-4">Открыть</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}