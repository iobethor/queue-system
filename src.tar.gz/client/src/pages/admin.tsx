import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  AnimatedButton, 
  AnimatedCard, 
  PageTransition, 
  StaggeredList,
  AnimatedCounter,
  LoadingSkeleton
} from "@/components/AnimatedMicroInteractions";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
// import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Navigation from "@/components/layout/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Users, Building2, Settings, HelpCircle, UserPlus, Plus,
  Edit, Trash2, Monitor, Palette, Clock, Volume2, Printer,
  MessageSquare, Send, Bot, Tv, CheckSquare, Square,
  Save, Wifi, Zap, Loader2, BarChart3, UserCircle,
  Bell, Download, CheckCircle, AlertTriangle, Calendar, Eye, User, Timer,
  Upload, FileDown, FileUp, Mail, Database, Cpu, Globe, Trash, ArrowUpFromLine as Import, ArrowDownToLine as Export,
  RefreshCw, Activity, MessageCircle, History, TrendingUp,
  ToggleLeft, ToggleRight, UserCheck, Ticket, AlertCircle, Search,
  Home, CalendarPlus, Wrench, Server, Shield, Brain, X
} from "lucide-react";
import { VoiceSettingsEnhanced } from "@/components/ui/voice-settings-enhanced";
import { DisplayBoardSettings } from "@/components/ui/display-board-settings";

// Operator Messaging Component
// Schedule Management Component
function ScheduleManagementSection({ 
  departments, 
  updateDepartmentScheduleMutation,
  workSchedule,
  setWorkSchedule,
  holidays,
  setHolidays,
  showWorkScheduleDialog,
  setShowWorkScheduleDialog,
  selectedScheduleDepartmentId,
  setSelectedScheduleDepartmentId
}: any) {

  const handleSaveSchedule = () => {
    if (!selectedScheduleDepartmentId) return;
    
    updateDepartmentScheduleMutation.mutate({
      departmentId: selectedScheduleDepartmentId,
      scheduleData: {
        workSchedule,
        holidays
      }
    });
  };

  const dayNames = {
    monday: 'Понедельник',
    tuesday: 'Вторник', 
    wednesday: 'Среда',
    thursday: 'Четверг',
    friday: 'Пятница',
    saturday: 'Суббота',
    sunday: 'Воскресенье'
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>График работы отделений</CardTitle>
          <CardDescription>
            Настройка рабочих часов и выходных дней для каждого отделения
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {(departments as any[])?.map((department: any) => (
              <div key={department.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h3 className="font-medium">{department.name}</h3>
                  <p className="text-sm text-gray-500">
                    {department.workSchedule ? 'График настроен' : 'График не настроен'}
                  </p>
                </div>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedScheduleDepartmentId(department.id);
                    if (department.workSchedule) {
                      setWorkSchedule(department.workSchedule);
                    }
                    if (department.holidays) {
                      setHolidays(department.holidays);
                    }
                    setShowWorkScheduleDialog(true);
                  }}
                >
                  <Clock className="h-4 w-4 mr-2" />
                  Настроить
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Work Schedule Section - Inline instead of Dialog */}
      {showWorkScheduleDialog && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Настройка графика работы</CardTitle>
            <CardDescription>
              Установите рабочие часы для каждого дня недели и добавьте праздничные дни
            </CardDescription>
          </CardHeader>
          <CardContent>
          <div className="space-y-6">
            {/* Weekly Schedule */}
            <div className="space-y-4">
              <h3 className="font-medium">Еженедельное расписание</h3>
              {Object.entries(dayNames).map(([day, dayName]) => (
                <div key={day} className="flex items-center space-x-4 p-3 border rounded">
                  <div className="w-24">
                    <Label className="text-sm font-medium">{dayName}</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={workSchedule[day]?.isWorkingDay || false}
                      onCheckedChange={(checked) => {
                        setWorkSchedule((prev: any) => ({
                          ...prev,
                          [day]: { ...prev[day], isWorkingDay: checked }
                        }));
                      }}
                    />
                    <Label className="text-sm">Рабочий день</Label>
                  </div>
                  {workSchedule[day]?.isWorkingDay && (
                    <div className="flex items-center space-x-2">
                      <Input
                        type="time"
                        value={workSchedule[day]?.startTime || '09:00'}
                        onChange={(e) => {
                          setWorkSchedule((prev: any) => ({
                            ...prev,
                            [day]: { ...prev[day], startTime: e.target.value }
                          }));
                        }}
                        className="w-24"
                      />
                      <span>до</span>
                      <Input
                        type="time"
                        value={workSchedule[day]?.endTime || '18:00'}
                        onChange={(e) => {
                          setWorkSchedule((prev: any) => ({
                            ...prev,
                            [day]: { ...prev[day], endTime: e.target.value }
                          }));
                        }}
                        className="w-24"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Holidays */}
            <div className="space-y-4">
              <h3 className="font-medium">Праздничные дни</h3>
              <div className="flex space-x-2">
                <Input
                  type="date"
                  onChange={(e) => {
                    if (e.target.value && !holidays.includes(e.target.value)) {
                      setHolidays([...holidays, e.target.value]);
                    }
                  }}
                />
                <Button
                  variant="outline"
                  onClick={() => {
                    const dateInput = document.querySelector('input[type="date"]') as HTMLInputElement;
                    if (dateInput?.value && !holidays.includes(dateInput.value)) {
                      setHolidays([...holidays, dateInput.value]);
                      dateInput.value = '';
                    }
                  }}
                >
                  Добавить
                </Button>
              </div>
              {holidays.length > 0 && (
                <div className="space-y-2">
                  {holidays.map((holiday: string, index: number) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                      <span>{new Date(holiday).toLocaleDateString('ru-RU')}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setHolidays(holidays.filter((_: string, i: number) => i !== index));
                        }}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="flex justify-end space-x-2 mt-6">
            <Button variant="outline" onClick={() => setShowWorkScheduleDialog(false)}>
              Отмена
            </Button>
            <Button onClick={handleSaveSchedule} disabled={updateDepartmentScheduleMutation.isPending}>
              {updateDepartmentScheduleMutation.isPending ? 'Сохранение...' : 'Сохранить'}
            </Button>
          </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}

function OperatorMessagingComponent({ operators }: { operators: any }) {
  const { toast } = useToast();
  const [selectedOperator, setSelectedOperator] = useState('');
  const [message, setMessage] = useState('');

  const sendMessageMutation = useMutation({
    mutationFn: async (data: { operatorId: string; message: string }) => {
      const response = await apiRequest('POST', '/api/admin/send-message', {
        operatorId: data.operatorId,
        message: data.message,
        timestamp: new Date().toISOString(),
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Сообщение отправлено",
        description: "Оператор получил ваше сообщение",
      });
      setMessage('');
      setSelectedOperator('');
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось отправить сообщение",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!selectedOperator || !message.trim()) {
      toast({
        title: "Ошибка",
        description: "Выберите оператора и введите сообщение",
        variant: "destructive",
      });
      return;
    }

    sendMessageMutation.mutate({
      operatorId: selectedOperator,
      message: message.trim(),
    });
  };

  return (
    <AnimatedCard>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-blue-500" />
          Сообщения операторам
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>Выберите оператора</Label>
          <Select value={selectedOperator} onValueChange={setSelectedOperator}>
            <SelectTrigger>
              <SelectValue placeholder="Выберите оператора" />
            </SelectTrigger>
            <SelectContent>
              {((operators as any) || [])?.map((operator: any) => (
                <SelectItem key={operator.id} value={operator.id.toString()}>
                  {operator.firstName} {operator.lastName} (Окно {operator.windowNumber})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Сообщение</Label>
          <Textarea 
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Введите сообщение для оператора..."
            className="min-h-20"
          />
        </div>
        <AnimatedButton 
          className="w-full"
          onClick={handleSendMessage}
          disabled={sendMessageMutation.isPending || !selectedOperator || !message.trim()}
        >
          {sendMessageMutation.isPending ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Send className="h-4 w-4 mr-2" />
          )}
          Отправить сообщение
        </AnimatedButton>
      </CardContent>
    </AnimatedCard>
  );
}

// Management Sections Components
function OperatorsManagementSection({ operators, exportDataMutation, openOperatorDialog }: { operators: any; exportDataMutation: any; openOperatorDialog: any }) {
  const { data: operatorStatuses } = useQuery({
    queryKey: ['/api/operator-statuses'],
  });

  const getOperatorStatus = (operatorId: number) => {
    const status = (operatorStatuses as any)?.find((s: any) => s.operatorId === operatorId);
    return status?.status || 'offline';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'break': return 'bg-yellow-500'; 
      case 'offline': 
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'online': return 'В сети';
      case 'break': return 'Перерыв';
      case 'offline': 
      default: return 'Не в сети';
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Управление операторами
          </CardTitle>
          <div className="flex items-center space-x-2">
            <AnimatedButton 
              size="sm" 
              variant="outline" 
              onClick={() => exportDataMutation.mutate('operators')}
              disabled={exportDataMutation.isPending}
            >
              <Export className="h-4 w-4 mr-2" />
              Экспорт
            </AnimatedButton>
            <AnimatedButton size="sm" onClick={() => openOperatorDialog()}>
              <UserPlus className="h-4 w-4 mr-2" />
              Добавить оператора
            </AnimatedButton>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {((operators as any) || [])?.map((operator: any) => {
            const status = getOperatorStatus(operator.id);
            return (
              <div key={operator.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback>
                        {operator.firstName?.[0]}{operator.lastName?.[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${getStatusColor(status)}`}></div>
                  </div>
                  <div>
                    <p className="font-medium">{operator.firstName} {operator.lastName}</p>
                    <p className="text-sm text-gray-500">Окно {operator.windowNumber} • {operator.role}</p>
                    <Badge variant={status === 'online' ? "default" : status === 'break' ? "secondary" : "outline"}>
                      {getStatusText(status)}
                    </Badge>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <AnimatedButton variant="outline" size="sm" onClick={() => openOperatorDialog(operator)}>
                    <Edit className="h-4 w-4" />
                  </AnimatedButton>
                  <AnimatedButton variant="outline" size="sm">
                    <Trash2 className="h-4 w-4" />
                  </AnimatedButton>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

function DepartmentsManagementSection({ departments, exportDataMutation, openDepartmentDialog }: { departments: any; exportDataMutation: any; openDepartmentDialog: any }) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Управление отделениями
          </CardTitle>
          <div className="flex items-center space-x-2">
            <AnimatedButton 
              size="sm" 
              variant="outline" 
              onClick={() => exportDataMutation.mutate('departments')}
              disabled={exportDataMutation.isPending}
            >
              <Export className="h-4 w-4 mr-2" />
              Экспорт
            </AnimatedButton>
            <AnimatedButton size="sm" onClick={() => openDepartmentDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Добавить отделение
            </AnimatedButton>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {((departments as any) || [])?.map((department: any) => (
            <div key={department.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-medium">{department.name}</p>
                <p className="text-sm text-gray-500">{department.location}</p>
                <Badge variant={department.isActive ? "default" : "secondary"}>
                  {department.isActive ? "Активно" : "Неактивно"}
                </Badge>
              </div>
              <div className="flex space-x-2">
                <AnimatedButton variant="outline" size="sm" onClick={() => openDepartmentDialog(department)}>
                  <Edit className="h-4 w-4" />
                </AnimatedButton>
                <AnimatedButton variant="outline" size="sm">
                  <Trash2 className="h-4 w-4" />
                </AnimatedButton>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function ServicesManagementSection({ services, exportDataMutation, openServiceDialog }: { services: any; exportDataMutation: any; openServiceDialog: any }) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Ticket className="h-5 w-5" />
            Управление услугами
          </CardTitle>
          <div className="flex items-center space-x-2">
            <AnimatedButton 
              size="sm" 
              variant="outline" 
              onClick={() => exportDataMutation.mutate('services')}
              disabled={exportDataMutation.isPending}
            >
              <Export className="h-4 w-4 mr-2" />
              Экспорт
            </AnimatedButton>
            <AnimatedButton size="sm" onClick={() => openServiceDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Добавить услугу
            </AnimatedButton>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {((services as any) || [])?.map((service: any) => (
            <div key={service.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-medium">{service.name}</p>
                <p className="text-sm text-gray-500">
                  {service.serviceCode} • {service.estimatedTime} мин
                </p>
                <Badge variant={service.isActive ? "default" : "secondary"}>
                  {service.isActive ? "Активна" : "Неактивна"}
                </Badge>
              </div>
              <div className="flex space-x-2">
                <AnimatedButton variant="outline" size="sm" onClick={() => openServiceDialog(service)}>
                  <Edit className="h-4 w-4" />
                </AnimatedButton>
                <AnimatedButton variant="outline" size="sm">
                  <Trash2 className="h-4 w-4" />
                </AnimatedButton>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}



// AI Settings Component
function AISettingsSection() {
  const { toast } = useToast();
  const [selectedModel, setSelectedModel] = useState('');
  const [temperature, setTemperature] = useState(70);
  const [operatorContext, setOperatorContext] = useState('');
  const [adminContext, setAdminContext] = useState('');
  const [aiEnabled, setAiEnabled] = useState(true);

  const { data: aiModels, isLoading: modelsLoading } = useQuery({
    queryKey: ['/api/ai/models'],
  });

  const { data: aiContexts, isLoading: contextsLoading } = useQuery({
    queryKey: ['/api/ai/contexts'],
  });

  const { data: aiStatus } = useQuery({
    queryKey: ['/api/ai/status'],
    refetchInterval: 30000,
  });

  const updateModelMutation = useMutation({
    mutationFn: async (model: string) => {
      const response = await apiRequest('POST', '/api/ai/model', { model });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Модель обновлена",
        description: "Активная модель ИИ изменена",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ai/models'] });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить модель",
        variant: "destructive",
      });
    },
  });

  const updateContextMutation = useMutation({
    mutationFn: async (data: { moduleType: string; context: string }) => {
      const response = await apiRequest('POST', '/api/ai/context', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Контекст обновлен",
        description: "Настройки контекста сохранены",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ai/contexts'] });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить контекст",
        variant: "destructive",
      });
    },
  });

  const handleSaveSettings = () => {
    if (selectedModel) {
      updateModelMutation.mutate(selectedModel);
    }
    if (operatorContext) {
      updateContextMutation.mutate({ moduleType: 'operator', context: operatorContext });
    }
    if (adminContext) {
      updateContextMutation.mutate({ moduleType: 'admin', context: adminContext });
    }
  };

  React.useEffect(() => {
    if (aiModels && (aiModels as any).currentModel) {
      setSelectedModel((aiModels as any).currentModel);
    }
    if (aiContexts) {
      setOperatorContext((aiContexts as any).operator || '');
      setAdminContext((aiContexts as any).admin || '');
    }
  }, [aiModels, aiContexts]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          Настройки ИИ
          {aiStatus ? (
            <Badge variant={(aiStatus as any)?.available ? "default" : "destructive"} className="ml-2">
              {(aiStatus as any)?.available ? "Подключен" : "Отключен"}
            </Badge>
          ) : null}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <Label>Активная модель</Label>
            {modelsLoading ? (
              <LoadingSkeleton lines={1} />
            ) : (
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger>
                  <SelectValue placeholder="Выберите модель" />
                </SelectTrigger>
                <SelectContent>
                  {(aiModels as any)?.models?.map((model: string) => (
                    <SelectItem key={model} value={model}>
                      {model}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          <div>
            <Label>Температура ({temperature}%)</Label>
            <div className="mt-2">
              <input 
                type="range" 
                min="1" 
                max="100" 
                step="1" 
                value={temperature}
                onChange={(e) => setTemperature(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Точность</span>
                <span>Творчество</span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <Label>Контекст для операторов</Label>
            {contextsLoading ? (
              <LoadingSkeleton lines={3} />
            ) : (
              <Textarea 
                value={operatorContext}
                onChange={(e) => setOperatorContext(e.target.value)}
                placeholder="Ты помощник для операторов системы электронной очереди..."
                className="min-h-24"
              />
            )}
          </div>

          <div>
            <Label>Контекст для администратора</Label>
            {contextsLoading ? (
              <LoadingSkeleton lines={3} />
            ) : (
              <Textarea 
                value={adminContext}
                onChange={(e) => setAdminContext(e.target.value)}
                placeholder="Ты администратор системы с полным доступом..."
                className="min-h-24"
              />
            )}
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Switch 
            id="ai-enabled" 
            checked={aiEnabled}
            onCheckedChange={setAiEnabled}
          />
          <Label htmlFor="ai-enabled">Включить ИИ помощника</Label>
        </div>

        <AnimatedButton 
          className="w-full"
          onClick={handleSaveSettings}
          disabled={updateModelMutation.isPending || updateContextMutation.isPending}
        >
          {(updateModelMutation.isPending || updateContextMutation.isPending) ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Save className="h-4 w-4 mr-2" />
          )}
          Сохранить настройки ИИ
        </AnimatedButton>
      </CardContent>
    </Card>
  );
}

// System and Data Management Component
function SystemDataComponent() {
  const { toast } = useToast();
  const [backupSchedule, setBackupSchedule] = useState('manual');
  const [backupLocation, setBackupLocation] = useState('/backups');
  const [isBackupRunning, setIsBackupRunning] = useState(false);
  const [selectedImportFile, setSelectedImportFile] = useState<File | null>(null);
  
  const { data: securitySettings, isLoading } = useQuery({
    queryKey: ['/api/security-settings'],
  });

  const updateSecurityMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('PUT', '/api/security-settings', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Настройки безопасности обновлены",
        description: "Изменения применены успешно",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/security-settings'] });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить настройки безопасности",
        variant: "destructive",
      });
    },
  });

  const handleSecurityToggle = (enabled: boolean) => {
    updateSecurityMutation.mutate({
      externalAccessRestricted: enabled,
      allowedExternalPaths: ['/booking'],
      internalNetworkRanges: ['192.168.0.0/16', '10.0.0.0/8', '172.16.0.0/12', '127.0.0.1'],
      updatedBy: 'admin'
    });
  };

  const handleBackupNow = async () => {
    setIsBackupRunning(true);
    try {
      const response = await apiRequest('POST', '/api/backup/create', {
        location: backupLocation,
        timestamp: new Date().toISOString()
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Создание файла резервной копии для скачивания
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        
        // Диалог сохранения
        const a = document.createElement('a');
        a.href = url;
        a.download = `database_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        toast({
          title: "Резервная копия создана",
          description: "База данных успешно сохранена",
        });
      } else {
        throw new Error('Ошибка сервера');
      }
    } catch (error) {
      toast({
        title: "Ошибка создания резервной копии",
        description: "Не удалось создать резервную копию",
        variant: "destructive",
      });
    } finally {
      setIsBackupRunning(false);
    }
  };

  const handleExport = async (type: string, endpoint: string, filename: string) => {
    try {
      const response = await apiRequest('GET', `/api/export/${endpoint}`, {});
      
      if (response.ok) {
        const data = await response.json();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        
        // Создание диалога сохранения через элемент a
        const a = document.createElement('a');
        a.href = url;
        a.download = `${filename}_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        toast({
          title: "Экспорт завершен",
          description: `Данные ${type} успешно экспортированы`,
        });
      } else {
        throw new Error('Ошибка сервера');
      }
    } catch (error) {
      toast({
        title: "Ошибка экспорта",
        description: `Не удалось экспортировать данные ${type}`,
        variant: "destructive",
      });
    }
  };

  const handleImport = async (endpoint: string, type: string) => {
    if (!selectedImportFile) {
      toast({
        title: "Файл не выбран",
        description: "Пожалуйста, выберите файл для импорта",
        variant: "destructive",
      });
      return;
    }

    try {
      const fileContent = await selectedImportFile.text();
      const data = JSON.parse(fileContent);
      
      const response = await apiRequest('POST', `/api/import/${endpoint}`, { data });
      
      if (response.ok) {
        const result = await response.json();
        toast({
          title: "Импорт завершен",
          description: `Импортировано ${result.count || 0} записей ${type}`,
        });
        setSelectedImportFile(null);
        // Очистка поля ввода файла
        const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
        if (fileInput) fileInput.value = '';
      } else {
        throw new Error('Ошибка сервера');
      }
    } catch (error) {
      toast({
        title: "Ошибка импорта",
        description: `Не удалось импортировать данные ${type}`,
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return <LoadingSkeleton lines={5} />;
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Security Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Настройки безопасности
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Ограничение внешнего доступа</h4>
                <p className="text-sm text-gray-600 mt-1">
                  Разрешить доступ только из внутренней сети
                </p>
              </div>
              <Switch 
                checked={(securitySettings as any)?.externalAccessRestricted || false}
                onCheckedChange={handleSecurityToggle}
                disabled={updateSecurityMutation.isPending}
              />
            </div>
          </div>

          <div className="p-4 border rounded-lg">
            <h4 className="font-medium mb-2">Разрешенные пути</h4>
            <div className="space-y-2">
              <Badge variant="outline" className="text-xs mr-2">
                /booking
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Database Backup */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Резервное копирование БД
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Режим создания копий</Label>
            <Select value={backupSchedule} onValueChange={setBackupSchedule}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="manual">Ручное</SelectItem>
                <SelectItem value="daily">Ежедневно</SelectItem>
                <SelectItem value="weekly">Еженедельно</SelectItem>
                <SelectItem value="monthly">Ежемесячно</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Папка для сохранения</Label>
            <Input 
              value={backupLocation}
              onChange={(e) => setBackupLocation(e.target.value)}
              placeholder="/path/to/backups"
            />
          </div>

          <AnimatedButton 
            onClick={handleBackupNow}
            disabled={isBackupRunning}
            className="w-full"
          >
            {isBackupRunning ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Download className="h-4 w-4 mr-2" />
            )}
            {isBackupRunning ? 'Создание копии...' : 'Создать резервную копию'}
          </AnimatedButton>

          <div className="text-sm text-gray-500">
            Последняя копия: Никогда
          </div>
        </CardContent>
      </Card>

      {/* Export Functions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileDown className="h-5 w-5" />
            Экспорт данных
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <AnimatedButton 
            variant="outline" 
            className="w-full justify-start"
            onClick={() => handleExport('талонов', 'tickets', 'tickets')}
          >
            <Ticket className="h-4 w-4 mr-2" />
            Экспорт талонов
          </AnimatedButton>
          
          <AnimatedButton 
            variant="outline" 
            className="w-full justify-start"
            onClick={() => handleExport('услуг', 'services', 'services')}
          >
            <Settings className="h-4 w-4 mr-2" />
            Экспорт услуг
          </AnimatedButton>
          
          <AnimatedButton 
            variant="outline" 
            className="w-full justify-start"
            onClick={() => handleExport('операторов', 'operators', 'operators')}
          >
            <Users className="h-4 w-4 mr-2" />
            Экспорт операторов
          </AnimatedButton>
          
          <AnimatedButton 
            variant="outline" 
            className="w-full justify-start"
            onClick={() => handleExport('отделений', 'departments', 'departments')}
          >
            <Building2 className="h-4 w-4 mr-2" />
            Экспорт отделений
          </AnimatedButton>
        </CardContent>
      </Card>

      {/* Import Functions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileUp className="h-5 w-5" />
            Импорт данных
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label>Выберите файл для импорта</Label>
            <Input 
              type="file" 
              accept=".json" 
              className="mt-2"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  setSelectedImportFile(file);
                }
              }}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            <AnimatedButton 
              variant="outline" 
              size="sm"
              onClick={() => handleImport('tickets', 'талонов')}
              disabled={!selectedImportFile}
            >
              <FileUp className="h-3 w-3 mr-1" />
              Талоны
            </AnimatedButton>
            
            <AnimatedButton 
              variant="outline" 
              size="sm"
              onClick={() => handleImport('services', 'услуг')}
              disabled={!selectedImportFile}
            >
              <FileUp className="h-3 w-3 mr-1" />
              Услуги
            </AnimatedButton>
            
            <AnimatedButton 
              variant="outline" 
              size="sm"
              onClick={() => handleImport('operators', 'операторов')}
              disabled={!selectedImportFile}
            >
              <FileUp className="h-3 w-3 mr-1" />
              Операторы
            </AnimatedButton>
            
            <AnimatedButton 
              variant="outline" 
              size="sm"
              onClick={() => handleImport('departments', 'отделений')}
              disabled={!selectedImportFile}
            >
              <FileUp className="h-3 w-3 mr-1" />
              Отделения
            </AnimatedButton>
          </div>

          <div className="text-xs text-gray-500 mt-2">
            Поддерживаются файлы в формате JSON
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Work Schedule Component
function WorkScheduleComponent() {
  const { toast } = useToast();
  const [selectedDepartment, setSelectedDepartment] = useState<number | null>(null);
  const [schedule, setSchedule] = useState<any>({});
  const [holidays, setHolidays] = useState<string[]>([]);

  const { data: departments, isLoading: departmentsLoading } = useQuery({
    queryKey: ['/api/departments'],
  });

  const updateScheduleMutation = useMutation({
    mutationFn: async ({ workSchedule, holidays }: any) => {
      const response = await apiRequest('PUT', `/api/departments/${selectedDepartment}/schedule`, {
        workSchedule,
        holidays
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "График работы обновлен",
        description: "Изменения применены успешно",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить график работы",
        variant: "destructive",
      });
    },
  });

  const daysOfWeek = [
    { key: 'monday', label: 'Понедельник' },
    { key: 'tuesday', label: 'Вторник' },
    { key: 'wednesday', label: 'Среда' },
    { key: 'thursday', label: 'Четверг' },
    { key: 'friday', label: 'Пятница' },
    { key: 'saturday', label: 'Суббота' },
    { key: 'sunday', label: 'Воскресенье' }
  ];

  const handleSaveSchedule = () => {
    if (!selectedDepartment) {
      toast({
        title: "Ошибка",
        description: "Выберите отделение",
        variant: "destructive",
      });
      return;
    }

    updateScheduleMutation.mutate({
      workSchedule: schedule,
      holidays: holidays
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-blue-500" />
          Управление графиком работы
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Department Selection */}
        <div>
          <Label htmlFor="department-select">Выберите отделение</Label>
          <Select onValueChange={(value) => setSelectedDepartment(parseInt(value))}>
            <SelectTrigger>
              <SelectValue placeholder="Выберите отделение" />
            </SelectTrigger>
            <SelectContent>
              {((departments as any[]) || []).map((dept: any) => (
                <SelectItem key={dept.id} value={dept.id.toString()}>
                  {dept.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedDepartment && (
          <>
            {/* Weekly Schedule */}
            <div className="space-y-4">
              <h3 className="font-semibold">Режим работы по дням недели</h3>
              {daysOfWeek.map((day) => (
                <div key={day.key} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Switch
                      checked={schedule[day.key]?.isWorking || false}
                      onCheckedChange={(checked) => 
                        setSchedule((prev: any) => ({
                          ...prev,
                          [day.key]: { ...prev[day.key], isWorking: checked }
                        }))
                      }
                    />
                    <span className="font-medium w-24">{day.label}</span>
                  </div>
                  
                  {schedule[day.key]?.isWorking && (
                    <div className="flex items-center gap-2">
                      <Input
                        type="time"
                        placeholder="09:00"
                        value={schedule[day.key]?.startTime || ''}
                        onChange={(e) => 
                          setSchedule((prev: any) => ({
                            ...prev,
                            [day.key]: { ...prev[day.key], startTime: e.target.value }
                          }))
                        }
                        className="w-24"
                      />
                      <span>-</span>
                      <Input
                        type="time"
                        placeholder="18:00"
                        value={schedule[day.key]?.endTime || ''}
                        onChange={(e) => 
                          setSchedule((prev: any) => ({
                            ...prev,
                            [day.key]: { ...prev[day.key], endTime: e.target.value }
                          }))
                        }
                        className="w-24"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>

            <Button onClick={handleSaveSchedule} disabled={updateScheduleMutation.isPending}>
              {updateScheduleMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
              Сохранить график работы
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}

// Settings Accordion Panel Component
function SettingsAccordionPanel() {
  const [selectedTheme, setSelectedTheme] = useState("light");
  const [terminalColor, setTerminalColor] = useState("#1e40af");
  const [displayColor, setDisplayColor] = useState("#059669");

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
      {/* Left Sidebar with Settings List */}
      <div className="lg:col-span-1">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Настройки</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Accordion type="single" collapsible className="w-full">
              {/* Terminals and Display */}
              <AccordionItem value="terminals">
                <AccordionTrigger className="px-4 py-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Monitor className="h-4 w-4" />
                    Терминалы и Табло
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-2">
                  <div className="space-y-2">
                    <Link href="/terminal-setup">
                      <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                        <Printer className="h-3 w-3 mr-2" />
                        Настройки терминала
                      </Button>
                    </Link>
                    <Link href="/display-setup">
                      <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                        <Tv className="h-3 w-3 mr-2" />
                        Настройки табло
                      </Button>
                    </Link>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* AI Settings */}
              <AccordionItem value="ai">
                <AccordionTrigger className="px-4 py-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Brain className="h-4 w-4" />
                    Настройки ИИ
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-2">
                  <div className="space-y-2">
                    <Link href="/ai-models">
                      <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                        <Cpu className="h-3 w-3 mr-2" />
                        Модели ИИ
                      </Button>
                    </Link>
                    <Link href="/chat-contexts">
                      <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                        <MessageSquare className="h-3 w-3 mr-2" />
                        Контексты чата
                      </Button>
                    </Link>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Voice Settings */}
              <AccordionItem value="voice">
                <AccordionTrigger className="px-4 py-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Volume2 className="h-4 w-4" />
                    Голос и звук
                  </div>
                </AccordionTrigger>
              </AccordionItem>

              {/* Display Board */}
              <AccordionItem value="display-board">
                <AccordionTrigger className="px-4 py-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Monitor className="h-4 w-4" />
                    Управление табло
                  </div>
                </AccordionTrigger>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Area */}
      <div className="lg:col-span-3">
        <Accordion type="single" collapsible className="w-full">
          {/* Terminal Settings Content */}
          <AccordionItem value="terminals">
            <AccordionContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Printer className="h-5 w-5" />
                      Настройки терминала
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Тема интерфейса</Label>
                      <Select value={selectedTheme} onValueChange={setSelectedTheme}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="light">Светлая</SelectItem>
                          <SelectItem value="dark">Темная</SelectItem>
                          <SelectItem value="auto">Автоматическая</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label>Цвет интерфейса</Label>
                      <div className="flex items-center gap-2 mt-2">
                        <Input 
                          type="color" 
                          value={terminalColor}
                          onChange={(e) => setTerminalColor(e.target.value)}
                          className="w-16 h-10"
                        />
                        <Input 
                          value={terminalColor}
                          onChange={(e) => setTerminalColor(e.target.value)}
                          placeholder="#1e40af"
                        />
                      </div>
                    </div>

                    <div>
                      <Label>Размер шрифта</Label>
                      <Select defaultValue="medium">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="small">Маленький</SelectItem>
                          <SelectItem value="medium">Средний</SelectItem>
                          <SelectItem value="large">Большой</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch id="terminal-sounds" />
                      <Label htmlFor="terminal-sounds">Звуковые уведомления</Label>
                    </div>

                    <Button className="w-full">
                      <Save className="h-4 w-4 mr-2" />
                      Сохранить настройки терминала
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Tv className="h-5 w-5" />
                      Настройки табло
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Стиль отображения</Label>
                      <Select defaultValue="modern">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="classic">Классический</SelectItem>
                          <SelectItem value="modern">Современный</SelectItem>
                          <SelectItem value="minimal">Минималистичный</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Цвет фона</Label>
                      <div className="flex items-center gap-2 mt-2">
                        <Input 
                          type="color" 
                          value={displayColor}
                          onChange={(e) => setDisplayColor(e.target.value)}
                          className="w-16 h-10"
                        />
                        <Input 
                          value={displayColor}
                          onChange={(e) => setDisplayColor(e.target.value)}
                          placeholder="#059669"
                        />
                      </div>
                    </div>

                    <div>
                      <Label>Скорость анимации</Label>
                      <Select defaultValue="normal">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="slow">Медленная</SelectItem>
                          <SelectItem value="normal">Обычная</SelectItem>
                          <SelectItem value="fast">Быстрая</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch id="display-animations" defaultChecked />
                      <Label htmlFor="display-animations">Анимации</Label>
                    </div>

                    <Button className="w-full">
                      <Save className="h-4 w-4 mr-2" />
                      Сохранить настройки табло
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* AI Settings Content */}
          <AccordionItem value="ai">
            <AccordionContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Brain className="h-5 w-5" />
                      Модели ИИ
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Активная модель</Label>
                      <Select defaultValue="llama3">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="llama3">Llama 3.2</SelectItem>
                          <SelectItem value="gemma">Gemma 2</SelectItem>
                          <SelectItem value="mistral">Mistral 7B</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Температура (творчество)</Label>
                      <div className="mt-2">
                        <input 
                          type="range" 
                          min="0" 
                          max="1" 
                          step="0.1" 
                          defaultValue="0.7"
                          className="w-full"
                        />
                        <div className="flex justify-between text-xs text-gray-500 mt-1">
                          <span>Точность</span>
                          <span>Творчество</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch id="ai-enabled" defaultChecked />
                      <Label htmlFor="ai-enabled">Включить ИИ помощника</Label>
                    </div>

                    <Button className="w-full">
                      <Save className="h-4 w-4 mr-2" />
                      Сохранить настройки ИИ
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <MessageSquare className="h-5 w-5" />
                      Контексты чата
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Контекст для операторов</Label>
                      <Textarea 
                        placeholder="Ты помощник для операторов системы электронной очереди..."
                        className="min-h-20"
                      />
                    </div>

                    <div>
                      <Label>Контекст для администратора</Label>
                      <Textarea 
                        placeholder="Ты администратор системы с полным доступом..."
                        className="min-h-20"
                      />
                    </div>

                    <Button className="w-full">
                      <Save className="h-4 w-4 mr-2" />
                      Сохранить контексты
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Voice Settings Content */}
          <AccordionItem value="voice">
            <AccordionContent>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Volume2 className="h-5 w-5" />
                    Голосовые настройки
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <VoiceSettingsEnhanced />
                </CardContent>
              </Card>
            </AccordionContent>
          </AccordionItem>

          {/* Display Board Content */}
          <AccordionItem value="display-board">
            <AccordionContent>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Monitor className="h-5 w-5" />
                    Управление электронным табло
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <DisplayBoardSettings />
                </CardContent>
              </Card>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
}

export default function AdminPanel() {
  const { toast } = useToast();

  // Data fetching
  const { data: statistics, isLoading: statisticsLoading } = useQuery({
    queryKey: ['/api/statistics'],
    refetchInterval: 5000,
  });

  const { data: operators, isLoading: operatorsLoading } = useQuery({
    queryKey: ['/api/operators'],
  });

  const { data: departments, isLoading: departmentsLoading } = useQuery({
    queryKey: ['/api/departments'],
  });

  const { data: services, isLoading: servicesLoading } = useQuery({
    queryKey: ['/api/services'],
  });

  const { data: tickets, isLoading: ticketsLoading } = useQuery({
    queryKey: ['/api/tickets'],
    refetchInterval: 3000,
  });

  // Query operator statuses for real-time data  
  const { data: operatorStatuses = [] } = useQuery({
    queryKey: ['/api/operator-statuses'],
    refetchInterval: 3000,
  });

  // Form states for various modals
  const [selectedOperator, setSelectedOperator] = useState<any>(null);
  const [selectedDepartment, setSelectedDepartment] = useState<any>(null);
  const [selectedService, setSelectedService] = useState<any>(null);
  const [operatorDialogOpen, setOperatorDialogOpen] = useState(false);
  const [departmentDialogOpen, setDepartmentDialogOpen] = useState(false);
  const [serviceDialogOpen, setServiceDialogOpen] = useState(false);
  const [activeSettingsSection, setActiveSettingsSection] = useState<string>('');
  const [activeManagementSection, setActiveManagementSection] = useState<string>('');
  const [showWorkScheduleDialog, setShowWorkScheduleDialog] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [showActiveOperatorsModal, setShowActiveOperatorsModal] = useState(false);
  const [workSchedule, setWorkSchedule] = useState<any>({
    monday: { isWorkingDay: true, startTime: '09:00', endTime: '18:00' },
    tuesday: { isWorkingDay: true, startTime: '09:00', endTime: '18:00' },
    wednesday: { isWorkingDay: true, startTime: '09:00', endTime: '18:00' },
    thursday: { isWorkingDay: true, startTime: '09:00', endTime: '18:00' },
    friday: { isWorkingDay: true, startTime: '09:00', endTime: '18:00' },
    saturday: { isWorkingDay: false, startTime: '09:00', endTime: '18:00' },
    sunday: { isWorkingDay: false, startTime: '09:00', endTime: '18:00' }
  });
  const [holidays, setHolidays] = useState<string[]>([]);
  const [selectedScheduleDepartmentId, setSelectedScheduleDepartmentId] = useState<number | null>(null);

  // Form schemas
  const operatorSchema = z.object({
    firstName: z.string().min(1, "Имя обязательно"),
    lastName: z.string().min(1, "Фамилия обязательна"),
    username: z.string().min(3, "Логин должен содержать минимум 3 символа"),
    password: z.string().min(6, "Пароль должен содержать минимум 6 символов"),
    email: z.string().email("Неверный формат email").optional().or(z.literal("")),
    windowNumber: z.string().min(1, "Номер окна обязателен"),
    role: z.enum(["operator", "admin", "supervisor"]),
    department: z.string().min(1, "Отделение обязательно"),
  });

  const departmentSchema = z.object({
    name: z.string().min(1, "Название обязательно"),
    description: z.string().optional(),
    location: z.string().optional(),
    isActive: z.boolean().default(true),
  });

  const serviceSchema = z.object({
    name: z.string().min(1, "Название обязательно"),
    description: z.string().optional(),
    estimatedTime: z.number().min(1, "Время должно быть больше 0"),
    serviceCode: z.string().min(1, "Код услуги обязателен"),
    departmentId: z.string().min(1, "Отделение обязательно"),
    isActive: z.boolean().default(true),
  });

  // Forms
  const operatorForm = useForm<z.infer<typeof operatorSchema>>({
    resolver: zodResolver(operatorSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      username: "",
      password: "",
      email: "",
      windowNumber: "",
      role: "operator",
      department: "",
    },
  });

  const departmentForm = useForm<z.infer<typeof departmentSchema>>({
    resolver: zodResolver(departmentSchema),
    defaultValues: {
      name: "",
      description: "",
      location: "",
      isActive: true,
    },
  });

  const serviceForm = useForm<z.infer<typeof serviceSchema>>({
    resolver: zodResolver(serviceSchema),
    defaultValues: {
      name: "",
      description: "",
      estimatedTime: 10,
      serviceCode: "",
      departmentId: "",
      isActive: true,
    },
  });

  // Mutations
  const createOperatorMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/operators', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/operators'] });
      setOperatorDialogOpen(false);
      operatorForm.reset();
      toast({
        title: "Оператор создан",
        description: "Новый оператор успешно добавлен в систему",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать оператора",
        variant: "destructive",
      });
    },
  });

  const updateOperatorMutation = useMutation({
    mutationFn: async ({ id, ...data }: any) => {
      const response = await apiRequest('PUT', `/api/operators/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/operators'] });
      setOperatorDialogOpen(false);
      setSelectedOperator(null);
      operatorForm.reset();
      toast({
        title: "Оператор обновлен",
        description: "Данные оператора успешно обновлены",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить данные оператора",
        variant: "destructive",
      });
    },
  });

  const deleteOperatorMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/operators/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/operators'] });
      toast({
        title: "Оператор удален",
        description: "Оператор успешно удален из системы",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить оператора",
        variant: "destructive",
      });
    },
  });

  const createDepartmentMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/departments', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/departments'] });
      setDepartmentDialogOpen(false);
      departmentForm.reset();
      toast({
        title: "Отделение создано",
        description: "Новое отделение успешно добавлено",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать отделение",
        variant: "destructive",
      });
    },
  });

  const updateDepartmentMutation = useMutation({
    mutationFn: async ({ id, ...data }: any) => {
      const response = await apiRequest('PUT', `/api/departments/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/departments'] });
      setDepartmentDialogOpen(false);
      setSelectedDepartment(null);
      departmentForm.reset();
      toast({
        title: "Отделение обновлено",
        description: "Данные отделения успешно обновлены",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить отделение",
        variant: "destructive",
      });
    },
  });

  const deleteDepartmentMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/departments/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/departments'] });
      toast({
        title: "Отделение удалено",
        description: "Отделение успешно удалено",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить отделение",
        variant: "destructive",
      });
    },
  });

  const createServiceMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/services', {
        ...data,
        departmentId: parseInt(data.departmentId),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      setShowServiceDialog(false);
      serviceForm.reset();
      toast({
        title: "Услуга создана",
        description: "Новая услуга успешно добавлена",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать услугу",
        variant: "destructive",
      });
    },
  });

  const updateServiceMutation = useMutation({
    mutationFn: async ({ id, ...data }: any) => {
      const response = await apiRequest('PUT', `/api/services/${id}`, {
        ...data,
        departmentId: parseInt(data.departmentId),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      setShowServiceDialog(false);
      setSelectedService(null);
      serviceForm.reset();
      toast({
        title: "Услуга обновлена",
        description: "Данные услуги успешно обновлены",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить услугу",
        variant: "destructive",
      });
    },
  });

  const deleteServiceMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/services/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      toast({
        title: "Услуга удалена",
        description: "Услуга успешно удалена",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить услугу",
        variant: "destructive",
      });
    },
  });

  // Export/Import mutations  
  const exportDataMutation = useMutation({
    mutationFn: async (dataType: string) => {
      const response = await apiRequest('GET', `/api/export/${dataType}`);
      return response.json();
    },
    onSuccess: (data, dataType) => {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${dataType}-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast({ title: `Данные ${dataType} экспортированы` });
    },
    onError: (error: any) => {
      toast({ 
        title: "Ошибка экспорта", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  const importDataMutation = useMutation({
    mutationFn: async ({ dataType, data }: { dataType: string; data: any }) => {
      return apiRequest('POST', `/api/import/${dataType}`, data);
    },
    onSuccess: (_, { dataType }) => {
      queryClient.invalidateQueries({ queryKey: [`/api/${dataType}`] });
      toast({ title: `Данные ${dataType} импортированы` });
    },
    onError: (error: any) => {
      toast({ 
        title: "Ошибка импорта", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  const updateDepartmentScheduleMutation = useMutation({
    mutationFn: async ({ departmentId, scheduleData }: { departmentId: number; scheduleData: any }) => {
      return apiRequest('PUT', `/api/departments/${departmentId}/schedule`, scheduleData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/departments'] });
      toast({ title: "График работы обновлен" });
      setShowWorkScheduleDialog(false);
    },
    onError: (error: any) => {
      toast({ 
        title: "Ошибка при обновлении графика", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  // Helper functions
  const openOperatorDialog = (operator?: any) => {
    if (operator) {
      setSelectedOperator(operator);
      operatorForm.reset({
        firstName: operator.firstName,
        lastName: operator.lastName,
        username: operator.username,
        password: "",
        email: operator.email || "",
        windowNumber: operator.windowNumber?.toString(),
        role: operator.role,
        department: operator.departmentId?.toString(),
      });
    } else {
      setSelectedOperator(null);
      operatorForm.reset();
    }
    setOperatorDialogOpen(true);
  };

  const openDepartmentDialog = (department?: any) => {
    if (department) {
      setSelectedDepartment(department);
      departmentForm.reset({
        name: department.name,
        description: department.description || "",
        location: department.location || "",
        isActive: department.isActive,
      });
    } else {
      setSelectedDepartment(null);
      departmentForm.reset();
    }
    setDepartmentDialogOpen(true);
  };

  const openServiceDialog = (service?: any) => {
    if (service) {
      setSelectedService(service);
      serviceForm.reset({
        name: service.name,
        description: service.description || "",
        estimatedTime: service.estimatedTime,
        serviceCode: service.serviceCode,
        departmentId: service.departmentId?.toString(),
        isActive: service.isActive,
      });
    } else {
      setSelectedService(null);
      serviceForm.reset();
    }
    setServiceDialogOpen(true);
  };

  const handleOperatorSubmit = (values: z.infer<typeof operatorSchema>) => {
    const data = {
      ...values,
      windowNumber: parseInt(values.windowNumber),
      departmentId: parseInt(values.department),
    };

    if (selectedOperator) {
      updateOperatorMutation.mutate({ id: selectedOperator.id, ...data });
    } else {
      createOperatorMutation.mutate(data);
    }
  };

  const handleDepartmentSubmit = (values: z.infer<typeof departmentSchema>) => {
    if (selectedDepartment) {
      updateDepartmentMutation.mutate({ id: selectedDepartment.id, ...values });
    } else {
      createDepartmentMutation.mutate(values);
    }
  };

  const handleServiceSubmit = (values: z.infer<typeof serviceSchema>) => {
    if (selectedService) {
      updateServiceMutation.mutate({ id: selectedService.id, ...values });
    } else {
      createServiceMutation.mutate(values);
    }
  };

  if (statisticsLoading || operatorsLoading || departmentsLoading || servicesLoading) {
    return (
      <PageTransition>
        <div className="min-h-screen">
          <Navigation />
          <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <LoadingSkeleton lines={2} className="max-w-md" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {Array.from({ length: 4 }).map((_, i) => (
                <Card key={i} className="p-6">
                  <LoadingSkeleton lines={3} />
                </Card>
              ))}
            </div>
            <div className="space-y-4">
              <LoadingSkeleton lines={1} className="max-w-xs" />
              <Card className="p-6">
                <LoadingSkeleton lines={6} />
              </Card>
            </div>
          </div>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Административная панель</h1>
          <p className="mt-2 text-gray-600">Управление системой электронной очереди</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              <span className="hidden sm:inline">Обзор</span>
            </TabsTrigger>
            <TabsTrigger value="management" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Управление</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Настройки</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Аналитика</span>
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              <span className="hidden sm:inline">Система и данные</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <AnimatedCard>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Users className="h-8 w-8 text-primary" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">В очереди</p>
                      <p className="text-2xl font-bold text-gray-900">
                        <AnimatedCounter value={(statistics as any)?.activeQueue || 0} />
                      </p>
                    </div>
                  </div>
                </CardContent>
              </AnimatedCard>

              <AnimatedCard>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <CheckCircle className="h-8 w-8 text-green-500" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Обслужено</p>
                      <p className="text-2xl font-bold text-gray-900">
                        <AnimatedCounter value={(statistics as any)?.completedToday || 0} />
                      </p>
                    </div>
                  </div>
                </CardContent>
              </AnimatedCard>

              <AnimatedCard>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Clock className="h-8 w-8 text-yellow-500" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Среднее время</p>
                      <p className="text-2xl font-bold text-gray-900">
                        <AnimatedCounter value={(statistics as any)?.averageWaitTime || 0} /> мин
                      </p>
                    </div>
                  </div>
                </CardContent>
              </AnimatedCard>

              <AnimatedCard>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <UserCheck className="h-8 w-8 text-green-500" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Активные операторы</p>
                      <p className="text-2xl font-bold text-gray-900">
                        <AnimatedCounter value={(operatorStatuses as any[])?.filter((status: any) => status.status === 'available').length || 0} />
                      </p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="mt-2 text-xs"
                        onClick={() => {
                          setShowActiveOperatorsModal(true);
                        }}
                      >
                        Просмотр деталей
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </AnimatedCard>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Быстрые действия</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <Link href="/statistics">
                      <Button className="w-full h-16 flex flex-col" variant="outline">
                        <BarChart3 className="h-6 w-6 mb-2" />
                        Детальная статистика
                      </Button>
                    </Link>
                    
                    <Button className="w-full h-16 flex flex-col" variant="outline" onClick={() => alert('Функция чата с ИИ будет доступна в следующей версии')}>
                      <Brain className="h-6 w-6 mb-2" />
                      Чат с ИИ
                    </Button>

                    <input
                      type="file"
                      id="ticketImportInput"
                      style={{ display: 'none' }}
                      accept=".xlsx,.csv,.json"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          importDataMutation.mutate({ file, type: 'tickets' });
                        }
                      }}
                    />
                    <Button 
                      className="w-full h-16 flex flex-col" 
                      variant="outline" 
                      onClick={() => document.getElementById('ticketImportInput')?.click()}
                    >
                      <FileUp className="h-6 w-6 mb-2" />
                      Импорт талонов
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Operator Messaging in Overview */}
              <OperatorMessagingComponent operators={operators} />
            </div>
          </TabsContent>

          {/* Management Tab - Услуги, Отделения, Операторы, График работы */}
          <TabsContent value="management" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Left Sidebar Navigation */}
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Управление системой</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <AnimatedButton 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => setActiveManagementSection('operators')}
                    >
                      <Users className="h-4 w-4 mr-2" />
                      Операторы
                    </AnimatedButton>
                    <AnimatedButton 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => setActiveManagementSection('departments')}
                    >
                      <Building2 className="h-4 w-4 mr-2" />
                      Отделения
                    </AnimatedButton>
                    <AnimatedButton 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => setActiveManagementSection('services')}
                    >
                      <Ticket className="h-4 w-4 mr-2" />
                      Услуги
                    </AnimatedButton>
                    <AnimatedButton 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => setActiveManagementSection('schedule')}
                    >
                      <Calendar className="h-4 w-4 mr-2" />
                      График работы
                    </AnimatedButton>
                  </CardContent>
                </Card>
              </div>

              {/* Right Content Area */}
              <div className="lg:col-span-3">
                {activeManagementSection === 'operators' && <OperatorsManagementSection operators={operators} exportDataMutation={exportDataMutation} openOperatorDialog={openOperatorDialog} />}
                {activeManagementSection === 'departments' && <DepartmentsManagementSection departments={departments} exportDataMutation={exportDataMutation} openDepartmentDialog={openDepartmentDialog} />}
                {activeManagementSection === 'services' && <ServicesManagementSection services={services} exportDataMutation={exportDataMutation} openServiceDialog={openServiceDialog} />}
                {activeManagementSection === 'schedule' && (
                  <ScheduleManagementSection
                    departments={departments}
                    updateDepartmentScheduleMutation={updateDepartmentScheduleMutation}
                    workSchedule={workSchedule}
                    setWorkSchedule={setWorkSchedule}
                    holidays={holidays}
                    setHolidays={setHolidays}
                    showWorkScheduleDialog={showWorkScheduleDialog}
                    setShowWorkScheduleDialog={setShowWorkScheduleDialog}
                    selectedScheduleDepartmentId={selectedScheduleDepartmentId}
                    setSelectedScheduleDepartmentId={setSelectedScheduleDepartmentId}
                  />
                )}
                
                {!activeManagementSection && (
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <Settings className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">
                          Выберите раздел управления
                        </h3>
                        <p className="text-gray-500">
                          Используйте меню слева для управления различными компонентами системы
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Settings Tab - Система, Терминалы, Печать, Голос, Табло, График работы */}
          <TabsContent value="settings" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Left Sidebar Navigation */}
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Настройки системы</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <AnimatedButton 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => setActiveSettingsSection('terminal')}
                    >
                      <Printer className="h-4 w-4 mr-2" />
                      Терминал
                    </AnimatedButton>
                    <AnimatedButton 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => setActiveSettingsSection('display')}
                    >
                      <Tv className="h-4 w-4 mr-2" />
                      Табло
                    </AnimatedButton>
                    <AnimatedButton 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => setActiveSettingsSection('voice')}
                    >
                      <Volume2 className="h-4 w-4 mr-2" />
                      Голос
                    </AnimatedButton>
                    <AnimatedButton 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => setActiveSettingsSection('ai')}
                    >
                      <Brain className="h-4 w-4 mr-2" />
                      ИИ
                    </AnimatedButton>
                    <AnimatedButton 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => setActiveSettingsSection('board')}
                    >
                      <Monitor className="h-4 w-4 mr-2" />
                      Управление табло
                    </AnimatedButton>
                  </CardContent>
                </Card>
              </div>

              {/* Main Settings Content */}
              <div className="lg:col-span-3">
                {activeSettingsSection === 'terminal' && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Printer className="h-5 w-5" />
                        Настройки терминала
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label>Тема интерфейса</Label>
                          <Select defaultValue="light">
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="light">Светлая</SelectItem>
                              <SelectItem value="dark">Темная</SelectItem>
                              <SelectItem value="auto">Автоматическая</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Label>Основной цвет</Label>
                          <div className="flex items-center gap-2 mt-2">
                            <Input type="color" defaultValue="#1e40af" className="w-16 h-10" />
                            <Input defaultValue="#1e40af" placeholder="Код цвета" />
                          </div>
                        </div>

                        <div>
                          <Label>Размер шрифта</Label>
                          <Select defaultValue="medium">
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="small">Маленький</SelectItem>
                              <SelectItem value="medium">Средний</SelectItem>
                              <SelectItem value="large">Большой</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label>Язык интерфейса</Label>
                          <Select defaultValue="ru">
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ru">Русский</SelectItem>
                              <SelectItem value="en">English</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                          <Switch id="terminal-sounds" />
                          <Label htmlFor="terminal-sounds">Звуковые уведомления</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch id="terminal-animation" defaultChecked />
                          <Label htmlFor="terminal-animation">Анимации интерфейса</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch id="terminal-fullscreen" />
                          <Label htmlFor="terminal-fullscreen">Полноэкранный режим</Label>
                        </div>
                      </div>

                      <AnimatedButton className="w-full">
                        <Save className="h-4 w-4 mr-2" />
                        Сохранить настройки терминала
                      </AnimatedButton>
                    </CardContent>
                  </Card>
                )}

                {activeSettingsSection === 'display' && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Tv className="h-5 w-5" />
                        Настройки табло
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label>Стиль отображения</Label>
                          <Select defaultValue="modern">
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="classic">Классический</SelectItem>
                              <SelectItem value="modern">Современный</SelectItem>
                              <SelectItem value="minimal">Минималистичный</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label>Цвет фона</Label>
                          <div className="flex items-center gap-2 mt-2">
                            <Input type="color" defaultValue="#059669" className="w-16 h-10" />
                            <Input defaultValue="#059669" placeholder="Код цвета" />
                          </div>
                        </div>

                        <div>
                          <Label>Скорость анимации</Label>
                          <Select defaultValue="normal">
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="slow">Медленная</SelectItem>
                              <SelectItem value="normal">Обычная</SelectItem>
                              <SelectItem value="fast">Быстрая</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label>Расположение колонок</Label>
                          <Select defaultValue="equal">
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="equal">Равные размеры</SelectItem>
                              <SelectItem value="left-large">Левая больше</SelectItem>
                              <SelectItem value="right-large">Правая больше</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                          <Switch id="display-animations" defaultChecked />
                          <Label htmlFor="display-animations">Анимации</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch id="display-sound" defaultChecked />
                          <Label htmlFor="display-sound">Звуковые сигналы</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch id="display-auto-scroll" />
                          <Label htmlFor="display-auto-scroll">Автопрокрутка</Label>
                        </div>
                      </div>

                      <AnimatedButton className="w-full">
                        <Save className="h-4 w-4 mr-2" />
                        Сохранить настройки табло
                      </AnimatedButton>
                    </CardContent>
                  </Card>
                )}

                {activeSettingsSection === 'voice' && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Volume2 className="h-5 w-5" />
                        Голосовые настройки
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <VoiceSettingsEnhanced />
                    </CardContent>
                  </Card>
                )}

                {activeSettingsSection === 'ai' && <AISettingsSection />}

                {activeSettingsSection === 'board' && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Monitor className="h-5 w-5" />
                        Управление электронным табло
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <DisplayBoardSettings />
                    </CardContent>
                  </Card>
                )}

                {!activeSettingsSection && (
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <Settings className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">
                          Выберите раздел настроек
                        </h3>
                        <p className="text-gray-500">
                          Используйте меню слева для настройки различных компонентов системы
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-indigo-500" />
                  Статистика и аналитика
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Link href="/statistics">
                  <Button className="w-full justify-start" variant="outline">
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Детальная статистика
                  </Button>
                </Link>
                <Link href="/advanced-statistics">
                  <Button className="w-full justify-start" variant="outline">
                    <Activity className="h-4 w-4 mr-2" />
                    Расширенная аналитика
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5" />
                  Система данных
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button 
                    className="w-full justify-start" 
                    variant="outline"
                    onClick={() => exportDataMutation.mutate('all')}
                    disabled={exportDataMutation.isPending}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Экспорт всех данных
                  </Button>
                  
                  <div>
                    <input
                      type="file"
                      id="dataImportInput"
                      style={{ display: 'none' }}
                      accept=".json,.xlsx,.csv"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          // Определяем тип по имени файла
                          let type = 'unknown';
                          if (file.name.includes('operator')) type = 'operators';
                          else if (file.name.includes('department')) type = 'departments';
                          else if (file.name.includes('service')) type = 'services';
                          else if (file.name.includes('ticket')) type = 'tickets';
                          
                          importDataMutation.mutate({ file, type });
                        }
                      }}
                    />
                    <Button 
                      className="w-full justify-start" 
                      variant="outline"
                      onClick={() => document.getElementById('dataImportInput')?.click()}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Импорт данных
                    </Button>
                  </div>
                </div>
                
                <SystemDataComponent />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Dialog Components */}
        
        <Dialog open={operatorDialogOpen} onOpenChange={setOperatorDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {selectedOperator ? "Редактировать оператора" : "Добавить оператора"}
              </DialogTitle>
              <DialogDescription>
                Заполните информацию об операторе
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left column - Labels */}
              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-1">
                  <h4 className="font-medium">Личные данные</h4>
                  <p className="text-sm text-muted-foreground">Основная информация об операторе</p>
                </div>
                <div className="space-y-1">
                  <h4 className="font-medium">Учетные данные</h4>
                  <p className="text-sm text-muted-foreground">Данные для входа в систему</p>
                </div>
                <div className="space-y-1">
                  <h4 className="font-medium">Роль и отделение</h4>
                  <p className="text-sm text-muted-foreground">Права доступа и привязка к отделению</p>
                </div>
              </div>

              {/* Right column - Form fields */}
              <div className="lg:col-span-2">
                <Form {...operatorForm}>
                  <form onSubmit={operatorForm.handleSubmit(handleOperatorSubmit)} className="space-y-4">
                    <FormField
                      control={operatorForm.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Имя</FormLabel>
                          <FormControl>
                            <Input placeholder="Введите имя" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={operatorForm.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Фамилия</FormLabel>
                          <FormControl>
                            <Input placeholder="Введите фамилию" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={operatorForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Логин</FormLabel>
                          <FormControl>
                            <Input placeholder="Введите логин" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={operatorForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Пароль</FormLabel>
                          <FormControl>
                            <Input 
                              type="password" 
                              placeholder={selectedOperator ? "Оставьте пустым для сохранения текущего" : "Введите пароль"} 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={operatorForm.control}
                      name="windowNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Номер окна</FormLabel>
                          <FormControl>
                            <Input placeholder="1" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={operatorForm.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Роль</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Выберите роль" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="operator">Оператор</SelectItem>
                              <SelectItem value="supervisor">Супервизор</SelectItem>
                              <SelectItem value="admin">Администратор</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={operatorForm.control}
                      name="department"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Отделение</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Выберите отделение" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {((departments as any) || [])?.map((dept: any) => (
                                <SelectItem key={dept.id} value={dept.id.toString()}>
                                  {dept.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button type="button" variant="outline" onClick={() => setOperatorDialogOpen(false)}>
                        Отмена
                      </Button>
                      <Button type="submit" disabled={createOperatorMutation.isPending || updateOperatorMutation.isPending}>
                        {selectedOperator ? "Обновить" : "Создать"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Department Dialog */}
        <Dialog open={departmentDialogOpen} onOpenChange={setDepartmentDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {selectedDepartment ? "Редактировать отделение" : "Добавить отделение"}
              </DialogTitle>
              <DialogDescription>
                Заполните информацию об отделении
              </DialogDescription>
            </DialogHeader>
            <Form {...departmentForm}>
              <form onSubmit={departmentForm.handleSubmit(handleDepartmentSubmit)} className="space-y-4">
                <FormField
                  control={departmentForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Название отделения</FormLabel>
                      <FormControl>
                        <Input placeholder="Введите название отделения" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={departmentForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Описание</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Введите описание отделения" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={departmentForm.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Местоположение</FormLabel>
                      <FormControl>
                        <Input placeholder="Введите адрес или местоположение" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDepartmentDialogOpen(false)}>
                    Отмена
                  </Button>
                  <Button type="submit" disabled={createDepartmentMutation.isPending || updateDepartmentMutation.isPending}>
                    {selectedDepartment ? "Обновить" : "Создать"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Service Dialog */}
        <Dialog open={serviceDialogOpen} onOpenChange={setServiceDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {selectedService ? "Редактировать услугу" : "Добавить услугу"}
              </DialogTitle>
              <DialogDescription>
                Заполните информацию об услуге
              </DialogDescription>
            </DialogHeader>
            <Form {...serviceForm}>
              <form onSubmit={serviceForm.handleSubmit(handleServiceSubmit)} className="space-y-4">
                <FormField
                  control={serviceForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Название услуги</FormLabel>
                      <FormControl>
                        <Input placeholder="Введите название услуги" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="serviceCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Код услуги</FormLabel>
                      <FormControl>
                        <Input placeholder="A, B, C..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Описание</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Введите описание услуги" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="estimatedTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Время обслуживания (минуты)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="10" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="departmentId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Отделение</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Выберите отделение" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {((departments as any) || [])?.map((dept: any) => (
                            <SelectItem key={dept.id} value={dept.id.toString()}>
                              {dept.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setServiceDialogOpen(false)}>
                    Отмена
                  </Button>
                  <Button type="submit" disabled={createServiceMutation.isPending || updateServiceMutation.isPending}>
                    {selectedService ? "Обновить" : "Создать"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Старые статичные формы удалены, заменены на модальные окна */}

        {/* Старые department формы удалены */}
        {false && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>
                {selectedDepartment ? "Редактировать отделение" : "Добавить отделение"}
              </CardTitle>
              <CardDescription>
                Заполните информацию об отделении
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Left column - Labels */}
                <div className="lg:col-span-1 space-y-6">
                  <div className="space-y-1">
                    <h4 className="font-medium">Основная информация</h4>
                    <p className="text-sm text-muted-foreground">Название и описание отделения</p>
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-medium">Статус работы</h4>
                    <p className="text-sm text-muted-foreground">Доступность для клиентов</p>
                  </div>
                </div>

                {/* Right column - Form fields */}
                <div className="lg:col-span-2">
            <Form {...departmentForm}>
              <form onSubmit={departmentForm.handleSubmit(handleDepartmentSubmit)} className="space-y-4">
                <FormField
                  control={departmentForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Название</FormLabel>
                      <FormControl>
                        <Input placeholder="Введите название отделения" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={departmentForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Описание</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Введите описание" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={departmentForm.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Местоположение</FormLabel>
                      <FormControl>
                        <Input placeholder="Введите адрес или местоположение" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={departmentForm.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Активно</FormLabel>
                        <div className="text-sm text-muted-foreground">
                          Отделение принимает клиентов
                        </div>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setDepartmentDialogOpen(false)}>
                    Отмена
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createDepartmentMutation.isPending || updateDepartmentMutation.isPending}
                  >
                    {createDepartmentMutation.isPending || updateDepartmentMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : null}
                    {selectedDepartment ? "Обновить" : "Создать"}
                  </Button>
                </div>
              </form>
            </Form>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Старые service формы удалены */}
        {false && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>
                {selectedService ? "Редактировать услугу" : "Добавить услугу"}
              </CardTitle>
              <CardDescription>
                Заполните информацию об услуге
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Left column - Labels */}
                <div className="lg:col-span-1 space-y-6">
                  <div className="space-y-1">
                    <h4 className="font-medium">Основные данные</h4>
                    <p className="text-sm text-muted-foreground">Название, код и описание услуги</p>
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-medium">Настройки очереди</h4>
                    <p className="text-sm text-muted-foreground">Время обслуживания и приоритет</p>
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-medium">Привязка к отделению</h4>
                    <p className="text-sm text-muted-foreground">Выберите отделение и статус</p>
                  </div>
                </div>

                {/* Right column - Form fields */}
                <div className="lg:col-span-2">
            <Form {...serviceForm}>
              <form onSubmit={serviceForm.handleSubmit(handleServiceSubmit)} className="space-y-4">
                <FormField
                  control={serviceForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Название услуги</FormLabel>
                      <FormControl>
                        <Input placeholder="Введите название услуги" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="serviceCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Код услуги</FormLabel>
                      <FormControl>
                        <Input placeholder="A, B, C..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Описание</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Введите описание услуги" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="estimatedTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Время обслуживания (минуты)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="10" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="departmentId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Отделение</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Выберите отделение" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {((departments as any) || [])?.map((dept: any) => (
                            <SelectItem key={dept.id} value={dept.id.toString()}>
                              {dept.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={serviceForm.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Активна</FormLabel>
                        <div className="text-sm text-muted-foreground">
                          Услуга доступна для записи
                        </div>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setShowServiceDialog(false)}>
                    Отмена
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createServiceMutation.isPending || updateServiceMutation.isPending}
                  >
                    {createServiceMutation.isPending || updateServiceMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : null}
                    {selectedService ? "Обновить" : "Создать"}
                  </Button>
                </div>
              </form>
            </Form>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
    
    {/* Active Operators Modal */}
    <Dialog open={showActiveOperatorsModal} onOpenChange={setShowActiveOperatorsModal}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserCheck className="h-5 w-5" />
            Активные операторы
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          {operators && operatorStatuses ? (
            <div className="grid gap-3">
              {(operators as any[]).map((operator: any) => {
                const status = (operatorStatuses as any[]).find(s => s.operatorId === operator.id);
                const isActive = status?.status === 'available';
                const isOnBreak = status?.status === 'on_break';
                const isOffline = !status || status.status === 'offline';
                
                return (
                  <div key={operator.id} className={`flex items-center justify-between p-3 rounded-lg border ${
                    isActive ? 'bg-green-50 border-green-200' : 
                    isOnBreak ? 'bg-yellow-50 border-yellow-200' : 
                    'bg-gray-50 border-gray-200'
                  }`}>
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${
                        isActive ? 'bg-green-500' : 
                        isOnBreak ? 'bg-yellow-500' : 
                        'bg-gray-400'
                      }`}></div>
                      <div>
                        <p className="font-medium">{operator.firstName} {operator.lastName}</p>
                        <p className="text-sm text-gray-600">Окно {operator.windowNumber}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant={isActive ? 'default' : isOnBreak ? 'secondary' : 'outline'}>
                        {isActive ? 'Активен' : isOnBreak ? 'На перерыве' : 'Оффлайн'}
                      </Badge>
                      {status?.breakReason && (
                        <p className="text-xs text-gray-500 mt-1">{status.breakReason}</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-8">Нет данных об операторах</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
    
    </PageTransition>
  );
}