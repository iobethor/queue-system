import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import Navigation from "@/components/layout/navigation";
import { 
  Calendar, Clock, Users, TrendingUp, 
  Download, FileText, FileSpreadsheet, 
  BarChart3, Activity, Timer, User
} from "lucide-react";
import { format, subDays, startOfDay, endOfDay } from "date-fns";

interface StatisticsFilters {
  dateFrom: string;
  dateTo: string;
  serviceId?: number;
  operatorId?: number;
  departmentId?: number;
}

export default function Statistics() {
  const [filters, setFilters] = useState<StatisticsFilters>({
    dateFrom: format(subDays(new Date(), 7), 'yyyy-MM-dd'),
    dateTo: format(new Date(), 'yyyy-MM-dd')
  });

  const { data: services = [] } = useQuery({
    queryKey: ['/api/services'],
  });

  const { data: operators = [] } = useQuery({
    queryKey: ['/api/operators'],
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['/api/departments'],
  });

  const [showResults, setShowResults] = useState(false);

  const { data: statistics = {}, isLoading } = useQuery({
    queryKey: ['/api/statistics/detailed', filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.dateFrom) params.append('dateFrom', filters.dateFrom);
      if (filters.dateTo) params.append('dateTo', filters.dateTo);
      if (filters.serviceId) params.append('serviceId', filters.serviceId.toString());
      if (filters.operatorId) params.append('operatorId', filters.operatorId.toString());
      if (filters.departmentId) params.append('departmentId', filters.departmentId.toString());
      
      const response = await fetch(`/api/statistics/detailed?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch statistics');
      return response.json();
    },
    enabled: showResults,
  });

  const handleFilterChange = (key: keyof StatisticsFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setShowResults(false); // Reset results when filters change
  };

  const handleShowStatistics = () => {
    setShowResults(true);
  };

  const exportToPDF = async () => {
    try {
      const response = await fetch('/api/statistics/export/pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(filters)
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `statistics_${format(new Date(), 'yyyy-MM-dd')}.pdf`;
        a.click();
        window.URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Error exporting PDF:', error);
    }
  };

  const exportToExcel = async () => {
    try {
      const response = await fetch('/api/statistics/export/excel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(filters)
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `statistics_${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
        a.click();
        window.URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Error exporting Excel:', error);
    }
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Статистика и аналитика</h1>
          <p className="mt-2 text-gray-600">Детальный анализ работы системы электронной очереди</p>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="mr-2 h-5 w-5" />
              Фильтры для анализа
            </CardTitle>
            <CardDescription>
              Настройте параметры для детального анализа статистики
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Дата с</label>
                <Input
                  type="date"
                  value={filters.dateFrom}
                  onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                  data-testid="input-date-from"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Дата по</label>
                <Input
                  type="date"
                  value={filters.dateTo}
                  onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                  data-testid="input-date-to"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Отделение</label>
                <Select onValueChange={(value) => handleFilterChange('departmentId', value === 'all' ? undefined : parseInt(value))}>
                  <SelectTrigger data-testid="select-department">
                    <SelectValue placeholder="Все отделения" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все отделения</SelectItem>
                    {(departments as any[]).map((dept: any) => (
                      <SelectItem key={dept.id} value={dept.id.toString()}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Услуга</label>
                <Select onValueChange={(value) => handleFilterChange('serviceId', value === 'all' ? undefined : parseInt(value))}>
                  <SelectTrigger data-testid="select-service">
                    <SelectValue placeholder="Все услуги" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все услуги</SelectItem>
                    {(services as any[]).map((service: any) => (
                      <SelectItem key={service.id} value={service.id.toString()}>
                        {service.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Оператор</label>
                <Select onValueChange={(value) => handleFilterChange('operatorId', value === 'all' ? undefined : parseInt(value))}>
                  <SelectTrigger data-testid="select-operator">
                    <SelectValue placeholder="Все операторы" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все операторы</SelectItem>
                    {(operators as any[]).map((operator: any) => (
                      <SelectItem key={operator.id} value={operator.id.toString()}>
                        {operator.firstName} {operator.lastName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end gap-2">
                <Button 
                  onClick={handleShowStatistics} 
                  className="bg-primary hover:bg-blue-700 flex-1"
                  data-testid="button-show-statistics"
                >
                  <BarChart3 className="mr-2 h-4 w-4" />
                  Показать
                </Button>
                <Button 
                  onClick={exportToPDF} 
                  variant="outline" 
                  className="flex-1"
                  data-testid="button-export-pdf"
                  disabled={!showResults}
                >
                  <FileText className="mr-2 h-4 w-4" />
                  PDF
                </Button>
                <Button 
                  onClick={exportToExcel} 
                  variant="outline" 
                  className="flex-1"
                  data-testid="button-export-excel"
                  disabled={!showResults}
                >
                  <FileSpreadsheet className="mr-2 h-4 w-4" />
                  Excel
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        {isLoading && (
          <Card className="mb-8">
            <CardContent className="pt-6">
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                <span className="ml-4 text-lg">Загрузка данных статистики...</span>
              </div>
            </CardContent>
          </Card>
        )}

        {showResults && !isLoading && (
          <>
            {/* Overall Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-l-4 border-blue-500">
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Users className="h-8 w-8 text-blue-500" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Всего талонов</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {(statistics as any)?.totalTickets || 0}
                  </p>
                  <p className="text-xs text-gray-500">
                    Обслужено: {(statistics as any)?.totalServed || 0} | 
                    Ожидают: {(statistics as any)?.totalWaiting || 0} | 
                    В процессе: {(statistics as any)?.totalInProgress || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-green-500">
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Timer className="h-8 w-8 text-green-500" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Среднее время ожидания</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {(statistics as any)?.avgWaitTime || 0} мин
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-yellow-500">
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Clock className="h-8 w-8 text-yellow-500" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Среднее время обслуживания</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {(statistics as any)?.avgServiceTime || 0} мин
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-purple-500">
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <TrendingUp className="h-8 w-8 text-purple-500" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Коэффициент удовлетворенности</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {(statistics as any)?.satisfactionRate || 0}%
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Daily Statistics */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="mr-2 h-5 w-5" />
              Статистика по дням
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Дата
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Обслужено
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Ср. время ожидания
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Ср. время обслуживания
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Удовлетворенность
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {(statistics as any)?.dailyStats?.map((day: any, index: number) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {format(new Date(day.date), 'dd.MM.yyyy')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {day.totalServed}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {day.avgWaitTime} мин
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {day.avgServiceTime} мин
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <Badge variant={day.satisfactionRate >= 80 ? "default" : day.satisfactionRate >= 60 ? "secondary" : "destructive"}>
                          {day.satisfactionRate}%
                        </Badge>
                      </td>
                    </tr>
                  )) || (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 text-center text-gray-500">
                        Нет данных за выбранный период
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Service Statistics */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="mr-2 h-5 w-5" />
              Статистика по услугам
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Услуга
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Количество
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Доля
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Ср. время
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Рейтинг
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {(statistics as any)?.serviceStats?.map((service: any, index: number) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {service.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {service.count}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {service.percentage}%
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {service.avgTime} мин
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <Badge variant={service.rating >= 4 ? "default" : service.rating >= 3 ? "secondary" : "destructive"}>
                          {service.rating}/5
                        </Badge>
                      </td>
                    </tr>
                  )) || (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 text-center text-gray-500">
                        Нет данных за выбранный период
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Operator Statistics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <User className="mr-2 h-5 w-5" />
              Статистика по операторам
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Оператор
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Обслужено
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Ср. время на клиента
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Рейтинг
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Эффективность
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {(statistics as any)?.operatorStats?.map((operator: any, index: number) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {operator.firstName} {operator.lastName}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {operator.totalServed}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {operator.avgServiceTime} мин
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <Badge variant={operator.rating >= 4 ? "default" : operator.rating >= 3 ? "secondary" : "destructive"}>
                          {operator.rating}/5
                        </Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <Badge variant={operator.efficiency >= 80 ? "default" : operator.efficiency >= 60 ? "secondary" : "destructive"}>
                          {operator.efficiency}%
                        </Badge>
                      </td>
                    </tr>
                  )) || (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 text-center text-gray-500">
                        Нет данных за выбранный период
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
          </>
        )}
      </div>
    </div>
  );
}