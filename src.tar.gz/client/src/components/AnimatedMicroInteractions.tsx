import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

// Animated Button with micro-interactions
export const AnimatedButton = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<typeof Button> & {
    variant?: any;
    size?: any;
    animate?: boolean;
  }
>(({ className, children, animate = true, ...props }, ref) => {
  return (
    <motion.div
      whileHover={animate ? { scale: 1.02 } : {}}
      whileTap={animate ? { scale: 0.98 } : {}}
      transition={{ duration: 0.1 }}
    >
      <Button
        ref={ref}
        className={cn(
          "transition-all duration-200 hover:shadow-md",
          className
        )}
        {...props}
      >
        {children}
      </Button>
    </motion.div>
  );
});

AnimatedButton.displayName = "AnimatedButton";

// Animated Card with hover effects
export const AnimatedCard = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<typeof Card> & {
    animate?: boolean;
    hoverScale?: number;
  }
>(({ className, children, animate = true, hoverScale = 1.02, ...props }, ref) => {
  return (
    <motion.div
      whileHover={animate ? { scale: hoverScale, y: -2 } : {}}
      transition={{ duration: 0.2 }}
      className="w-full"
    >
      <Card
        ref={ref}
        className={cn(
          "transition-all duration-200 hover:shadow-lg border-0 shadow-sm",
          className
        )}
        {...props}
      >
        {children}
      </Card>
    </motion.div>
  );
});

AnimatedCard.displayName = "AnimatedCard";

// Smooth page transitions
export const PageTransition = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.3 }}
  >
    {children}
  </motion.div>
);

// Staggered list animations
export const StaggeredList = ({ 
  children, 
  staggerDelay = 0.1 
}: { 
  children: React.ReactNode[];
  staggerDelay?: number;
}) => (
  <motion.div
    initial="hidden"
    animate="visible"
    variants={{
      hidden: { opacity: 0 },
      visible: {
        opacity: 1,
        transition: {
          staggerChildren: staggerDelay
        }
      }
    }}
  >
    {React.Children.map(children, (child, index) => (
      <motion.div
        key={index}
        variants={{
          hidden: { opacity: 0, x: -20 },
          visible: { opacity: 1, x: 0 }
        }}
        transition={{ duration: 0.3 }}
      >
        {child}
      </motion.div>
    ))}
  </motion.div>
);

// Loading skeleton with pulse animation
export const LoadingSkeleton = ({ 
  className,
  lines = 3 
}: { 
  className?: string;
  lines?: number;
}) => (
  <div className={cn("space-y-3", className)}>
    {Array.from({ length: lines }).map((_, i) => (
      <motion.div
        key={i}
        className="h-4 bg-gray-200 rounded animate-pulse"
        style={{ width: `${100 - i * 10}%` }}
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ 
          duration: 1.5, 
          repeat: Infinity,
          delay: i * 0.2 
        }}
      />
    ))}
  </div>
);

// Success/Error notification animations
export const NotificationAnimation = ({ 
  type, 
  children 
}: { 
  type: 'success' | 'error' | 'warning';
  children: React.ReactNode;
}) => {
  const colors = {
    success: 'bg-green-500',
    error: 'bg-red-500',
    warning: 'bg-yellow-500'
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: -50 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8, y: -50 }}
        transition={{ type: "spring", duration: 0.5 }}
        className={cn(
          "fixed top-4 right-4 p-4 rounded-lg text-white shadow-lg z-50",
          colors[type]
        )}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
};

// Floating action button with ripple effect
export const FloatingButton = ({ 
  children, 
  onClick,
  className 
}: { 
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
}) => (
  <motion.button
    whileHover={{ scale: 1.1 }}
    whileTap={{ scale: 0.9 }}
    className={cn(
      "fixed bottom-6 right-6 w-14 h-14 bg-primary text-white rounded-full shadow-lg",
      "flex items-center justify-center z-50 hover:shadow-xl transition-shadow",
      className
    )}
    onClick={onClick}
    animate={{
      boxShadow: [
        "0 4px 8px rgba(0,0,0,0.1)",
        "0 6px 12px rgba(0,0,0,0.15)",
        "0 4px 8px rgba(0,0,0,0.1)"
      ]
    }}
    transition={{ duration: 2, repeat: Infinity }}
  >
    {children}
  </motion.button>
);

// Counter with number animation
export const AnimatedCounter = ({ 
  value, 
  className 
}: { 
  value: number;
  className?: string;
}) => (
  <motion.span
    key={value}
    initial={{ scale: 1.2, color: '#10b981' }}
    animate={{ scale: 1, color: '#374151' }}
    transition={{ duration: 0.3 }}
    className={className}
  >
    {value}
  </motion.span>
);

// Progress bar with smooth animation
export const AnimatedProgress = ({ 
  value, 
  max = 100,
  className 
}: { 
  value: number;
  max?: number;
  className?: string;
}) => (
  <div className={cn("w-full bg-gray-200 rounded-full h-2", className)}>
    <motion.div
      className="bg-primary h-2 rounded-full"
      initial={{ width: 0 }}
      animate={{ width: `${(value / max) * 100}%` }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    />
  </div>
);

// Icon with bounce animation
export const BouncingIcon = ({ 
  children,
  trigger = false 
}: { 
  children: React.ReactNode;
  trigger?: boolean;
}) => (
  <motion.div
    animate={trigger ? { 
      scale: [1, 1.2, 1],
      rotate: [0, 10, -10, 0]
    } : {}}
    transition={{ duration: 0.6 }}
  >
    {children}
  </motion.div>
);