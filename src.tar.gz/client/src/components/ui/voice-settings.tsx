import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { speechService, VoiceSettings } from "@/services/speechService";
import { Volume2, VolumeX, TestTube, Radio, Headphones } from "lucide-react";

interface VoiceSettingsProps {
  onSettingsChange?: (settings: VoiceSettings) => void;
}

export function VoiceSettingsCard({ onSettingsChange }: VoiceSettingsProps) {
  const [isEnabled, setIsEnabled] = useState(true);
  const [settings, setSettings] = useState<VoiceSettings>(speechService.getSettings());
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [rhvoiceVoices, setRhvoiceVoices] = useState<string[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<string>('');
  const [isTesting, setIsTesting] = useState(false);
  const [isRhvoiceAvailable, setIsRhvoiceAvailable] = useState(false);

  useEffect(() => {
    // Загружаем голоса при инициализации
    const loadVoices = async () => {
      const availableVoices = speechService.getVoices();
      setVoices(availableVoices);
      
      // Загружаем RHVoice голоса
      const rhVoices = await speechService.getRHVoiceVoices();
      setRhvoiceVoices(rhVoices);
      
      // Проверяем доступность RHVoice
      const rhAvailable = await speechService.isRHVoiceAvailable();
      setIsRhvoiceAvailable(rhAvailable);
      
      const bestVoice = speechService.getBestRussianFemaleVoice();
      if (bestVoice) {
        setSelectedVoice(bestVoice.name);
      }
    };

    loadVoices();
    
    // Слушаем событие загрузки голосов (для некоторых браузеров)
    if ('speechSynthesis' in window) {
      speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  const handleSettingChange = (key: keyof VoiceSettings, value: any) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    speechService.updateSettings(newSettings);
    onSettingsChange?.(newSettings);
  };

  const handleVoiceChange = (voiceName: string) => {
    setSelectedVoice(voiceName);
    if (settings.engine === 'rhvoice') {
      handleSettingChange('rhvoiceVoice', voiceName);
      speechService.setRHVoiceVoice(voiceName);
    } else {
      handleSettingChange('voiceName', voiceName);
    }
  };

  const handleEngineChange = (engine: 'rhvoice' | 'browser') => {
    handleSettingChange('engine', engine);
    speechService.setEngine(engine);
  };

  const toggleEnabled = (enabled: boolean) => {
    setIsEnabled(enabled);
    speechService.setEnabled(enabled);
  };

  const testVoice = async () => {
    if (isTesting) return;
    
    setIsTesting(true);
    try {
      await speechService.testAnnouncement();
    } catch (error) {
      console.error('Ошибка тестирования голоса:', error);
    } finally {
      setIsTesting(false);
    }
  };

  if (!speechService.isSupported()) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <VolumeX className="w-5 h-5" />
            Голосовые объявления
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Ваш браузер не поддерживает голосовые объявления
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {isEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          Голосовые объявления
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Включение/выключение */}
        <div className="flex items-center justify-between">
          <Label htmlFor="voice-enabled">Включить голосовые объявления</Label>
          <Switch
            id="voice-enabled"
            checked={isEnabled}
            onCheckedChange={toggleEnabled}
          />
        </div>

        {isEnabled && (
          <>
            {/* Движок синтеза речи */}
            <div className="space-y-3">
              <Label>Движок синтеза речи</Label>
              <div className="flex gap-2">
                <Button
                  variant={settings.engine === 'rhvoice' ? 'default' : 'outline'}
                  onClick={() => handleEngineChange('rhvoice')}
                  className="flex-1"
                  disabled={!isRhvoiceAvailable}
                >
                  <Radio className="w-4 h-4 mr-2" />
                  RHVoice
                  {!isRhvoiceAvailable && <Badge variant="destructive" className="ml-2">Недоступен</Badge>}
                  {isRhvoiceAvailable && <Badge variant="secondary" className="ml-2">Премиум</Badge>}
                </Button>
                <Button
                  variant={settings.engine === 'browser' ? 'default' : 'outline'}
                  onClick={() => handleEngineChange('browser')}
                  className="flex-1"
                >
                  <Headphones className="w-4 h-4 mr-2" />
                  Браузер
                </Button>
              </div>
            </div>

            {/* Выбор голоса */}
            <div className="space-y-2">
              <Label>
                {settings.engine === 'rhvoice' ? 'RHVoice голос' : 'Голос браузера'}
              </Label>
              <Select value={selectedVoice} onValueChange={handleVoiceChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Выберите голос" />
                </SelectTrigger>
                <SelectContent>
                  {settings.engine === 'rhvoice' ? (
                    rhvoiceVoices.map((voice) => (
                      <SelectItem key={voice} value={voice}>
                        {voice} (RHVoice)
                      </SelectItem>
                    ))
                  ) : (
                    voices
                      .filter(voice => voice.lang.startsWith('ru') || voice.lang.startsWith('en'))
                      .map((voice) => (
                        <SelectItem key={voice.name} value={voice.name}>
                          {voice.name} ({voice.lang})
                        </SelectItem>
                      ))
                  )}
                </SelectContent>
              </Select>
            </div>

            {/* Скорость речи */}
            <div className="space-y-2">
              <Label>Скорость речи: {settings.rate.toFixed(1)}x</Label>
              <Slider
                value={[settings.rate]}
                onValueChange={(value) => handleSettingChange('rate', value[0])}
                min={0.5}
                max={2}
                step={0.1}
                className="w-full"
              />
            </div>

            {/* Высота тона */}
            <div className="space-y-2">
              <Label>Высота тона: {settings.pitch.toFixed(1)}</Label>
              <Slider
                value={[settings.pitch]}
                onValueChange={(value) => handleSettingChange('pitch', value[0])}
                min={0.5}
                max={2}
                step={0.1}
                className="w-full"
              />
            </div>

            {/* Громкость */}
            <div className="space-y-2">
              <Label>Громкость: {Math.round(settings.volume * 100)}%</Label>
              <Slider
                value={[settings.volume]}
                onValueChange={(value) => handleSettingChange('volume', value[0])}
                min={0}
                max={1}
                step={0.1}
                className="w-full"
              />
            </div>

            {/* Тест */}
            <Button
              onClick={testVoice}
              disabled={isTesting}
              variant="outline"
              className="w-full"
            >
              <TestTube className="w-4 h-4 mr-2" />
              {isTesting ? 'Воспроизведение...' : 'Тест голоса'}
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}