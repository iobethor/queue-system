import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './card';
import { Button } from './button';
import { Label } from './label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './select';
import { Slider } from './slider';
import { Switch } from './switch';
import { Volume2, Settings, TestTube, Loader2, CheckCircle, XCircle } from 'lucide-react';
import { Badge } from './badge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';

interface VoiceSettings {
  id: number;
  engine: string;
  voiceName: string;
  rate: number;
  pitch: number;
  volume: number;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}

interface Voice {
  name: string;
  displayName: string;
  language: string;
  gender: string;
}

interface RHVoiceHealth {
  status: string;
  voices?: number;
  version?: string;
}

export function VoiceSettingsEnhanced() {
  const [isTesting, setIsTesting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Загрузка текущих настроек голоса
  const { data: settings, isLoading: settingsLoading } = useQuery<VoiceSettings>({
    queryKey: ['/api/voice-settings'],
    retry: 3,
  });

  // Загрузка доступных голосов RHVoice
  const { data: voices, isLoading: voicesLoading } = useQuery<Voice[]>({
    queryKey: ['/api/rhvoice/voices'],
    retry: 2,
  });

  // Проверка состояния RHVoice
  const { data: rhvoiceHealth } = useQuery<RHVoiceHealth>({
    queryKey: ['/api/rhvoice/health'],
    retry: 1,
    refetchInterval: 30000, // проверяем каждые 30 секунд
  });

  // Мутация для обновления настроек
  const updateSettingsMutation = useMutation({
    mutationFn: async (newSettings: Partial<VoiceSettings>) => {
      const response = await fetch('/api/voice-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings),
      });
      if (!response.ok) throw new Error('Не удалось обновить настройки');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/voice-settings'] });
      toast({
        title: "Настройки обновлены",
        description: "Настройки голоса успешно сохранены",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить настройки голоса",
        variant: "destructive",
      });
    },
  });

  const handleSettingChange = (key: keyof VoiceSettings, value: any) => {
    if (!settings) return;
    updateSettingsMutation.mutate({ [key]: value });
  };

  const testVoice = async () => {
    if (!settings) return;
    
    setIsTesting(true);
    try {
      const response = await fetch('/api/rhvoice/say', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: `Талон П1-01, пройдите к оператору Мария Петровна, окно номер 3`,
          voice: settings.voiceName,
          rate: settings.rate,
          pitch: settings.pitch,
          volume: settings.volume,
          format: 'wav'
        }),
      });

      if (response.ok) {
        const audioBlob = await response.blob();
        const audioUrl = URL.createObjectURL(audioBlob);
        const audio = new Audio(audioUrl);
        
        audio.onended = () => {
          URL.revokeObjectURL(audioUrl);
          setIsTesting(false);
        };
        
        audio.onerror = () => {
          URL.revokeObjectURL(audioUrl);
          setIsTesting(false);
          toast({
            title: "Ошибка воспроизведения",
            description: "Не удалось воспроизвести тестовое сообщение",
            variant: "destructive",
          });
        };
        
        await audio.play();
        
        toast({
          title: "Тест голоса",
          description: "Тестовое сообщение воспроизводится",
        });
      } else {
        throw new Error('Ошибка синтеза речи');
      }
    } catch (error) {
      setIsTesting(false);
      toast({
        title: "Ошибка теста",
        description: "Не удалось выполнить тест голоса",
        variant: "destructive",
      });
    }
  };

  if (settingsLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin" />
            <span className="ml-2">Загрузка настроек...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!settings) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">
            Настройки голоса не найдены
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Volume2 className="w-5 h-5" />
              Настройки голоса RHVoice
            </CardTitle>
            <CardDescription>
              Настройка локального синтезатора речи для русских объявлений
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {rhvoiceHealth?.status === 'ok' ? (
              <Badge variant="default" className="bg-green-500">
                <CheckCircle className="w-3 h-3 mr-1" />
                Активен
              </Badge>
            ) : (
              <Badge variant="destructive">
                <XCircle className="w-3 h-3 mr-1" />
                Недоступен
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Включение/выключение */}
        <div className="flex items-center justify-between">
          <div>
            <Label className="font-medium">Включить голосовые объявления</Label>
            <p className="text-sm text-gray-500 mt-1">
              Автоматические голосовые объявления при вызове клиентов
            </p>
          </div>
          <Switch
            checked={settings.enabled}
            onCheckedChange={(enabled) => handleSettingChange('enabled', enabled)}
            disabled={updateSettingsMutation.isPending}
          />
        </div>

        {settings.enabled && (
          <>
            {/* Выбор движка */}
            <div className="space-y-2">
              <Label>Движок синтеза речи</Label>
              <Select
                value={settings.engine}
                onValueChange={(value) => handleSettingChange('engine', value)}
                disabled={updateSettingsMutation.isPending}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem key="rhvoice" value="rhvoice">RHVoice (локальный)</SelectItem>
                  <SelectItem key="browser" value="browser">Browser Speech API</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {settings.engine === 'rhvoice' && (
              <>
                {/* Выбор голоса */}
                <div className="space-y-2">
                  <Label>Голос</Label>
                  {voicesLoading ? (
                    <div className="flex items-center text-sm text-gray-500">
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Загрузка голосов...
                    </div>
                  ) : voices && voices.length > 0 ? (
                    <Select
                      value={settings.voiceName}
                      onValueChange={(value) => handleSettingChange('voiceName', value)}
                      disabled={updateSettingsMutation.isPending}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {voices.map((voice) => (
                          <SelectItem key={voice.name} value={voice.name}>
                            {voice.displayName} ({voice.gender}, {voice.language})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="text-sm text-red-500">
                      RHVoice голоса недоступны
                    </div>
                  )}
                </div>

                {/* Скорость речи */}
                <div className="space-y-2">
                  <Label>Скорость речи: {settings.rate}%</Label>
                  <Slider
                    value={[settings.rate]}
                    onValueChange={(value) => handleSettingChange('rate', value[0])}
                    min={50}
                    max={200}
                    step={10}
                    className="w-full"
                    disabled={updateSettingsMutation.isPending}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Медленно (50%)</span>
                    <span>Быстро (200%)</span>
                  </div>
                </div>

                {/* Высота тона */}
                <div className="space-y-2">
                  <Label>Высота тона: {settings.pitch}%</Label>
                  <Slider
                    value={[settings.pitch]}
                    onValueChange={(value) => handleSettingChange('pitch', value[0])}
                    min={50}
                    max={200}
                    step={10}
                    className="w-full"
                    disabled={updateSettingsMutation.isPending}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Низкий (50%)</span>
                    <span>Высокий (200%)</span>
                  </div>
                </div>

                {/* Громкость */}
                <div className="space-y-2">
                  <Label>Громкость: {settings.volume}%</Label>
                  <Slider
                    value={[settings.volume]}
                    onValueChange={(value) => handleSettingChange('volume', value[0])}
                    min={10}
                    max={100}
                    step={5}
                    className="w-full"
                    disabled={updateSettingsMutation.isPending}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Тихо (10%)</span>
                    <span>Громко (100%)</span>
                  </div>
                </div>

                {/* Статус RHVoice */}
                {rhvoiceHealth && (
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h4 className="font-medium mb-2">Статус RHVoice</h4>
                    <div className="text-sm space-y-1">
                      <div>Статус: <Badge variant={rhvoiceHealth.status === 'ok' ? 'default' : 'destructive'}>{rhvoiceHealth.status}</Badge></div>
                      {rhvoiceHealth.voices && <div>Доступно голосов: {rhvoiceHealth.voices}</div>}
                      {rhvoiceHealth.version && <div>Версия: {rhvoiceHealth.version}</div>}
                    </div>
                  </div>
                )}

                {/* Тест голоса */}
                <Button
                  onClick={testVoice}
                  disabled={isTesting || updateSettingsMutation.isPending || rhvoiceHealth?.status !== 'ok'}
                  variant="outline"
                  className="w-full"
                >
                  {isTesting ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <TestTube className="w-4 h-4 mr-2" />
                  )}
                  {isTesting ? 'Воспроизведение...' : 'Тест голоса'}
                </Button>
              </>
            )}
          </>
        )}

        {/* Информация о голосовых объявлениях */}
        <div className="p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">Формат объявлений</h4>
          <p className="text-sm text-blue-700">
            Пример: "Талон П1-01, пройдите к оператору Мария Петровна, окно номер 3"
          </p>
          <p className="text-xs text-blue-600 mt-2">
            Объявления автоматически воспроизводятся при вызове клиентов операторами
          </p>
        </div>
      </CardContent>
    </Card>
  );
}