import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { Monitor, Settings, Plus, Edit2, Trash2, TestTube } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface DisplayBoardSettings {
  id?: number;
  portPath: string;
  baudRate: number;
  enabled: boolean;
}

interface DisplayBoard {
  id: number;
  address: number;
  operatorId: number;
  windowNumber: number;
  name?: string;
  enabled: boolean;
  currentTicket?: string;
}

interface Operator {
  id: number;
  firstName: string;
  lastName: string;
  windowNumber?: number;
}

export function DisplayBoardSettings() {
  const [settings, setSettings] = useState<DisplayBoardSettings>({
    portPath: '/dev/ttyUSB0',
    baudRate: 9600,
    enabled: false
  });
  const [boards, setBoards] = useState<DisplayBoard[]>([]);
  const [operators, setOperators] = useState<Operator[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editingBoard, setEditingBoard] = useState<DisplayBoard | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newBoard, setNewBoard] = useState<Partial<DisplayBoard>>({
    address: 1,
    windowNumber: 1,
    enabled: true,
    name: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchSettings();
    fetchBoards();
    fetchOperators();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/display-board-settings');
      if (response.ok) {
        const data = await response.json();
        setSettings(data);
      }
    } catch (error) {
      console.error('Ошибка загрузки настроек табло:', error);
    }
  };

  const fetchBoards = async () => {
    try {
      const response = await fetch('/api/display-boards');
      if (response.ok) {
        const data = await response.json();
        setBoards(data);
      }
    } catch (error) {
      console.error('Ошибка загрузки списка табло:', error);
    }
  };

  const fetchOperators = async () => {
    try {
      const response = await fetch('/api/operators');
      if (response.ok) {
        const data = await response.json();
        setOperators(data);
      }
    } catch (error) {
      console.error('Ошибка загрузки операторов:', error);
    }
  };

  const saveSettings = async () => {
    try {
      const response = await fetch('/api/display-board-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });

      if (response.ok) {
        toast({
          title: 'Настройки сохранены',
          description: 'Настройки табло успешно обновлены'
        });
      } else {
        toast({
          title: 'Ошибка',
          description: 'Не удалось сохранить настройки',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Ошибка',
        description: 'Произошла ошибка при сохранении',
        variant: 'destructive'
      });
    }
  };

  const createBoard = async () => {
    if (!newBoard.operatorId) {
      toast({
        title: 'Ошибка',
        description: 'Выберите оператора',
        variant: 'destructive'
      });
      return;
    }

    try {
      const response = await fetch('/api/display-boards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newBoard)
      });

      if (response.ok) {
        await fetchBoards();
        setIsDialogOpen(false);
        setNewBoard({
          address: 1,
          windowNumber: 1,
          enabled: true,
          name: ''
        });
        toast({
          title: 'Табло создано',
          description: 'Новое табло успешно добавлено'
        });
      } else {
        toast({
          title: 'Ошибка',
          description: 'Не удалось создать табло',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Ошибка',
        description: 'Произошла ошибка при создании табло',
        variant: 'destructive'
      });
    }
  };

  const updateBoard = async (board: DisplayBoard) => {
    try {
      const response = await fetch(`/api/display-boards/${board.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(board)
      });

      if (response.ok) {
        await fetchBoards();
        setEditingBoard(null);
        toast({
          title: 'Табло обновлено',
          description: 'Настройки табло успешно сохранены'
        });
      }
    } catch (error) {
      toast({
        title: 'Ошибка',
        description: 'Не удалось обновить табло',
        variant: 'destructive'
      });
    }
  };

  const deleteBoard = async (id: number) => {
    if (!confirm('Удалить табло?')) return;

    try {
      const response = await fetch(`/api/display-boards/${id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        await fetchBoards();
        toast({
          title: 'Табло удалено',
          description: 'Табло успешно удалено'
        });
      }
    } catch (error) {
      toast({
        title: 'Ошибка',
        description: 'Не удалось удалить табло',
        variant: 'destructive'
      });
    }
  };

  const testConnection = async () => {
    toast({
      title: 'Тестирование',
      description: 'Отправка тестового сигнала на табло...'
    });
    // Здесь будет логика тестирования соединения
  };

  const getOperatorName = (operatorId: number) => {
    const operator = operators.find(op => op.id === operatorId);
    return operator ? `${operator.firstName} ${operator.lastName}` : 'Неизвестен';
  };

  const availableOperators = operators.filter(op => 
    !boards.some(board => board.operatorId === op.id) || 
    editingBoard?.operatorId === op.id
  );

  return (
    <div className="max-w-6xl mx-auto space-y-6" data-testid="display-board-settings">
      {/* Заголовок секции */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Настройки табло</h2>
          <p className="text-gray-600">Управление аппаратными табло через COM порт</p>
        </div>
        <Badge variant={settings.enabled ? "default" : "secondary"}>
          {settings.enabled ? "Активно" : "Отключено"}
        </Badge>
      </div>

      {/* Основные настройки */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Настройки подключения табло
          </CardTitle>
          <CardDescription>
            Конфигурация COM-порта для управления электронными табло
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="port-path">COM-порт</Label>
              <Input
                id="port-path"
                value={settings.portPath}
                onChange={(e) => setSettings({ ...settings, portPath: e.target.value })}
                placeholder="/dev/ttyUSB0"
                data-testid="input-port-path"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="baud-rate">Скорость (baud)</Label>
              <Select
                value={settings.baudRate.toString()}
                onValueChange={(value) => setSettings({ ...settings, baudRate: parseInt(value) })}
              >
                <SelectTrigger data-testid="select-baud-rate">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="9600">9600</SelectItem>
                  <SelectItem value="19200">19200</SelectItem>
                  <SelectItem value="38400">38400</SelectItem>
                  <SelectItem value="57600">57600</SelectItem>
                  <SelectItem value="115200">115200</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch
              id="enabled"
              checked={settings.enabled}
              onCheckedChange={(checked) => setSettings({ ...settings, enabled: checked })}
              data-testid="switch-enabled"
            />
            <Label htmlFor="enabled">Включить табло</Label>
          </div>

          <div className="flex gap-2">
            <Button onClick={saveSettings} data-testid="button-save-settings">
              Сохранить настройки
            </Button>
            <Button variant="outline" onClick={testConnection} data-testid="button-test-connection">
              <TestTube className="h-4 w-4 mr-2" />
              Тест соединения
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Список табло */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Monitor className="h-5 w-5" />
              Конфигурация табло
            </CardTitle>
            <CardDescription>
              Управление электронными табло для каждого оператора
            </CardDescription>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-board">
                <Plus className="h-4 w-4 mr-2" />
                Добавить табло
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Новое табло</DialogTitle>
                <DialogDescription>
                  Создайте новое электронное табло для отображения номеров билетов
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Адрес табло</Label>
                    <Input
                      type="number"
                      min="1"
                      max="254"
                      value={newBoard.address}
                      onChange={(e) => setNewBoard({ ...newBoard, address: parseInt(e.target.value) })}
                      data-testid="input-new-address"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Номер окна</Label>
                    <Input
                      type="number"
                      min="1"
                      value={newBoard.windowNumber}
                      onChange={(e) => setNewBoard({ ...newBoard, windowNumber: parseInt(e.target.value) })}
                      data-testid="input-new-window"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Оператор</Label>
                  <Select
                    value={newBoard.operatorId?.toString()}
                    onValueChange={(value) => setNewBoard({ ...newBoard, operatorId: parseInt(value) })}
                  >
                    <SelectTrigger data-testid="select-new-operator">
                      <SelectValue placeholder="Выберите оператора" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableOperators.map(operator => (
                        <SelectItem key={operator.id} value={operator.id.toString()}>
                          {operator.firstName} {operator.lastName} 
                          {operator.windowNumber && ` (Окно ${operator.windowNumber})`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Название (необязательно)</Label>
                  <Input
                    value={newBoard.name}
                    onChange={(e) => setNewBoard({ ...newBoard, name: e.target.value })}
                    placeholder="Описание табло"
                    data-testid="input-new-name"
                  />
                </div>

                <Button onClick={createBoard} className="w-full" data-testid="button-create-board">
                  Создать табло
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {boards.map((board) => (
              <Card key={board.id} className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    {editingBoard?.id === board.id ? (
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label className="text-sm">Адрес</Label>
                          <Input
                            type="number"
                            min="1"
                            max="254"
                            value={editingBoard.address}
                            onChange={(e) => setEditingBoard({ 
                              ...editingBoard, 
                              address: parseInt(e.target.value) 
                            })}
                            data-testid={`input-edit-address-${board.id}`}
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Окно</Label>
                          <Input
                            type="number"
                            min="1"
                            value={editingBoard.windowNumber}
                            onChange={(e) => setEditingBoard({ 
                              ...editingBoard, 
                              windowNumber: parseInt(e.target.value) 
                            })}
                            data-testid={`input-edit-window-${board.id}`}
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Название</Label>
                          <Input
                            value={editingBoard.name || ''}
                            onChange={(e) => setEditingBoard({ 
                              ...editingBoard, 
                              name: e.target.value 
                            })}
                            data-testid={`input-edit-name-${board.id}`}
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="flex items-center gap-4">
                          <Badge variant={board.enabled ? 'default' : 'secondary'}>
                            Адрес {board.address}
                          </Badge>
                          <span className="text-sm text-muted-foreground">
                            Окно {board.windowNumber}
                          </span>
                          <span className="font-medium">
                            {getOperatorName(board.operatorId)}
                          </span>
                        </div>
                        {board.name && (
                          <p className="text-sm text-muted-foreground">{board.name}</p>
                        )}
                        {board.currentTicket && (
                          <Badge variant="outline">
                            Текущий талон: {board.currentTicket}
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {editingBoard?.id === board.id ? (
                      <>
                        <Button 
                          size="sm" 
                          onClick={() => updateBoard(editingBoard)}
                          data-testid={`button-save-${board.id}`}
                        >
                          Сохранить
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => setEditingBoard(null)}
                          data-testid={`button-cancel-${board.id}`}
                        >
                          Отмена
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => setEditingBoard(board)}
                          data-testid={`button-edit-${board.id}`}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => deleteBoard(board.id)}
                          data-testid={`button-delete-${board.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </Card>
            ))}
            
            {boards.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <Monitor className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>Табло не настроены</p>
                <p className="text-sm">Добавьте первое табло для начала работы</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}