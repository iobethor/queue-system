import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  ClipboardList, CalendarPlus, Monitor, Headset, 
  Tv, Settings, Home, UserCircle, Users, Menu, HelpCircle
} from "lucide-react";

export default function Navigation() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  // Collapse menu by default on dashboard page to avoid duplication
  const [isMenuCollapsed, setIsMenuCollapsed] = useState(location === "/" || location === "");

  // Auto-collapse menu when navigating to dashboard
  useEffect(() => {
    if (location === "/" || location === "") {
      setIsMenuCollapsed(true);
    } else {
      // Auto-expand menu on other pages unless manually collapsed
      setIsMenuCollapsed(false);
    }
  }, [location]);

  const navItems = [
    { href: "/", label: "Главная", icon: Home },
    { href: "/booking", label: "Запись", icon: CalendarPlus },
    { href: "/terminal", label: "Терминал", icon: Monitor },
    { href: "/operator", label: "Оператор", icon: Headset },
    { href: "/display", label: "Табло", icon: Tv },
    { href: "/hall-admin", label: "Админ зала", icon: Users },
    { href: "/admin", label: "Админ", icon: Settings },
    { href: "/help", label: "Справка", icon: HelpCircle },
  ];

  return (
    <nav className="bg-white shadow-lg border-b-2 border-primary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* First row: Title */}
        <div className="flex justify-between items-center h-14 border-b border-gray-100">
          <div className="flex items-center">
            <ClipboardList className="h-6 w-6 sm:h-8 sm:w-8 text-primary mr-2 sm:mr-3" />
            <span className="text-lg sm:text-xl font-bold text-gray-900 hidden sm:block">
              Система электронной очереди
            </span>
            <span className="text-sm font-bold text-gray-900 sm:hidden">
              СЭО
            </span>
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <UserCircle className="mr-2 h-5 w-5" />
            <span className="hidden lg:inline">Администратор</span>
          </div>
        </div>

        {/* Second row: Navigation */}
        <div className="flex justify-between h-12">
          <div className="flex items-center">
            {/* Desktop menu toggle button */}
            <div className="hidden md:block">
              {(location === "/" || location === "") ? (
                // Always show dropdown menu on dashboard
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-gray-700 hover:text-primary"
                      data-testid="button-menu-dropdown"
                      title="Открыть меню"
                    >
                      <Menu className="h-5 w-5" />
                      <span className="ml-2 text-sm">Навигация</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-56 z-50 bg-white shadow-lg border">
                    {navItems.map((item) => {
                      const Icon = item.icon;
                      const isActive = location === item.href || 
                        (item.href !== "/" && location.startsWith(item.href));
                      
                      return (
                        <Link key={item.href} href={item.href}>
                          <DropdownMenuItem className={`cursor-pointer ${
                            isActive ? 'bg-blue-50 text-primary' : ''
                          }`}>
                            <Icon className="mr-2 h-4 w-4" />
                            {item.label}
                          </DropdownMenuItem>
                        </Link>
                      );
                    })}
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                // Show toggle button on other pages
                isMenuCollapsed ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-gray-700 hover:text-primary"
                        data-testid="button-menu-dropdown"
                        title="Открыть меню"
                      >
                        <Menu className="h-5 w-5" />
                        <span className="ml-2 text-sm">Навигация</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" className="w-56 z-50 bg-white shadow-lg border">
                      {navItems.map((item) => {
                        const Icon = item.icon;
                        const isActive = location === item.href || 
                          (item.href !== "/" && location.startsWith(item.href));
                        
                        return (
                          <Link key={item.href} href={item.href}>
                            <DropdownMenuItem className={`cursor-pointer ${
                              isActive ? 'bg-blue-50 text-primary' : ''
                            }`}>
                              <Icon className="mr-2 h-4 w-4" />
                              {item.label}
                            </DropdownMenuItem>
                          </Link>
                        );
                      })}
                      <DropdownMenuItem 
                        onClick={() => setIsMenuCollapsed(false)}
                        className="cursor-pointer border-t mt-2 pt-2"
                      >
                        <Menu className="mr-2 h-4 w-4" />
                        Развернуть меню
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsMenuCollapsed(true)}
                    className="text-gray-700 hover:text-primary"
                    data-testid="button-collapse-menu"
                    title="Свернуть меню"
                  >
                    <Menu className="h-5 w-5" />
                    <span className="ml-2 text-sm">Свернуть</span>
                  </Button>
                )
              )}
            </div>
          </div>
          
          {!isMenuCollapsed && !(location === "/" || location === "") && (
            <div className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href || 
                  (item.href !== "/" && location.startsWith(item.href));
                
                return (
                  <Link key={item.href} href={item.href}>
                    <Button
                      variant="ghost"
                      className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                        isActive 
                          ? 'text-primary bg-blue-50' 
                          : 'text-gray-700 hover:text-primary hover:bg-gray-50'
                      }`}
                    >
                      <Icon className="mr-2 h-4 w-4" />
                      {item.label}
                    </Button>
                  </Link>
                );
              })}
            </div>
          )}

          {/* Mobile menu */}
          <div className="md:hidden flex items-center">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[280px] sm:w-[350px] z-50">
                <div className="flex flex-col h-full">
                  <div className="flex items-center mb-6 pb-4 border-b">
                    <ClipboardList className="h-6 w-6 text-primary mr-3" />
                    <span className="text-lg font-bold text-gray-900">СЭО</span>
                  </div>
                  
                  <div className="flex-1 space-y-2">
                    {navItems.map((item) => {
                      const Icon = item.icon;
                      const isActive = location === item.href || 
                        (item.href !== "/" && location.startsWith(item.href));
                      
                      return (
                        <Link key={item.href} href={item.href}>
                          <Button
                            variant="ghost"
                            className={`w-full justify-start px-3 py-3 text-left ${
                              isActive 
                                ? 'text-primary bg-blue-50' 
                                : 'text-gray-700 hover:text-primary hover:bg-gray-50'
                            }`}
                            onClick={() => setIsOpen(false)}
                          >
                            <Icon className="mr-3 h-5 w-5" />
                            {item.label}
                          </Button>
                        </Link>
                      );
                    })}
                  </div>
                  
                  <div className="border-t pt-4 mt-4">
                    <div className="flex items-center px-3 py-2 text-sm text-gray-600">
                      <UserCircle className="mr-3 h-5 w-5" />
                      <span>Администратор</span>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
