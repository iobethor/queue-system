import { useEffect, useRef, useState } from 'react';
import { useToast } from '@/hooks/use-toast';

interface WebSocketMessage {
  type: string;
  data?: any;
  ticket?: any;
  message?: string;
}

export function useWebSocket(clientType: string, userId?: number, windowNumber?: number) {
  const { toast } = useToast();
  const ws = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  const connect = () => {
    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      ws.current = new WebSocket(wsUrl);

      ws.current.onopen = () => {
        console.log('WebSocket подключен');
        setIsConnected(true);
        reconnectAttempts.current = 0;
        
        // Регистрируем клиента
        ws.current?.send(JSON.stringify({
          type: 'register',
          clientType,
          userId,
          windowNumber,
          id: `${clientType}_${userId || Date.now()}`
        }));
      };

      ws.current.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          setLastMessage(message);
          
          // Обработка различных типов сообщений
          switch (message.type) {
            case 'connected':
            case 'registered':
              console.log('WebSocket:', message.message);
              break;
              
            case 'ticket_created':
              if (clientType === 'display' || clientType === 'operator') {
                toast({
                  title: "Новый талон",
                  description: `Выдан талон ${message.ticket?.ticketNumber}`,
                });
              }
              break;
              
            case 'ticket_called':
              if (clientType === 'display') {
                toast({
                  title: "Вызов клиента",
                  description: `Вызывается талон ${message.ticket?.ticketNumber}`,
                });
              }
              break;
              
            case 'ticket_completed':
              if (clientType === 'display' || clientType === 'operator') {
                toast({
                  title: "Обслуживание завершено",
                  description: `Завершено обслуживание талона ${message.ticket?.ticketNumber}`,
                });
              }
              break;
              
            case 'queue_update':
              // Обновление очереди
              console.log('Обновление очереди:', message.data);
              break;
              
            case 'operator_update':
              if (clientType === 'operator' && message.data?.operatorId === userId) {
                console.log('Обновление для оператора:', message.data);
              }
              break;
              
            case 'error':
              toast({
                title: "Ошибка WebSocket",
                description: message.message,
                variant: "destructive",
              });
              break;
              
            default:
              console.log('Неизвестное сообщение WebSocket:', message);
          }
        } catch (error) {
          console.error('Ошибка обработки WebSocket сообщения:', error);
        }
      };

      ws.current.onclose = (event) => {
        console.log('WebSocket отключен:', event.code, event.reason);
        setIsConnected(false);
        
        // Попытка переподключения
        if (reconnectAttempts.current < maxReconnectAttempts) {
          reconnectAttempts.current++;
          const delay = Math.pow(2, reconnectAttempts.current) * 1000; // Экспоненциальная задержка
          
          console.log(`Попытка переподключения ${reconnectAttempts.current}/${maxReconnectAttempts} через ${delay}ms`);
          
          setTimeout(() => {
            connect();
          }, delay);
        } else {
          toast({
            title: "Соединение потеряно",
            description: "Не удалось восстановить соединение с сервером",
            variant: "destructive",
          });
        }
      };

      ws.current.onerror = (error) => {
        console.error('WebSocket ошибка:', error);
        setIsConnected(false);
      };

    } catch (error) {
      console.error('Ошибка создания WebSocket соединения:', error);
    }
  };

  const disconnect = () => {
    if (ws.current) {
      ws.current.close();
      ws.current = null;
      setIsConnected(false);
    }
  };

  const sendMessage = (message: any) => {
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify(message));
    } else {
      console.warn('WebSocket не подключен');
    }
  };

  // Ping для поддержания соединения
  useEffect(() => {
    if (isConnected) {
      const pingInterval = setInterval(() => {
        sendMessage({ type: 'ping' });
      }, 30000); // Ping каждые 30 секунд

      return () => clearInterval(pingInterval);
    }
  }, [isConnected]);

  useEffect(() => {
    connect();

    return () => {
      disconnect();
    };
  }, [clientType, userId, windowNumber]);

  return {
    isConnected,
    lastMessage,
    sendMessage,
    connect,
    disconnect
  };
}
