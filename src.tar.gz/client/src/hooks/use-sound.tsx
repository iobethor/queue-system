import { useCallback, useRef } from 'react';

interface SoundOptions {
  volume?: number;
  loop?: boolean;
}

export function useSound() {
  const audioContext = useRef<AudioContext | null>(null);
  const audioBuffers = useRef<Map<string, AudioBuffer>>(new Map());

  // Инициализация AudioContext
  const initAudioContext = useCallback(() => {
    if (!audioContext.current) {
      audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return audioContext.current;
  }, []);

  // Генерация синтетических звуков
  const generateTone = useCallback((frequency: number, duration: number, type: OscillatorType = 'sine') => {
    const context = initAudioContext();
    const oscillator = context.createOscillator();
    const gainNode = context.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(context.destination);

    oscillator.frequency.setValueAtTime(frequency, context.currentTime);
    oscillator.type = type;

    // Envelope для плавного звучания
    gainNode.gain.setValueAtTime(0, context.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.3, context.currentTime + 0.01);
    gainNode.gain.exponentialRampToValueAtTime(0.01, context.currentTime + duration);

    oscillator.start(context.currentTime);
    oscillator.stop(context.currentTime + duration);

    return { oscillator, gainNode };
  }, [initAudioContext]);

  // Звук вызова клиента (двойной сигнал)
  const playCallSound = useCallback(() => {
    generateTone(800, 0.3); // Первый тон
    setTimeout(() => {
      generateTone(1000, 0.3); // Второй тон
    }, 400);
  }, [generateTone]);

  // Звук уведомления
  const playNotificationSound = useCallback(() => {
    generateTone(600, 0.2);
  }, [generateTone]);

  // Звук успеха
  const playSuccessSound = useCallback(() => {
    generateTone(523, 0.15); // C5
    setTimeout(() => generateTone(659, 0.15), 150); // E5
    setTimeout(() => generateTone(784, 0.3), 300); // G5
  }, [generateTone]);

  // Звук ошибки
  const playErrorSound = useCallback(() => {
    generateTone(300, 0.1);
    setTimeout(() => generateTone(250, 0.1), 120);
    setTimeout(() => generateTone(200, 0.2), 240);
  }, [generateTone]);

  // Звук объявления (более сложная мелодия)
  const playAnnouncementSound = useCallback(() => {
    // Приятная мелодия для объявлений
    const notes = [
      { freq: 523, duration: 0.2 }, // C5
      { freq: 587, duration: 0.2 }, // D5
      { freq: 659, duration: 0.2 }, // E5
      { freq: 698, duration: 0.4 }, // F5
    ];

    notes.forEach((note, index) => {
      setTimeout(() => {
        generateTone(note.freq, note.duration);
      }, index * 250);
    });
  }, [generateTone]);

  // Универсальная функция воспроизведения
  const playSound = useCallback((soundType: string, options?: SoundOptions) => {
    try {
      switch (soundType) {
        case 'call':
          playCallSound();
          break;
        case 'notification':
          playNotificationSound();
          break;
        case 'success':
          playSuccessSound();
          break;
        case 'error':
          playErrorSound();
          break;
        case 'announcement':
          playAnnouncementSound();
          break;
        default:
          console.warn(`Неизвестный тип звука: ${soundType}`);
      }
    } catch (error) {
      console.error('Ошибка воспроизведения звука:', error);
    }
  }, [playCallSound, playNotificationSound, playSuccessSound, playErrorSound, playAnnouncementSound]);

  // Воспроизведение голосового объявления
  const speakText = useCallback((text: string, lang: string = 'ru-RU') => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 0.9;
      utterance.pitch = 1.0;
      utterance.volume = 0.8;

      // Попытка найти русский голос
      const voices = speechSynthesis.getVoices();
      const russianVoice = voices.find(voice => voice.lang.startsWith('ru'));
      if (russianVoice) {
        utterance.voice = russianVoice;
      }

      speechSynthesis.speak(utterance);
    } else {
      console.warn('Speech Synthesis API не поддерживается');
      // Fallback на звуковой сигнал
      playSound('announcement');
    }
  }, [playSound]);

  // Объявление вызова клиента
  const announceTicket = useCallback((ticketNumber: string, windowNumber: number) => {
    playSound('call');
    
    setTimeout(() => {
      speakText(`Клиент с талоном ${ticketNumber}, пройдите к окну номер ${windowNumber}`);
    }, 1000);
  }, [playSound, speakText]);

  return {
    playSound,
    speakText,
    announceTicket,
    generateTone,
  };
}
