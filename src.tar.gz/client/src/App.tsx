import React from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import Booking from "@/pages/booking";
import Terminal from "@/pages/terminal";
import Operator from "@/pages/operator";
import Display from "@/pages/display";
import Admin from "@/pages/admin";
import AdminSimple from "@/pages/admin-simple";
import AdminMinimal from "@/pages/admin-minimal";
import TestClick from "@/pages/test-click";
import AdminBasic from "@/pages/admin-basic";
import AdminWorking from "@/pages/admin-working";
import HallAdmin from "@/pages/hall-admin";
import Statistics from "@/pages/statistics";
import AdvancedStatistics from "@/pages/advanced-statistics";
import Help from "@/pages/help";
import TerminalSetup from "@/pages/terminal-setup";
import DisplaySetup from "@/pages/display-setup";
import OperatorChat from "@/pages/operator-chat";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/booking" component={Booking} />
      <Route path="/terminal" component={Terminal} />
      <Route path="/operator" component={Operator} />
      <Route path="/display" component={Display} />
      <Route path="/admin" component={Admin} />
      <Route path="/hall-admin" component={HallAdmin} />
      <Route path="/statistics" component={Statistics} />
      <Route path="/advanced-statistics" component={AdvancedStatistics} />
      <Route path="/help" component={Help} />
      <Route path="/terminal-setup" component={TerminalSetup} />
      <Route path="/display-setup" component={DisplaySetup} />
      <Route path="/operator-chat" component={OperatorChat} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Очищаем старые проблемные ID при запуске приложения
  React.useEffect(() => {
    const cleanupOldIds = () => {
      const terminalId = localStorage.getItem('terminal_id');
      const displayId = localStorage.getItem('display_id');
      
      if (terminalId && (terminalId.includes('(') || terminalId.includes(')') || terminalId.includes('/'))) {
        console.log('Очищаем старый terminal_id:', terminalId);
        localStorage.removeItem('terminal_id');
      }
      
      if (displayId && (displayId.includes('(') || displayId.includes(')') || displayId.includes('/'))) {
        console.log('Очищаем старый display_id:', displayId);
        localStorage.removeItem('display_id');
      }
    };
    
    cleanupOldIds();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-gray-50">
          <Router />
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
