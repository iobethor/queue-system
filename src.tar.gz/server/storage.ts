import { 
  departments, services, operators, appointments, tickets, callHistory, 
  serviceRatings, systemSettings, aiChatLogs, users, terminalSettings, displaySettings,
  aiSettings, operatorServices, emailSettings, importExportLogs, statisticsCache, aiChatSessions, voiceSettings,
  displayBoardSettings, displayBoards, ticketSettings, operatorChatMessages, operatorStatus,
  databaseBackups, importRecords, securitySettings,
  type Department, type Service, type Operator, type Appointment, type Ticket,
  type CallHistory, type ServiceRating, type SystemSetting, type AiChatLog, type User,
  type TerminalSettings, type InsertTerminalSettings,
  type DisplaySettings, type InsertDisplaySettings,
  type AiSettings, type InsertAiSettings,
  type OperatorServices, type InsertOperatorServices,
  type EmailSettings, type InsertEmailSettings,
  type ImportExportLog, type InsertImportExportLog,
  type StatisticsCache, type InsertStatisticsCache,
  type AiChatSession, type InsertAiChatSession,
  type VoiceSettings, type InsertVoiceSettings,
  type DisplayBoardSettings, type InsertDisplayBoardSettings,
  type DisplayBoard, type InsertDisplayBoard,
  type TicketSettings, type InsertTicketSettings,
  type OperatorChatMessage, type InsertOperatorChatMessage,
  type OperatorStatus, type InsertOperatorStatus,
  type DatabaseBackup, type InsertDatabaseBackup,
  type ImportRecord, type InsertImportRecord,
  type SecuritySettings, type InsertSecuritySettings,
  type InsertDepartment, type InsertService, type InsertOperator, type InsertAppointment,
  type InsertTicket, type InsertCallHistory, type InsertServiceRating, 
  type InsertSystemSetting, type InsertAiChatLog, type InsertUser,
  type OperatorMessage, type InsertOperatorMessage
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql, gte, lte, isNull, isNotNull } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  // Legacy user methods for compatibility
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Department methods
  getDepartments(): Promise<Department[]>;
  getDepartment(id: number): Promise<Department | undefined>;
  createDepartment(department: InsertDepartment): Promise<Department>;
  updateDepartment(id: number, department: Partial<InsertDepartment>): Promise<Department>;
  deleteDepartment(id: number): Promise<boolean>;

  // Service methods
  getServices(): Promise<Service[]>;
  getServicesByDepartment(departmentId: number): Promise<Service[]>;
  getService(id: number): Promise<Service | undefined>;
  getServiceById(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, service: Partial<InsertService>): Promise<Service>;
  deleteService(id: number): Promise<boolean>;

  // Operator methods
  getOperators(): Promise<Operator[]>;
  getOperatorsByDepartment(departmentId: number): Promise<Operator[]>;
  getOperator(id: number): Promise<Operator | undefined>;
  getOperatorByEmail(email: string): Promise<Operator | undefined>;
  getOperatorByUsername(username: string): Promise<Operator | undefined>;
  createOperator(operator: InsertOperator): Promise<Operator>;
  updateOperator(id: number, operator: Partial<InsertOperator>): Promise<Operator>;
  deleteOperator(id: number): Promise<boolean>;

  // Appointment methods
  getAppointments(): Promise<Appointment[]>;
  getAppointmentsByDate(date: string): Promise<Appointment[]>;
  getAppointmentByPin(pinCode: string): Promise<Appointment | undefined>;
  getAppointmentById(id: number): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment>;

  // Ticket methods
  getTickets(): Promise<Ticket[]>;
  getActiveTickets(): Promise<Ticket[]>;
  getTicketsByStatus(status: string): Promise<Ticket[]>;
  getTicket(id: number): Promise<Ticket | undefined>;
  getTicketsByDate(date: string): Promise<Ticket[]>;
  createTicket(ticket: InsertTicket, ticketNumber?: string): Promise<Ticket>;
  updateTicket(id: number, ticket: Partial<InsertTicket>): Promise<Ticket>;

  // Call History methods
  createCallHistory(callHistory: InsertCallHistory): Promise<CallHistory>;
  getCallHistoryByTicket(ticketId: number): Promise<CallHistory[]>;

  // Service Rating methods
  createServiceRating(rating: InsertServiceRating): Promise<ServiceRating>;
  getServiceRatingsByOperator(operatorId: number): Promise<ServiceRating[]>;

  // System Settings methods
  getSystemSettings(): Promise<SystemSetting[]>;
  getSystemSetting(key: string): Promise<SystemSetting | undefined>;
  setSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting>;

  // AI Chat methods
  createAiChatLog(log: InsertAiChatLog): Promise<AiChatLog>;

  // AI Settings methods
  getAiSettings(): Promise<AiSettings[]>;
  getAiSetting(id: number): Promise<AiSettings | undefined>;
  createAiSetting(setting: InsertAiSettings): Promise<AiSettings>;
  updateAiSetting(id: number, setting: Partial<InsertAiSettings>): Promise<AiSettings>;
  deleteAiSetting(id: number): Promise<boolean>;

  // Operator Services methods
  getOperatorServices(operatorId: number): Promise<number[]>; // return service IDs
  setOperatorServices(operatorId: number, serviceIds: number[]): Promise<void>;
  getOperatorsByService(serviceId: number): Promise<Operator[]>;
  getAiChatHistory(userId: number, limit?: number): Promise<AiChatLog[]>;

  // Terminal Settings methods
  getTerminalSettings(): Promise<TerminalSettings | undefined>;
  updateTerminalSettings(settings: Partial<InsertTerminalSettings>): Promise<TerminalSettings>;

  // Email Settings methods
  getEmailSettings(): Promise<EmailSettings | undefined>;
  updateEmailSettings(settings: Partial<InsertEmailSettings>): Promise<EmailSettings>;

  // Import/Export methods
  createImportExportLog(log: InsertImportExportLog): Promise<ImportExportLog>;
  getImportExportLogs(limit?: number): Promise<ImportExportLog[]>;
  exportAppointments(startDate: string, endDate: string): Promise<Appointment[]>;
  importAppointments(appointments: InsertAppointment[]): Promise<Appointment[]>;
  exportTickets(startDate: string, endDate: string): Promise<any[]>;
  exportStatistics(startDate: string, endDate: string): Promise<any>;

  // Statistics Cache methods
  getStatisticsCache(dateKey: string, departmentId?: number): Promise<StatisticsCache | undefined>;
  updateStatisticsCache(cache: InsertStatisticsCache): Promise<StatisticsCache>;
  generateDailyStatistics(date: string): Promise<any>;

  // AI Chat Sessions methods
  createAiChatSession(session: InsertAiChatSession): Promise<AiChatSession>;
  getActiveAiChatSession(userId: number, module: string): Promise<AiChatSession | undefined>;
  endAiChatSession(sessionId: string): Promise<boolean>;

  // Voice settings methods
  getVoiceSettings(): Promise<VoiceSettings | undefined>;
  updateVoiceSettings(settings: InsertVoiceSettings): Promise<VoiceSettings>;

  // Display board settings methods
  getDisplayBoardSettings(): Promise<DisplayBoardSettings | undefined>;
  updateDisplayBoardSettings(settings: InsertDisplayBoardSettings): Promise<DisplayBoardSettings>;
  
  // Ticket settings methods
  getTicketSettings(): Promise<TicketSettings>;
  updateTicketSettings(settings: Partial<InsertTicketSettings>): Promise<TicketSettings>;
  
  // Display boards methods
  getDisplayBoards(): Promise<DisplayBoard[]>;
  getDisplayBoard(id: number): Promise<DisplayBoard | undefined>;
  getDisplayBoardByOperator(operatorId: number): Promise<DisplayBoard | undefined>;
  createDisplayBoard(board: InsertDisplayBoard): Promise<DisplayBoard>;
  updateDisplayBoard(id: number, board: Partial<InsertDisplayBoard>): Promise<DisplayBoard>;
  deleteDisplayBoard(id: number): Promise<boolean>;
  updateDisplayBoardTicket(operatorId: number, ticketNumber: string | null): Promise<boolean>;

  // Operator Chat methods
  getOperatorChatMessages(operatorId?: number, receiverId?: number): Promise<OperatorChatMessage[]>;
  createOperatorChatMessage(message: InsertOperatorChatMessage): Promise<OperatorChatMessage>;
  markMessageAsRead(messageId: number): Promise<void>;
  
  // Operator Status methods
  getAllOperatorStatuses(): Promise<OperatorStatus[]>;
  getOperatorStatus(operatorId: number): Promise<OperatorStatus | undefined>;
  updateOperatorStatus(operatorId: number, status: Partial<InsertOperatorStatus>): Promise<OperatorStatus>;
  setOperatorBreak(operatorId: number, reason?: string): Promise<OperatorStatus>;
  endOperatorBreak(operatorId: number): Promise<OperatorStatus>;

  // Utility methods
  generatePinCode(): Promise<string>;
  generateTicketNumber(serviceCode: string): Promise<string>;
  getQueueStatistics(): Promise<any>;
  
  // Statistics methods
  getActiveTicketCount(): Promise<number>;
  getCompletedTicketsToday(): Promise<number>;
  getAppointmentsTodayCount(): Promise<number>;
  getAverageWaitTime(): Promise<number>;

  // Terminal settings methods
  getTerminalSettingsByTerminalId(terminalId: string): Promise<TerminalSettings | undefined>;
  createOrUpdateTerminalSettings(settings: any): Promise<TerminalSettings>;

  // Display settings methods
  getDisplaySettingsByDisplayId(displayId: string): Promise<DisplaySettings | undefined>;
  createOrUpdateDisplaySettings(settings: any): Promise<DisplaySettings>;

  // Database backup methods
  createDatabaseBackup(backup: InsertDatabaseBackup): Promise<DatabaseBackup>;
  getDatabaseBackups(): Promise<DatabaseBackup[]>;
  deleteDatabaseBackup(id: number): Promise<boolean>;
  
  // Import record methods (для предотвращения дублирования)
  createImportRecord(record: InsertImportRecord): Promise<ImportRecord>;
  checkImportRecord(tableType: string, importHash: string): Promise<ImportRecord | undefined>;
  
  // Database operations
  createFullDatabaseBackup(): Promise<{ filePath: string; fileSize: number; recordsCount: number }>;
  clearDatabaseWithProtection(pin: string): Promise<{ cleared: boolean; tablesCleared: string[] }>;

  // Security Settings methods
  getSecuritySettings(): Promise<SecuritySettings | undefined>;
  updateSecuritySettings(settings: InsertSecuritySettings): Promise<SecuritySettings>;

  // Schedule Management methods
  updateDepartmentSchedule(departmentId: number, scheduleData: { workSchedule?: any; holidays?: string[] }): Promise<Department>;
  getDepartmentSchedule(departmentId: number): Promise<{ workSchedule?: any; holidays?: string[] } | undefined>;
  checkBookingAvailability(departmentId: number, date: string, time: string): Promise<boolean>;

}

export class DatabaseStorage implements IStorage {
  // Legacy user methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    const [createdUser] = await db.insert(users).values(user).returning();
    return createdUser;
  }

  // Department methods
  async getDepartments(): Promise<Department[]> {
    return await db.select().from(departments).where(eq(departments.isActive, true));
  }

  async getDepartment(id: number): Promise<Department | undefined> {
    const [department] = await db.select().from(departments).where(eq(departments.id, id));
    return department || undefined;
  }

  async createDepartment(department: InsertDepartment): Promise<Department> {
    const [created] = await db.insert(departments).values(department).returning();
    return created;
  }

  async updateDepartment(id: number, department: Partial<InsertDepartment>): Promise<Department> {
    const [updated] = await db.update(departments)
      .set({ ...department, updatedAt: sql`CURRENT_TIMESTAMP` })
      .where(eq(departments.id, id))
      .returning();
    return updated;
  }

  async deleteDepartment(id: number): Promise<boolean> {
    const result = await db.delete(departments).where(eq(departments.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Service methods
  async getServices(): Promise<Service[]> {
    return await db.select().from(services).where(eq(services.isActive, true));
  }

  async getServicesByDepartment(departmentId: number): Promise<Service[]> {
    return await db.select().from(services)
      .where(and(eq(services.departmentId, departmentId), eq(services.isActive, true)));
  }

  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service || undefined;
  }

  async getServiceById(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service || undefined;
  }

  async createService(service: InsertService): Promise<Service> {
    const [created] = await db.insert(services).values(service).returning();
    return created;
  }

  async updateService(id: number, service: Partial<InsertService>): Promise<Service> {
    const [updated] = await db.update(services)
      .set({ ...service, updatedAt: sql`CURRENT_TIMESTAMP` })
      .where(eq(services.id, id))
      .returning();
    return updated;
  }

  async deleteService(id: number): Promise<boolean> {
    const result = await db.delete(services).where(eq(services.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Operator methods
  async getOperators(): Promise<Operator[]> {
    return await db.select().from(operators).where(eq(operators.isActive, true));
  }

  async getOperatorsByDepartment(departmentId: number): Promise<Operator[]> {
    return await db.select().from(operators)
      .where(and(eq(operators.departmentId, departmentId), eq(operators.isActive, true)));
  }

  async getOperator(id: number): Promise<Operator | undefined> {
    const [operator] = await db.select().from(operators).where(eq(operators.id, id));
    return operator || undefined;
  }

  async getOperatorByEmail(email: string): Promise<Operator | undefined> {
    const [operator] = await db.select().from(operators).where(eq(operators.email, email));
    return operator || undefined;
  }

  async getOperatorByUsername(username: string): Promise<Operator | undefined> {
    const [operator] = await db.select().from(operators).where(eq(operators.username, username));
    return operator || undefined;
  }

  async createOperator(operator: InsertOperator): Promise<Operator> {
    const [created] = await db.insert(operators).values(operator).returning();
    return created;
  }

  async updateOperator(id: number, operator: Partial<InsertOperator>): Promise<Operator> {
    const [updated] = await db.update(operators)
      .set({ ...operator, updatedAt: sql`CURRENT_TIMESTAMP` })
      .where(eq(operators.id, id))
      .returning();
    return updated;
  }

  async deleteOperator(id: number): Promise<boolean> {
    const result = await db.delete(operators).where(eq(operators.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Appointment methods
  async getAppointments(): Promise<Appointment[]> {
    return await db.select().from(appointments).orderBy(desc(appointments.createdAt));
  }

  async getAppointmentsByDate(date: string): Promise<Appointment[]> {
    return await db.select().from(appointments)
      .where(eq(appointments.appointmentDate, date))
      .orderBy(appointments.appointmentTime);
  }

  async getAppointmentByPin(pinCode: string): Promise<Appointment | undefined> {
    const [appointment] = await db.select().from(appointments)
      .where(eq(appointments.pinCode, pinCode));
    return appointment || undefined;
  }

  async createAppointment(appointment: InsertAppointment & { pinCode: string }): Promise<Appointment> {
    const [created] = await db.insert(appointments).values(appointment).returning();
    return created;
  }

  async updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment> {
    const [updated] = await db.update(appointments)
      .set({ ...appointment, updatedAt: sql`CURRENT_TIMESTAMP` })
      .where(eq(appointments.id, id))
      .returning();
    return updated;
  }

  async getAppointmentById(id: number): Promise<Appointment | undefined> {
    const [appointment] = await db.select().from(appointments).where(eq(appointments.id, id));
    return appointment || undefined;
  }

  // Ticket methods
  async getTickets(): Promise<Ticket[]> {
    return await db.select().from(tickets).orderBy(desc(tickets.issuedAt));
  }

  async getActiveTickets(): Promise<any[]> {
    return await db.select({
      id: tickets.id,
      ticketNumber: tickets.ticketNumber,
      serviceId: tickets.serviceId,
      serviceName: services.name,
      serviceCode: services.serviceCode,
      departmentId: tickets.departmentId,
      status: tickets.status,
      priority: tickets.priority,
      issuedAt: tickets.issuedAt,
      calledAt: tickets.calledAt,
      servedAt: tickets.servedAt,
      completedAt: tickets.completedAt,
      operatorId: tickets.operatorId,
      estimatedWaitTime: tickets.estimatedWaitTime,
      actualWaitTime: tickets.actualWaitTime
    }).from(tickets)
      .leftJoin(services, eq(tickets.serviceId, services.id))
      .where(sql`${tickets.status} IN ('waiting', 'in_progress', 'serving')`)
      .orderBy(tickets.priority, tickets.issuedAt);
  }

  async getTicketsByStatus(status: string): Promise<Ticket[]> {
    return await db.select().from(tickets)
      .where(eq(tickets.status, status))
      .orderBy(tickets.issuedAt);
  }

  async getTicket(id: number): Promise<Ticket | undefined> {
    const [ticket] = await db.select().from(tickets).where(eq(tickets.id, id));
    return ticket || undefined;
  }

  async getTicketsByDate(date: string): Promise<Ticket[]> {
    return await db.select().from(tickets)
      .where(sql`DATE(${tickets.issuedAt}) = ${date}`)
      .orderBy(tickets.issuedAt);
  }

  async createTicket(ticket: InsertTicket, ticketNumber?: string): Promise<Ticket> {
    const ticketData = ticketNumber ? { ...ticket, ticketNumber } : ticket;
    const [created] = await db.insert(tickets).values(ticketData).returning();
    return created;
  }

  async updateTicket(id: number, ticket: Partial<InsertTicket>): Promise<Ticket> {
    const [updated] = await db.update(tickets)
      .set(ticket)
      .where(eq(tickets.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Талон с ID ${id} не найден`);
    }
    
    return updated;
  }

  // Call History methods
  async createCallHistory(callHistoryData: InsertCallHistory): Promise<CallHistory> {
    const [created] = await db.insert(callHistory).values(callHistoryData).returning();
    return created;
  }

  async getCallHistoryByTicket(ticketId: number): Promise<CallHistory[]> {
    return await db.select().from(callHistory)
      .where(eq(callHistory.ticketId, ticketId))
      .orderBy(desc(callHistory.calledAt));
  }

  // Service Rating methods
  async createServiceRating(rating: InsertServiceRating): Promise<ServiceRating> {
    const [created] = await db.insert(serviceRatings).values(rating).returning();
    return created;
  }

  async getServiceRatingsByOperator(operatorId: number): Promise<ServiceRating[]> {
    return await db.select().from(serviceRatings)
      .where(eq(serviceRatings.operatorId, operatorId))
      .orderBy(desc(serviceRatings.createdAt));
  }

  // System Settings methods
  async getSystemSettings(): Promise<SystemSetting[]> {
    return await db.select().from(systemSettings);
  }

  async getSystemSetting(key: string): Promise<SystemSetting | undefined> {
    const [setting] = await db.select().from(systemSettings)
      .where(eq(systemSettings.key, key));
    return setting || undefined;
  }

  // Call History and Rating methods
  async getCallHistory(): Promise<CallHistory[]> {
    return await db.select().from(callHistory).orderBy(desc(callHistory.calledAt));
  }

  async getRatings(): Promise<ServiceRating[]> {
    return await db.select().from(serviceRatings).orderBy(desc(serviceRatings.createdAt));
  }

  // Department working hours check
  async isDepartmentCurrentlyWorking(departmentId: number): Promise<{ isWorking: boolean; reason?: string }> {
    try {
      const now = new Date();
      const currentDay = now.getDay(); // 0 = воскресенье, 1 = понедельник, etc.
      const currentTime = now.getHours() * 100 + now.getMinutes(); // HHMM format
      
      // Проверяем рабочие часы отделения
      // Для упрощения считаем, что все отделения работают пн-пт 9:00-18:00
      if (currentDay === 0 || currentDay === 6) {
        return { isWorking: false, reason: 'Выходной день' };
      }
      
      if (currentTime < 900 || currentTime >= 1800) {
        return { isWorking: false, reason: 'Не рабочее время' };
      }
      
      return { isWorking: true };
    } catch (error) {
      console.error('Error checking working hours:', error);
      return { isWorking: false, reason: 'Ошибка проверки времени' };
    }
  }

  async setSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting> {
    const [updated] = await db.insert(systemSettings)
      .values(setting)
      .onConflictDoUpdate({
        target: systemSettings.key,
        set: { value: setting.value, updatedAt: sql`CURRENT_TIMESTAMP` }
      })
      .returning();
    return updated;
  }

  // AI Chat methods
  async createAiChatLog(log: InsertAiChatLog): Promise<AiChatLog> {
    const [created] = await db.insert(aiChatLogs).values(log).returning();
    return created;
  }

  async getAiChatHistory(userId: number, limit = 50): Promise<AiChatLog[]> {
    return await db.select().from(aiChatLogs)
      .where(eq(aiChatLogs.userId, userId))
      .orderBy(desc(aiChatLogs.createdAt))
      .limit(limit);
  }

  // Utility methods
  async generatePinCode(): Promise<string> {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    
    // Генерируем формат AB-1234
    result += chars.charAt(Math.floor(Math.random() * 26)); // A-Z
    result += chars.charAt(Math.floor(Math.random() * 26)); // A-Z
    result += '-';
    
    for (let i = 0; i < 4; i++) {
      result += '0123456789'.charAt(Math.floor(Math.random() * 10));
    }
    
    // Проверяем уникальность
    const existing = await this.getAppointmentByPin(result);
    if (existing) {
      return this.generatePinCode(); // Рекурсивно генерируем новый
    }
    
    return result;
  }

  async generateTicketNumber(serviceCode: string): Promise<string> {
    // Получаем настройки длины номера талона (количество цифр, по умолчанию 4)
    const ticketSettings = await this.getTicketSettings();
    const digitLength = ticketSettings.ticketNumberLength || 4;
    
    // Используем транзакцию для получения следующего номера
    const result = await db.transaction(async (tx) => {
      // Получаем все талоны для данной услуги сегодня, учитывая как новый формат (CODE0001), так и старый (CODE-001)
      const existingTickets = await tx.select({
        ticketNumber: tickets.ticketNumber
      })
        .from(tickets)
        .where(and(
          sql`${tickets.ticketNumber} LIKE ${serviceCode + '%'}`,
          gte(tickets.issuedAt, sql`CURRENT_DATE`)
        ));

      let maxNumber = 0;
      
      // Извлекаем максимальный номер из существующих талонов
      for (const ticket of existingTickets) {
        const ticketNum = ticket.ticketNumber;
        if (!ticketNum) continue;
        
        let numberPart = '';
        
        if (ticketNum.includes('-')) {
          // Старый формат: CODE-001
          const parts = ticketNum.split('-');
          numberPart = parts[1] || '';
        } else {
          // Новый формат: CODE0001
          numberPart = ticketNum.substring(serviceCode.length);
        }
        
        const num = parseInt(numberPart, 10);
        if (!isNaN(num) && num > maxNumber) {
          maxNumber = num;
        }
      }

      const nextNumber = maxNumber + 1;

      // Формат: код услуги + цифры (например: A0001, B0002, CERT010001)
      return `${serviceCode}${nextNumber.toString().padStart(digitLength, '0')}`;
    });

    return result;
  }

  async getQueueStatistics(): Promise<any> {
    const today = new Date().toISOString().split('T')[0];
    
    const [activeCount] = await db.select({ count: sql<number>`count(*)` })
      .from(tickets)
      .where(sql`${tickets.status} IN ('waiting', 'in_progress', 'serving')`);
    
    const [completedToday] = await db.select({ count: sql<number>`count(*)` })
      .from(tickets)
      .where(and(
        eq(tickets.status, 'completed'),
        gte(tickets.issuedAt, sql`CURRENT_DATE`)
      ));
    
    // Вычисляем среднее время ожидания на основе реальных временных меток
    const [avgWaitTime] = await db.select({ 
      avg: sql<number>`avg(EXTRACT(EPOCH FROM (${tickets.calledAt} - ${tickets.issuedAt}))/60)` 
    })
      .from(tickets)
      .where(and(
        sql`${tickets.calledAt} IS NOT NULL`,
        sql`${tickets.issuedAt} IS NOT NULL`,
        gte(tickets.issuedAt, sql`CURRENT_DATE`)
      ));
    
    return {
      activeQueue: activeCount.count || 0,
      completedToday: completedToday.count || 0,
      averageWaitTime: Math.round(avgWaitTime.avg || 0)
    };
  }

  // Terminal Settings methods
  async getTerminalSettings(): Promise<TerminalSettings | undefined> {
    const [settings] = await db.select().from(terminalSettings).limit(1);
    
    // Если настройки не существуют, создаем с настройками по умолчанию
    if (!settings) {
      const defaultSettings = {
        theme: 'classic',
        displayTimeSeconds: 5,
        organizationName: 'ЭЛЕКТРОННАЯ ОЧЕРЕДЬ',
        backgroundColor: '#ffffff',
        textColor: '#000000',
        accentColor: '#0079F2',
        showWaitingTime: true,
        showQueuePosition: true,
        enableSound: true,
        ticketTemplate: JSON.stringify({
          header: '================================',
          title: '{{organizationName}}',
          divider: '================================',
          ticketNumber: 'ТАЛОН № {{ticketNumber}}',
          service: 'Услуга: {{serviceName}}',
          date: 'Дата: {{date}}',
          time: 'Время: {{time}}',
          queueInfo: 'В очереди: {{queueCount}} человек',
          waitTime: 'Приблизительное время ожидания:\n{{waitTime}} минут',
          footer: '================================\nСохраните этот талон до вызова\n================================'
        })
      };
      
      return await this.updateTerminalSettings(defaultSettings);
    }
    
    return settings;
  }

  async updateTerminalSettings(settings: Partial<InsertTerminalSettings>): Promise<TerminalSettings> {
    const [existing] = await db.select().from(terminalSettings).limit(1);
    
    if (existing) {
      const [updated] = await db.update(terminalSettings)
        .set({ ...settings, updatedAt: new Date() })
        .where(eq(terminalSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(terminalSettings)
        .values(settings as InsertTerminalSettings)
        .returning();
      return created;
    }
  }

  // Display Settings methods
  async getDisplaySettings(): Promise<DisplaySettings> {
    const [settings] = await db.select().from(displaySettings).limit(1);
    
    // Если настройки не существуют, создаем с настройками по умолчанию
    if (!settings) {
      const defaultSettings = {
        organizationName: 'ЭЛЕКТРОННАЯ ОЧЕРЕДЬ',
        backgroundColor: '#ffffff',
        textColor: '#000000',
        accentColor: '#2563eb',
        headerColor: '#1e40af',
        showTime: true,
        showCompletedCount: true,
        fontSize: 16,
        refreshInterval: 3
      };
      
      return await this.updateDisplaySettings(defaultSettings);
    }
    
    return settings;
  }

  async updateDisplaySettings(settings: Partial<InsertDisplaySettings>): Promise<DisplaySettings> {
    const [existing] = await db.select().from(displaySettings).limit(1);
    
    if (existing) {
      const [updated] = await db.update(displaySettings)
        .set({ ...settings, updatedAt: new Date() })
        .where(eq(displaySettings.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(displaySettings)
        .values(settings as InsertDisplaySettings)
        .returning();
      return created;
    }
  }

  // Ticket Settings methods
  async getTicketSettings(): Promise<TicketSettings> {
    const [settings] = await db.select().from(ticketSettings).limit(1);
    
    // Если настройки не существуют, создаем с настройками по умолчанию
    if (!settings) {
      const defaultSettings = {
        ticketNumberLength: 3
      };
      
      const [created] = await db.insert(ticketSettings)
        .values(defaultSettings as InsertTicketSettings)
        .returning();
      return created;
    }
    
    return settings;
  }

  async updateTicketSettings(settings: Partial<InsertTicketSettings>): Promise<TicketSettings> {
    const [existing] = await db.select().from(ticketSettings).limit(1);
    
    if (existing) {
      const [updated] = await db.update(ticketSettings)
        .set({ ...settings, updatedAt: new Date() })
        .where(eq(ticketSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(ticketSettings)
        .values(settings as InsertTicketSettings)
        .returning();
      return created;
    }
  }

  // AI Settings methods
  async getAiSettings(): Promise<AiSettings[]> {
    return await db.select().from(aiSettings).orderBy(aiSettings.id);
  }

  async getAiSetting(id: number): Promise<AiSettings | undefined> {
    const [setting] = await db.select().from(aiSettings).where(eq(aiSettings.id, id));
    return setting || undefined;
  }

  async createAiSetting(setting: InsertAiSettings): Promise<AiSettings> {
    const [created] = await db.insert(aiSettings).values(setting).returning();
    return created;
  }

  async updateAiSetting(id: number, setting: Partial<InsertAiSettings>): Promise<AiSettings> {
    const [updated] = await db.update(aiSettings)
      .set({...setting, updatedAt: sql`CURRENT_TIMESTAMP`})
      .where(eq(aiSettings.id, id))
      .returning();
    return updated;
  }

  async deleteAiSetting(id: number): Promise<boolean> {
    const result = await db.delete(aiSettings).where(eq(aiSettings.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Operator Services methods
  async getOperatorServices(operatorId: number): Promise<number[]> {
    const results = await db.select({ serviceId: operatorServices.serviceId })
      .from(operatorServices)
      .where(eq(operatorServices.operatorId, operatorId));
    return results.map(r => r.serviceId);
  }

  async setOperatorServices(operatorId: number, serviceIds: number[]): Promise<void> {
    // Удаляем существующие связи
    await db.delete(operatorServices).where(eq(operatorServices.operatorId, operatorId));
    
    // Добавляем новые связи
    if (serviceIds.length > 0) {
      const values = serviceIds.map(serviceId => ({ operatorId, serviceId }));
      await db.insert(operatorServices).values(values);
    }
  }

  async getOperatorsByService(serviceId: number): Promise<Operator[]> {
    const results = await db.select()
      .from(operators)
      .innerJoin(operatorServices, eq(operators.id, operatorServices.operatorId))
      .where(eq(operatorServices.serviceId, serviceId));
    return results.map(r => r.operators);
  }

  // Email Settings methods
  async getEmailSettings(): Promise<EmailSettings | undefined> {
    const [settings] = await db.select().from(emailSettings).limit(1);
    return settings || undefined;
  }

  async updateEmailSettings(settings: Partial<InsertEmailSettings>): Promise<EmailSettings> {
    const [existing] = await db.select().from(emailSettings).limit(1);
    
    if (existing) {
      const [updated] = await db.update(emailSettings)
        .set({ ...settings, updatedAt: sql`CURRENT_TIMESTAMP` })
        .where(eq(emailSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(emailSettings)
        .values(settings as InsertEmailSettings)
        .returning();
      return created;
    }
  }

  // Import/Export methods
  async createImportExportLog(log: InsertImportExportLog): Promise<ImportExportLog> {
    const [created] = await db.insert(importExportLogs).values(log).returning();
    return created;
  }

  async getImportExportLogs(limit = 50): Promise<ImportExportLog[]> {
    return await db.select().from(importExportLogs)
      .orderBy(desc(importExportLogs.createdAt))
      .limit(limit);
  }

  async exportAppointments(startDate: string, endDate: string): Promise<Appointment[]> {
    return await db.select().from(appointments)
      .where(and(
        gte(appointments.appointmentDate, startDate),
        lte(appointments.appointmentDate, endDate)
      ))
      .orderBy(appointments.appointmentDate, appointments.appointmentTime);
  }

  async importAppointments(appointmentsData: (InsertAppointment & { pinCode: string })[]): Promise<Appointment[]> {
    const results: Appointment[] = [];
    
    for (const appointment of appointmentsData) {
      try {
        // Проверяем уникальность PIN-кода
        const existingPin = await this.getAppointmentByPin(appointment.pinCode);
        if (existingPin) {
          // Генерируем новый PIN-код если существует
          appointment.pinCode = await this.generatePinCode();
        }
        
        const [created] = await db.insert(appointments).values(appointment).returning();
        results.push(created);
      } catch (error) {
        console.error('Error importing appointment:', error);
        // Логируем ошибку но продолжаем импорт
      }
    }
    
    return results;
  }

  async exportTickets(startDate: string, endDate: string): Promise<any[]> {
    return await db.select({
      id: tickets.id,
      ticketNumber: tickets.ticketNumber,
      serviceId: tickets.serviceId,
      serviceName: services.name,
      departmentId: tickets.departmentId,
      departmentName: departments.name,
      status: tickets.status,
      priority: tickets.priority,
      issuedAt: tickets.issuedAt,
      calledAt: tickets.calledAt,
      servedAt: tickets.servedAt,
      completedAt: tickets.completedAt,
      operatorId: tickets.operatorId,
      operatorName: sql`CONCAT(${operators.firstName}, ' ', ${operators.lastName})`,
      estimatedWaitTime: tickets.estimatedWaitTime,
      actualWaitTime: tickets.actualWaitTime
    }).from(tickets)
      .leftJoin(services, eq(tickets.serviceId, services.id))
      .leftJoin(departments, eq(tickets.departmentId, departments.id))
      .leftJoin(operators, eq(tickets.operatorId, operators.id))
      .where(and(
        sql`${tickets.issuedAt} >= ${startDate}`,
        sql`${tickets.issuedAt} <= ${endDate + ' 23:59:59'}`
      ))
      .orderBy(tickets.issuedAt);
  }

  async exportStatistics(startDate: string, endDate: string): Promise<any> {
    const [ticketStats] = await db.select({
      totalTickets: sql<number>`count(*)`,
      completedTickets: sql<number>`count(case when status = 'completed' then 1 end)`,
      missedTickets: sql<number>`count(case when status = 'missed' then 1 end)`,
      averageWaitTime: sql<number>`avg(actual_wait_time)`,
      maxWaitTime: sql<number>`max(actual_wait_time)`,
      minWaitTime: sql<number>`min(actual_wait_time)`
    }).from(tickets)
      .where(and(
        sql`${tickets.issuedAt} >= ${startDate}`,
        sql`${tickets.issuedAt} <= ${endDate + ' 23:59:59'}`
      ));

    const serviceStats = await db.select({
      serviceId: services.id,
      serviceName: services.name,
      serviceCode: services.serviceCode,
      totalTickets: sql<number>`count(${tickets.id})`,
      completedTickets: sql<number>`count(case when ${tickets.status} = 'completed' then 1 end)`,
      averageWaitTime: sql<number>`avg(${tickets.actualWaitTime})`
    }).from(services)
      .leftJoin(tickets, and(
        eq(tickets.serviceId, services.id),
        sql`${tickets.issuedAt} >= ${startDate}`,
        sql`${tickets.issuedAt} <= ${endDate + ' 23:59:59'}`
      ))
      .groupBy(services.id, services.name, services.serviceCode)
      .orderBy(services.name);

    return {
      period: { startDate, endDate },
      summary: ticketStats,
      byService: serviceStats,
      generatedAt: new Date().toISOString()
    };
  }

  // Statistics Cache methods
  async getStatisticsCache(dateKey: string, departmentId?: number): Promise<StatisticsCache | undefined> {
    const whereConditions = departmentId
      ? and(eq(statisticsCache.dateKey, dateKey), eq(statisticsCache.departmentId, departmentId))
      : eq(statisticsCache.dateKey, dateKey);
      
    const [cache] = await db.select().from(statisticsCache)
      .where(whereConditions)
      .limit(1);
    return cache || undefined;
  }

  async updateStatisticsCache(cache: InsertStatisticsCache): Promise<StatisticsCache> {
    const existing = await this.getStatisticsCache(cache.dateKey, cache.departmentId || undefined);
    
    if (existing) {
      const [updated] = await db.update(statisticsCache)
        .set({ ...cache, updatedAt: sql`CURRENT_TIMESTAMP` })
        .where(eq(statisticsCache.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(statisticsCache).values(cache).returning();
      return created;
    }
  }

  async generateDailyStatistics(date: string): Promise<any> {
    const stats = await this.exportStatistics(date, date);
    
    // Кэшируем результат
    await this.updateStatisticsCache({
      dateKey: date,
      totalTickets: stats.summary.totalTickets,
      completedTickets: stats.summary.completedTickets,
      averageWaitTime: Math.round(stats.summary.averageWaitTime || 0),
      averageServiceTime: 0, // TODO: добавить расчет времени обслуживания
      dataJson: stats
    });
    
    return stats;
  }

  // AI Chat Sessions methods
  async createAiChatSession(session: InsertAiChatSession): Promise<AiChatSession> {
    const [created] = await db.insert(aiChatSessions).values(session).returning();
    return created;
  }

  async getActiveAiChatSession(userId: number, module: string): Promise<AiChatSession | undefined> {
    const [session] = await db.select().from(aiChatSessions)
      .where(and(
        eq(aiChatSessions.userId, userId),
        eq(aiChatSessions.module, module),
        eq(aiChatSessions.isActive, true)
      ))
      .orderBy(desc(aiChatSessions.startedAt))
      .limit(1);
    
    return session || undefined;
  }

  async endAiChatSession(sessionId: string): Promise<boolean> {
    const [updated] = await db.update(aiChatSessions)
      .set({ 
        isActive: false, 
        endedAt: sql`CURRENT_TIMESTAMP` 
      })
      .where(eq(aiChatSessions.sessionId, sessionId))
      .returning();
    
    return !!updated;
  }

  // Voice Settings methods
  async getVoiceSettings(): Promise<VoiceSettings> {
    const [settings] = await db.select().from(voiceSettings).limit(1);
    
    // Если настроек нет, создаем дефолтные
    if (!settings) {
      const [newSettings] = await db
        .insert(voiceSettings)
        .values({
          engine: 'rhvoice',
          voiceName: 'elena',
          rate: 100,
          pitch: 100,
          volume: 100,
          enabled: true
        })
        .returning();
      return newSettings;
    }
    
    return settings;
  }

  async updateVoiceSettings(data: Partial<InsertVoiceSettings>): Promise<VoiceSettings> {
    // Получаем текущие настройки
    const currentSettings = await this.getVoiceSettings();
    
    // Обновляем настройки
    const [updatedSettings] = await db
      .update(voiceSettings)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(voiceSettings.id, currentSettings.id))
      .returning();
    
    return updatedSettings;
  }

  // Display Board Settings methods
  async getDisplayBoardSettings(): Promise<DisplayBoardSettings | undefined> {
    const [settings] = await db.select().from(displayBoardSettings).limit(1);
    return settings || undefined;
  }

  async updateDisplayBoardSettings(data: InsertDisplayBoardSettings): Promise<DisplayBoardSettings> {
    const existing = await this.getDisplayBoardSettings();
    
    if (existing) {
      const [updated] = await db
        .update(displayBoardSettings)
        .set({ ...data, updatedAt: sql`CURRENT_TIMESTAMP` })
        .where(eq(displayBoardSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(displayBoardSettings)
        .values(data)
        .returning();
      return created;
    }
  }

  // Display Boards methods
  async getDisplayBoards(): Promise<DisplayBoard[]> {
    return await db.select().from(displayBoards).orderBy(displayBoards.address);
  }

  async getDisplayBoard(id: number): Promise<DisplayBoard | undefined> {
    const [board] = await db.select().from(displayBoards).where(eq(displayBoards.id, id));
    return board || undefined;
  }

  async getDisplayBoardByOperator(operatorId: number): Promise<DisplayBoard | undefined> {
    const [board] = await db.select().from(displayBoards)
      .where(and(eq(displayBoards.operatorId, operatorId), eq(displayBoards.enabled, true)));
    return board || undefined;
  }

  async createDisplayBoard(board: InsertDisplayBoard): Promise<DisplayBoard> {
    const [created] = await db.insert(displayBoards).values(board).returning();
    return created;
  }

  async updateDisplayBoard(id: number, board: Partial<InsertDisplayBoard>): Promise<DisplayBoard> {
    const [updated] = await db
      .update(displayBoards)
      .set({ ...board, lastUpdated: sql`CURRENT_TIMESTAMP` })
      .where(eq(displayBoards.id, id))
      .returning();
    return updated;
  }

  async deleteDisplayBoard(id: number): Promise<boolean> {
    const result = await db.delete(displayBoards).where(eq(displayBoards.id, id));
    return (result.rowCount || 0) > 0;
  }

  async updateDisplayBoardTicket(operatorId: number, ticketNumber: string | null): Promise<boolean> {
    const result = await db
      .update(displayBoards)
      .set({ 
        currentTicket: ticketNumber,
        lastUpdated: sql`CURRENT_TIMESTAMP` 
      })
      .where(and(eq(displayBoards.operatorId, operatorId), eq(displayBoards.enabled, true)));
    return (result.rowCount || 0) > 0;
  }

  // Operator Chat methods
  async getOperatorChatMessages(operatorId?: number, receiverId?: number): Promise<OperatorChatMessage[]> {
    if (operatorId && receiverId) {
      return await db.select().from(operatorChatMessages)
        .where(
          and(
            eq(operatorChatMessages.senderId, operatorId),
            eq(operatorChatMessages.receiverId, receiverId)
          )
        )
        .orderBy(desc(operatorChatMessages.createdAt));
    } else if (operatorId) {
      return await db.select().from(operatorChatMessages)
        .where(eq(operatorChatMessages.senderId, operatorId))
        .orderBy(desc(operatorChatMessages.createdAt));
    } else if (receiverId) {
      return await db.select().from(operatorChatMessages)
        .where(eq(operatorChatMessages.receiverId, receiverId))
        .orderBy(desc(operatorChatMessages.createdAt));
    }
    
    return await db.select().from(operatorChatMessages)
      .orderBy(desc(operatorChatMessages.createdAt));
  }

  async createOperatorChatMessage(message: InsertOperatorChatMessage): Promise<OperatorChatMessage> {
    const [created] = await db.insert(operatorChatMessages).values(message).returning();
    return created;
  }

  async getUnreadMessagesCount(operatorId: number): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(operatorChatMessages)
      .where(and(
        eq(operatorChatMessages.receiverId, operatorId),
        eq(operatorChatMessages.isRead, false)
      ));
    
    return result[0]?.count || 0;
  }

  async getOperatorMessages(operatorId: number): Promise<any[]> {
    return await db
      .select({
        id: operatorChatMessages.id,
        senderId: operatorChatMessages.senderId,
        message: operatorChatMessages.message,
        isRead: operatorChatMessages.isRead,
        createdAt: operatorChatMessages.createdAt,
        senderName: sql<string>`CASE 
          WHEN ${operatorChatMessages.senderId} IS NULL THEN 'Администратор зала'
          ELSE CONCAT(${operators.firstName}, ' ', ${operators.lastName})
        END`
      })
      .from(operatorChatMessages)
      .leftJoin(operators, eq(operatorChatMessages.senderId, operators.id))
      .where(eq(operatorChatMessages.receiverId, operatorId))
      .orderBy(desc(operatorChatMessages.createdAt))
      .limit(50);
  }

  async markMessagesAsRead(operatorId: number): Promise<void> {
    await db
      .update(operatorChatMessages)
      .set({ isRead: true })
      .where(and(
        eq(operatorChatMessages.receiverId, operatorId),
        eq(operatorChatMessages.isRead, false)
      ));
  }

  async markMessageAsRead(messageId: number): Promise<void> {
    await db
      .update(operatorChatMessages)
      .set({ isRead: true })
      .where(eq(operatorChatMessages.id, messageId));
  }

  // Operator Status methods
  async getAllOperatorStatuses(): Promise<OperatorStatus[]> {
    return await db
      .select()
      .from(operatorStatus);
  }

  async getOperatorStatus(operatorId: number): Promise<OperatorStatus | undefined> {
    const [status] = await db
      .select()
      .from(operatorStatus)
      .where(eq(operatorStatus.operatorId, operatorId));
    return status || undefined;
  }

  async updateOperatorStatus(operatorId: number, status: Partial<InsertOperatorStatus>): Promise<OperatorStatus> {
    // Проверяем существует ли запись
    const existing = await this.getOperatorStatus(operatorId);
    
    if (existing) {
      const [updated] = await db
        .update(operatorStatus)
        .set({
          ...status,
          updatedAt: sql`CURRENT_TIMESTAMP`,
          lastActivity: sql`CURRENT_TIMESTAMP`
        })
        .where(eq(operatorStatus.operatorId, operatorId))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(operatorStatus)
        .values({
          operatorId,
          ...status,
          lastActivity: sql`CURRENT_TIMESTAMP`,
          updatedAt: sql`CURRENT_TIMESTAMP`
        })
        .returning();
      return created;
    }
  }

  async setOperatorBreak(operatorId: number, reason?: string): Promise<OperatorStatus> {
    return await this.updateOperatorStatus(operatorId, {
      status: 'break',
      breakStartTime: new Date(),
      breakReason: reason,
      breakEndTime: null
    });
  }

  async endOperatorBreak(operatorId: number): Promise<OperatorStatus> {
    return await this.updateOperatorStatus(operatorId, {
      status: 'available',
      breakEndTime: new Date(),
      breakReason: null
    });
  }

  // Statistics methods
  async getActiveTicketCount(): Promise<number> {
    const results = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(tickets)
      .where(
        and(
          eq(tickets.status, 'waiting'),
          isNull(tickets.completedAt)
        )
      );
    return results[0]?.count || 0;
  }

  async getCompletedTicketsToday(): Promise<number> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    const results = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(tickets)
      .where(
        and(
          eq(tickets.status, 'completed'),
          sql`${tickets.completedAt} >= ${today}`,
          sql`${tickets.completedAt} < ${tomorrow}`
        )
      );
    return results[0]?.count || 0;
  }

  async getAppointmentsTodayCount(): Promise<number> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    const results = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(appointments)
      .where(
        and(
          sql`${appointments.appointmentDate} >= ${today}`,
          sql`${appointments.appointmentDate} < ${tomorrow}`
        )
      );
    return results[0]?.count || 0;
  }

  async getAverageWaitTime(): Promise<number> {
    const results = await db
      .select({ 
        avgTime: sql<number>`AVG(EXTRACT(EPOCH FROM (completed_at - created_at)) / 60)` 
      })
      .from(tickets)
      .where(
        and(
          eq(tickets.status, 'completed'),
          isNotNull(tickets.completedAt)
        )
      );
    return results[0]?.avgTime || 0;
  }

  async getNoShowTicketsToday(): Promise<number> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    const results = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(tickets)
      .where(
        and(
          eq(tickets.status, 'no_show'),
          sql`${tickets.createdAt} >= ${today}`,
          sql`${tickets.createdAt} < ${tomorrow}`
        )
      );
    return results[0]?.count || 0;
  }

  // Database backup methods
  async createDatabaseBackup(backup: InsertDatabaseBackup): Promise<DatabaseBackup> {
    const [created] = await db.insert(databaseBackups).values(backup).returning();
    return created;
  }

  async getDatabaseBackups(): Promise<DatabaseBackup[]> {
    return await db.select().from(databaseBackups).orderBy(desc(databaseBackups.createdAt));
  }

  async deleteDatabaseBackup(id: number): Promise<boolean> {
    const result = await db.delete(databaseBackups).where(eq(databaseBackups.id, id));
    return (result as any).rowCount > 0;
  }

  // Import record methods
  async createImportRecord(record: InsertImportRecord): Promise<ImportRecord> {
    const [created] = await db.insert(importRecords).values(record).returning();
    return created;
  }

  async checkImportRecord(tableType: string, importHash: string): Promise<ImportRecord | undefined> {
    const [record] = await db.select().from(importRecords)
      .where(and(
        eq(importRecords.tableType, tableType),
        eq(importRecords.importHash, importHash)
      ));
    return record || undefined;
  }

  // Full database backup
  async createFullDatabaseBackup(): Promise<{ filePath: string; fileSize: number; recordsCount: number }> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const fileName = `full_backup_${timestamp}.sql`;
    const filePath = `./backups/${fileName}`;
    
    // Создаем директорию для бэкапов если не существует
    const fs = require('fs');
    const path = require('path');
    const backupDir = './backups';
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }

    // Получаем DATABASE_URL из env
    const databaseUrl = process.env.DATABASE_URL;
    if (!databaseUrl) {
      throw new Error('DATABASE_URL не найден в переменных окружения');
    }

    // Выполняем pg_dump для создания полной резервной копии
    const { execSync } = require('child_process');
    try {
      execSync(`pg_dump "${databaseUrl}" > "${filePath}"`, { stdio: 'inherit' });
      
      // Получаем размер файла
      const stats = fs.statSync(filePath);
      const fileSize = stats.size;
      
      // Подсчитываем общее количество записей во всех таблицах
      const countResults = await db.execute(
        sql`SELECT COALESCE(SUM(n_tup_ins), 0) as total
            FROM pg_stat_all_tables 
            WHERE schemaname = 'public'`
      );
      const recordsCount = (countResults.rows[0] as any)?.total || 0;

      return { filePath, fileSize, recordsCount };
    } catch (error) {
      console.error('Ошибка создания резервной копии:', error);
      throw new Error('Не удалось создать резервную копию базы данных');
    }
  }

  // Clear database with PIN protection
  async clearDatabaseWithProtection(pin: string): Promise<{ cleared: boolean; tablesCleared: string[] }> {
    const correctPin = '2025';
    if (pin !== correctPin) {
      return { cleared: false, tablesCleared: [] };
    }

    const tablesCleared: string[] = [];
    
    try {
      // Очищаем таблицы в правильном порядке (учитывая foreign keys)
      const tablesToClear = [
        'call_history',
        'service_ratings', 
        'operator_chat_messages',
        'import_records',
        'tickets',
        'appointments',
        'ai_chat_logs',
        'ai_chat_sessions',
        'import_export_logs',
        'statistics_cache'
      ];

      for (const tableName of tablesToClear) {
        try {
          await db.execute(sql.raw(`TRUNCATE TABLE ${tableName} CASCADE`));
          tablesCleared.push(tableName);
        } catch (error) {
          console.error(`Ошибка очистки таблицы ${tableName}:`, error);
        }
      }

      // Сбрасываем последовательности для автоинкрементных полей
      const sequencesToReset = [
        'tickets_id_seq',
        'appointments_id_seq', 
        'call_history_id_seq',
        'service_ratings_id_seq',
        'operator_chat_messages_id_seq',
        'import_records_id_seq',
        'ai_chat_logs_id_seq',
        'ai_chat_sessions_id_seq',
        'import_export_logs_id_seq',
        'statistics_cache_id_seq'
      ];

      for (const seqName of sequencesToReset) {
        try {
          await db.execute(sql.raw(`ALTER SEQUENCE ${seqName} RESTART WITH 1`));
        } catch (error) {
          // Игнорируем ошибки сброса последовательностей
        }
      }

      return { cleared: true, tablesCleared };
    } catch (error) {
      console.error('Ошибка очистки базы данных:', error);
      return { cleared: false, tablesCleared };
    }
  }

  // Security Settings methods
  async getSecuritySettings(): Promise<SecuritySettings | undefined> {
    const [settings] = await db.select().from(securitySettings).limit(1);
    
    // Если настроек нет, создаем настройки по умолчанию
    if (!settings) {
      const defaultSettings = {
        externalAccessRestricted: false,
        allowedExternalPaths: ['/booking'],
        internalNetworkRanges: ['192.168.0.0/16', '10.0.0.0/8', '172.16.0.0/12', '127.0.0.1'],
        updatedBy: 'system'
      };
      
      const [created] = await db.insert(securitySettings)
        .values(defaultSettings)
        .returning();
      return created;
    }
    
    return settings;
  }

  async updateSecuritySettings(settings: InsertSecuritySettings): Promise<SecuritySettings> {
    // Проверяем есть ли уже настройки
    const existing = await this.getSecuritySettings();
    
    if (existing) {
      // Обновляем существующие
      const [updated] = await db.update(securitySettings)
        .set({ 
          ...settings, 
          updatedAt: sql`CURRENT_TIMESTAMP` 
        })
        .where(eq(securitySettings.id, existing.id))
        .returning();
      return updated;
    } else {
      // Создаем новые
      const [created] = await db.insert(securitySettings)
        .values({ 
          ...settings,
          updatedAt: sql`CURRENT_TIMESTAMP`
        })
        .returning();
      return created;
    }
  }

  // Terminal settings methods
  async getTerminalSettingsByTerminalId(terminalId: string): Promise<TerminalSettings | undefined> {
    const [settings] = await db.select()
      .from(terminalSettings)
      .where(eq(terminalSettings.terminalId, terminalId));
    return settings || undefined;
  }

  async createOrUpdateTerminalSettings(settings: any): Promise<TerminalSettings> {
    const existingSettings = await this.getTerminalSettingsByTerminalId(settings.terminalId);
    
    if (existingSettings) {
      // Обновляем существующие настройки
      const [updated] = await db.update(terminalSettings)
        .set({
          ...settings,
          updatedAt: sql`CURRENT_TIMESTAMP`
        })
        .where(eq(terminalSettings.terminalId, settings.terminalId))
        .returning();
      return updated;
    } else {
      // Создаем новые настройки
      const [created] = await db.insert(terminalSettings)
        .values(settings)
        .returning();
      return created;
    }
  }

  // Display settings methods
  async getDisplaySettingsByDisplayId(displayId: string): Promise<DisplaySettings | undefined> {
    const [settings] = await db.select()
      .from(displaySettings)
      .where(eq(displaySettings.displayId, displayId));
    return settings || undefined;
  }

  async createOrUpdateDisplaySettings(settings: any): Promise<DisplaySettings> {
    const existingSettings = await this.getDisplaySettingsByDisplayId(settings.displayId);
    
    if (existingSettings) {
      // Обновляем существующие настройки
      const [updated] = await db.update(displaySettings)
        .set({
          ...settings,
          updatedAt: sql`CURRENT_TIMESTAMP`
        })
        .where(eq(displaySettings.displayId, settings.displayId))
        .returning();
      return updated;
    } else {
      // Создаем новые настройки
      const [created] = await db.insert(displaySettings)
        .values(settings)
        .returning();
      return created;
    }
  }

  // Operator Messages methods implementation
  async getOperatorMessages(): Promise<OperatorMessage[]> {
    return await db
      .select()
      .from(operatorChatMessages)
      .orderBy(desc(operatorChatMessages.createdAt));
  }

  async createOperatorMessage(message: InsertOperatorMessage): Promise<OperatorMessage> {
    const [created] = await db
      .insert(operatorChatMessages)
      .values(message)
      .returning();
    return created;
  }

  async markMessagesAsRead(messageIds: number[]): Promise<void> {
    if (messageIds.length === 0) return;
    
    for (const messageId of messageIds) {
      await db
        .update(operatorChatMessages)
        .set({ isRead: true })
        .where(eq(operatorChatMessages.id, messageId));
    }
  }

  // Schedule Management methods implementation
  async updateDepartmentSchedule(departmentId: number, scheduleData: { workSchedule?: any; holidays?: string[]; workingHours?: any }): Promise<Department> {
    const [updated] = await db
      .update(departments)
      .set({
        workSchedule: scheduleData.workSchedule,
        holidays: scheduleData.holidays,
        workingHours: scheduleData.workingHours,
        updatedAt: sql`CURRENT_TIMESTAMP`
      })
      .where(eq(departments.id, departmentId))
      .returning();
    return updated;
  }

  async getDepartment(departmentId: number): Promise<Department | undefined> {
    const [department] = await db
      .select()
      .from(departments)
      .where(eq(departments.id, departmentId));
    return department;
  }

  async isCurrentlyWorking(departmentId: number): Promise<{isWorking: boolean, reason: string}> {
    const department = await this.getDepartment(departmentId);
    
    if (!department) {
      return { isWorking: false, reason: 'department_not_found' };
    }
    
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
    const currentTime = now.toTimeString().slice(0, 5); // HH:MM format
    const currentDate = now.toISOString().split('T')[0]; // YYYY-MM-DD format
    
    const workSchedule = department.workSchedule || {};
    const holidays = department.holidays || [];
    
    // Check if today is a holiday
    if (holidays.includes(currentDate)) {
      return { isWorking: false, reason: 'holiday' };
    }
    
    // Map day of week to schedule key
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayKey = days[dayOfWeek];
    const daySchedule = workSchedule[dayKey];
    
    if (!daySchedule || !daySchedule.isWorkingDay) {
      return { isWorking: false, reason: 'non_working_day' };
    }
    
    // Check if current time is within working hours
    if (daySchedule.startTime && daySchedule.endTime) {
      const isWithinHours = currentTime >= daySchedule.startTime && currentTime <= daySchedule.endTime;
      return { 
        isWorking: isWithinHours, 
        reason: isWithinHours ? 'working_hours' : 'outside_hours'
      };
    }
    
    return { isWorking: true, reason: 'no_restrictions' };
  }

  async getDepartmentSchedule(departmentId: number): Promise<{ workSchedule?: any; holidays?: string[] } | undefined> {
    const [department] = await db
      .select({
        workSchedule: departments.workSchedule,
        holidays: departments.holidays
      })
      .from(departments)
      .where(eq(departments.id, departmentId));
    return department;
  }

  async checkBookingAvailability(departmentId: number, date: string, time: string): Promise<boolean> {
    const department = await this.getDepartmentSchedule(departmentId);
    if (!department) return false;

    // Check if date is a holiday
    if (department.holidays && department.holidays.includes(date)) {
      return false;
    }

    // Check day of week schedule
    const dayOfWeek = new Date(date).toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
    const daySchedule = department.workSchedule?.[dayOfWeek];
    
    if (!daySchedule || !daySchedule.isWorking) {
      return false;
    }

    // Check if time is within working hours
    const [hours, minutes] = time.split(':').map(Number);
    const timeMinutes = hours * 60 + minutes;
    
    const [startHours, startMinutes] = daySchedule.startTime.split(':').map(Number);
    const startTimeMinutes = startHours * 60 + startMinutes;
    
    const [endHours, endMinutes] = daySchedule.endTime.split(':').map(Number);
    const endTimeMinutes = endHours * 60 + endMinutes;

    // Check if time is within break hours
    if (daySchedule.breakStart && daySchedule.breakEnd) {
      const [breakStartHours, breakStartMinutes] = daySchedule.breakStart.split(':').map(Number);
      const breakStartTimeMinutes = breakStartHours * 60 + breakStartMinutes;
      
      const [breakEndHours, breakEndMinutes] = daySchedule.breakEnd.split(':').map(Number);
      const breakEndTimeMinutes = breakEndHours * 60 + breakEndMinutes;
      
      if (timeMinutes >= breakStartTimeMinutes && timeMinutes <= breakEndTimeMinutes) {
        return false;
      }
    }

    return timeMinutes >= startTimeMinutes && timeMinutes <= endTimeMinutes;
  }

  // Export methods for data management
  async getAllOperators(): Promise<any[]> {
    const operators = await db.select().from(operatorsTable);
    return operators;
  }

  async getAllDepartments(): Promise<any[]> {
    const departments = await db.select().from(departmentsTable);
    return departments;
  }

  async getAllServices(): Promise<any[]> {
    const services = await db.select().from(servicesTable);
    return services;
  }

  async getAllTickets(): Promise<any[]> {
    const tickets = await db.select().from(ticketsTable);
    return tickets;
  }
}

export const storage = new DatabaseStorage();
