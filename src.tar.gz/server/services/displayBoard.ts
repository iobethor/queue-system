import { SerialPort, ReadlineParser } from 'serialport';
import { storage } from '../storage';

export class DisplayBoardService {
  private port: SerialPort | null = null;
  private parser: ReadlineParser | null = null;
  private isConnected = false;

  /**
   * Инициализирует подключение к COM-порту
   */
  async initialize(): Promise<boolean> {
    try {
      const settings = await storage.getDisplayBoardSettings();
      if (!settings || !settings.enabled) {
        console.log('Табло отключены в настройках');
        return false;
      }

      if (this.isConnected) {
        console.log('Табло уже подключены');
        return true;
      }

      this.port = new SerialPort({
        path: settings.portPath,
        baudRate: settings.baudRate,
        autoOpen: false
      });

      this.parser = new ReadlineParser();
      this.port.pipe(this.parser);

      return new Promise((resolve) => {
        this.port!.open((err) => {
          if (err) {
            console.error('Ошибка подключения к табло:', err);
            resolve(false);
          } else {
            this.isConnected = true;
            console.log(`Табло подключены через ${settings.portPath} на ${settings.baudRate} baud`);
            
            // Слушаем ответы от табло
            this.parser!.on('data', (data) => {
              this.handleResponse(data);
            });

            resolve(true);
          }
        });
      });
    } catch (error) {
      console.error('Ошибка инициализации табло:', error);
      return false;
    }
  }

  /**
   * Отправляет команду на табло
   */
  private async sendCommand(address: number, command: Buffer): Promise<boolean> {
    if (!this.isConnected || !this.port) {
      console.log('Табло не подключены');
      return false;
    }

    try {
      // Формируем пакет: $E0 + адрес + команда + CRC
      const packet = Buffer.concat([
        Buffer.from([0xE0]), // Заголовок пакета
        Buffer.from([address]), // Адрес табло
        command, // Команда
        this.calculateCRC(Buffer.concat([Buffer.from([0xE0, address]), command]))
      ]);

      return new Promise((resolve) => {
        this.port!.write(packet, (err) => {
          if (err) {
            console.error(`Ошибка отправки команды на табло ${address}:`, err);
            resolve(false);
          } else {
            resolve(true);
          }
        });
      });
    } catch (error) {
      console.error('Ошибка формирования пакета:', error);
      return false;
    }
  }

  /**
   * Показать номер талона на табло
   */
  async showTicket(operatorId: number, ticketNumber: string): Promise<boolean> {
    try {
      const board = await storage.getDisplayBoardByOperator(operatorId);
      if (!board) {
        console.log(`Табло для оператора ${operatorId} не найдено`);
        return false;
      }

      // Команда отображения: $00 + номер + буква
      const ticketText = ticketNumber.padEnd(8, ' '); // Дополняем пробелами до 8 символов
      const command = Buffer.concat([
        Buffer.from([0x00]), // Команда отображения
        Buffer.from(ticketText, 'ascii')
      ]);

      const success = await this.sendCommand(board.address, command);
      if (success) {
        // Обновляем текущий талон в базе данных
        await storage.updateDisplayBoardTicket(operatorId, ticketNumber);
        console.log(`Табло ${board.address}: показан талон ${ticketNumber}`);
      }

      return success;
    } catch (error) {
      console.error('Ошибка отображения талона:', error);
      return false;
    }
  }

  /**
   * Очистить табло
   */
  async clearBoard(operatorId: number): Promise<boolean> {
    try {
      const board = await storage.getDisplayBoardByOperator(operatorId);
      if (!board) {
        console.log(`Табло для оператора ${operatorId} не найдено`);
        return false;
      }

      // Команда очистки: $00 + пустые символы
      const command = Buffer.concat([
        Buffer.from([0x00]), // Команда отображения
        Buffer.from('        ', 'ascii') // 8 пробелов для очистки
      ]);

      const success = await this.sendCommand(board.address, command);
      if (success) {
        // Убираем текущий талон из базы данных
        await storage.updateDisplayBoardTicket(operatorId, null);
        console.log(`Табло ${board.address}: очищено`);
      }

      return success;
    } catch (error) {
      console.error('Ошибка очистки табло:', error);
      return false;
    }
  }

  /**
   * Воспроизвести звуковой сигнал
   */
  async playSound(operatorId: number, soundType: 'call' | 'complete' = 'call'): Promise<boolean> {
    try {
      const board = await storage.getDisplayBoardByOperator(operatorId);
      if (!board) {
        return false;
      }

      // Команда звука: $50 + тип звука
      const soundCode = soundType === 'call' ? 0x01 : 0x02;
      const command = Buffer.from([0x50, soundCode]);

      const success = await this.sendCommand(board.address, command);
      if (success) {
        console.log(`Табло ${board.address}: воспроизведен звук ${soundType}`);
      }

      return success;
    } catch (error) {
      console.error('Ошибка воспроизведения звука:', error);
      return false;
    }
  }

  /**
   * Тестирование соединения с табло
   */
  async testConnection(address?: number): Promise<boolean> {
    if (!this.isConnected) {
      await this.initialize();
    }

    if (address) {
      // Тестируем конкретное табло
      const testCommand = Buffer.from([0xFF, 0x01]); // Команда пинга
      return await this.sendCommand(address, testCommand);
    } else {
      // Тестируем все табло
      const boards = await storage.getDisplayBoards();
      let allOk = true;

      for (const board of boards.filter(b => b.enabled)) {
        const testCommand = Buffer.from([0xFF, 0x01]); // Команда пинга
        const result = await this.sendCommand(board.address, testCommand);
        if (!result) {
          console.error(`Табло ${board.address} не отвечает`);
          allOk = false;
        }
      }

      return allOk;
    }
  }

  /**
   * Обработка ответов от табло
   */
  private handleResponse(data: string): void {
    try {
      const buffer = Buffer.from(data, 'hex');
      if (buffer.length < 2) return;

      const address = buffer[0];
      const status = buffer[1];

      console.log(`Табло ${address}: статус 0x${status.toString(16)}`);

      // Обработка различных статусов
      switch (status) {
        case 0x00:
          console.log(`Табло ${address}: команда выполнена`);
          break;
        case 0xFF:
          console.log(`Табло ${address}: ошибка выполнения`);
          break;
        case 0x01:
          console.log(`Табло ${address}: готово к работе`);
          break;
        default:
          console.log(`Табло ${address}: неизвестный статус 0x${status.toString(16)}`);
      }
    } catch (error) {
      console.error('Ошибка обработки ответа табло:', error);
    }
  }

  /**
   * Вычисление CRC для пакета
   */
  private calculateCRC(data: Buffer): Buffer {
    let crc = 0;
    for (let i = 0; i < data.length; i++) {
      crc ^= data[i];
      for (let j = 0; j < 8; j++) {
        if (crc & 0x80) {
          crc = (crc << 1) ^ 0x07;
        } else {
          crc = crc << 1;
        }
        crc &= 0xFF;
      }
    }
    return Buffer.from([crc]);
  }

  /**
   * Закрытие соединения
   */
  async disconnect(): Promise<void> {
    if (this.port && this.isConnected) {
      return new Promise((resolve) => {
        this.port!.close((err) => {
          if (err) {
            console.error('Ошибка отключения табло:', err);
          } else {
            console.log('Табло отключены');
          }
          this.isConnected = false;
          this.port = null;
          this.parser = null;
          resolve();
        });
      });
    }
  }

  /**
   * Проверка статуса подключения
   */
  getConnectionStatus(): boolean {
    return this.isConnected;
  }

  /**
   * Получение информации о подключении
   */
  async getConnectionInfo(): Promise<any> {
    const settings = await storage.getDisplayBoardSettings();
    const boards = await storage.getDisplayBoards();
    
    return {
      connected: this.isConnected,
      settings: settings || { portPath: '', baudRate: 0, enabled: false },
      boardCount: boards.length,
      activeBoards: boards.filter(b => b.enabled).length
    };
  }
}

// Глобальный экземпляр сервиса табло
export const displayBoardService = new DisplayBoardService();

// Автоматическая инициализация при запуске сервера
displayBoardService.initialize().catch(error => {
  console.error('Ошибка автоматической инициализации табло:', error);
});