import { WebSocketServer, WebSocket } from 'ws';

interface ClientInfo {
  id: string;
  type: 'dashboard' | 'terminal' | 'operator' | 'display' | 'admin';
  userId?: number;
  windowNumber?: number;
}

class WebSocketService {
  private clients: Map<WebSocket, ClientInfo> = new Map();

  setupWebSocket(wss: WebSocketServer) {
    wss.on('connection', (ws: WebSocket) => {
      console.log('WebSocket клиент подключен');

      ws.on('message', (message: Buffer) => {
        try {
          const data = JSON.parse(message.toString());
          this.handleMessage(ws, data);
        } catch (error) {
          console.error('Ошибка обработки WebSocket сообщения:', error);
          ws.send(JSON.stringify({ type: 'error', message: 'Некорректный формат сообщения' }));
        }
      });

      ws.on('close', () => {
        console.log('WebSocket клиент отключен');
        this.clients.delete(ws);
      });

      ws.on('error', (error) => {
        console.error('WebSocket ошибка:', error);
        this.clients.delete(ws);
      });

      // Отправляем приветственное сообщение
      ws.send(JSON.stringify({ 
        type: 'connected', 
        message: 'Подключение к системе очередей установлено' 
      }));
    });
  }

  private handleMessage(ws: WebSocket, data: any) {
    switch (data.type) {
      case 'register':
        this.registerClient(ws, data);
        break;
      case 'ping':
        ws.send(JSON.stringify({ type: 'pong' }));
        break;
      default:
        console.log('Неизвестный тип сообщения:', data.type);
    }
  }

  private registerClient(ws: WebSocket, data: any) {
    const clientInfo: ClientInfo = {
      id: data.id || `client_${Date.now()}`,
      type: data.clientType || 'dashboard',
      userId: data.userId,
      windowNumber: data.windowNumber
    };

    this.clients.set(ws, clientInfo);
    console.log(`Клиент зарегистрирован: ${clientInfo.type} (${clientInfo.id})`);

    ws.send(JSON.stringify({ 
      type: 'registered', 
      clientInfo 
    }));
  }

  // Методы для отправки уведомлений разным типам клиентов
  broadcastToAll(type: string, data?: any) {
    const message = { type, ...data };
    this.clients.forEach((clientInfo, ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(message));
      }
    });
  }

  broadcastMessage(type: string, data?: any) {
    const message = { type, ...data };
    this.clients.forEach((clientInfo, ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(message));
      }
    });
  }

  broadcastToType(clientType: string, message: any) {
    this.clients.forEach((clientInfo, ws) => {
      if (clientInfo.type === clientType && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(message));
      }
    });
  }

  sendToOperator(operatorId: number, message: any) {
    this.clients.forEach((clientInfo, ws) => {
      if (clientInfo.type === 'operator' && clientInfo.userId === operatorId && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(message));
      }
    });
  }

  // Уведомления о событиях очереди
  // Добавляем метод broadcast для совместимости
  broadcast(message: any) {
    this.broadcastToAll(message.type, message.data);
  }

  notifyTicketCreated(ticket: any) {
    this.broadcastToAll('ticket_created', { ticket });
  }

  notifyTicketCalled(ticket: any) {
    this.broadcastToAll('ticket_called', { ticket });
  }

  notifyTicketCompleted(ticket: any) {
    this.broadcastToAll('ticket_completed', { ticket });
  }

  notifyQueueUpdate(queueData: any) {
    this.broadcastToType('display', {
      type: 'queue_update',
      data: queueData
    });
  }

  notifyOperatorUpdate(operatorData: any) {
    this.broadcastToType('operator', {
      type: 'operator_update',
      data: operatorData
    });
  }
}

const wsService = new WebSocketService();

export function setupWebSocket(wss: WebSocketServer) {
  wsService.setupWebSocket(wss);
}

export { wsService };
