import axios from 'axios';

interface OllamaResponse {
  response: string;
  done: boolean;
  context?: number[];
}

interface HuggingFaceResponse {
  generated_text: string;
}

interface ModuleContext {
  booking: string;
  terminal: string;
  operator: string;
  display: string;
  admin: string;
}

class OllamaService {
  private baseUrl: string;
  private model: string;
  private moduleContexts: ModuleContext;

  constructor() {
    this.baseUrl = process.env.OLLAMA_URL || 'http://localhost:11434';
    this.model = process.env.OLLAMA_MODEL || 'llama3:8b';
    this.moduleContexts = {
      booking: `Ты помощник модуля предварительной записи. Помогаешь клиентам записаться на услуги, 
      объясняешь требуемые документы, расписание работы. Отвечай вежливо и информативно на русском языке.
      Не выходи за рамки организации и её услуг.`,
      
      terminal: `Ты помощник терминала выдачи талонов. Помогаешь клиентам выбрать нужную услугу,
      объясняешь процедуру получения талона и время ожидания. Будь краток и понятен.
      Фокусируйся только на услугах этой организации.`,
      
      operator: `Ты помощник для оператора. Помогаешь с информацией о клиентах, услугах, процедурах.
      Предоставляй быстрые справки по документам и требованиям. Отвечай четко и профессионально.
      Ориентируйся на внутренние процессы организации.`,
      
      display: `Ты помощник информационного табло. Предоставляешь общую информацию об очереди,
      времени ожидания, работе окон. Информация должна быть публичной и понятной всем посетителям.
      Избегай внутренней информации организации.`,
      
      admin: `Ты помощник администратора системы очередей. Анализируешь статистику, прогнозируешь нагрузку,
      помогаешь с настройкой системы и отчетами. Предоставляй детальную аналитику и рекомендации.
      Имеешь доступ ко всем данным системы для анализа.`
    };
  }

  async isAvailable(): Promise<boolean> {
    try {
      const response = await axios.get(`${this.baseUrl}/api/tags`, { timeout: 5000 });
      return response.status === 200;
    } catch (error) {
      console.error('Ollama не доступен:', error);
      return false;
    }
  }

  async chatWithSettings(message: string, settings: { model: string; temperature: number; context: string; module: string; providerType?: string; apiKey?: string; apiUrl?: string }): Promise<string> {
    try {
      const prompt = `${settings.context}\n\nПользователь: ${message}\nАссистент:`;
      
      // Определяем провайдер по типу или модели
      const providerType = settings.providerType || this.detectProviderType(settings.model);
      
      switch (providerType) {
        case 'huggingface':
          return await this.chatWithHuggingFaceSettings(message, settings);
        case 'openai':
          return await this.chatWithOpenAISettings(message, settings);
        case 'anthropic':
          return await this.chatWithAnthropicSettings(message, settings);
        case 'gemini':
          return await this.chatWithGeminiSettings(message, settings);
        default:
          // Ollama (локальный)
          return await this.chatWithOllamaSettings(message, settings);
      }
    } catch (error: any) {
      console.error('Ошибка AI chatWithSettings:', error);
      throw error;
    }
  }

  private detectProviderType(model: string): string {
    if (model.includes('gemma') || model === 'huggingface') {
      return 'huggingface';
    } else if (model.startsWith('gpt-')) {
      return 'openai';
    } else if (model.startsWith('claude-')) {
      return 'anthropic';
    } else if (model.startsWith('gemini-')) {
      return 'gemini';
    }
    return 'ollama';
  }

  private async chatWithOllamaSettings(message: string, settings: { model: string; temperature: number; context: string; apiUrl?: string }): Promise<string> {
    const baseUrl = settings.apiUrl || this.baseUrl;
    const prompt = `${settings.context}\n\nПользователь: ${message}\nАссистент:`;
    
    const response = await axios.post(`${baseUrl}/api/generate`, {
      model: settings.model,
      prompt: prompt,
      options: {
        temperature: settings.temperature
      },
      stream: false
    }, {
      timeout: 30000
    });

    return response.data.response || 'Извините, не удалось получить ответ.';
  }

  private async chatWithHuggingFaceSettings(message: string, settings: { model: string; temperature: number; context: string; apiKey?: string }): Promise<string> {
    const apiKey = settings.apiKey || process.env.HUGGINGFACE_API_KEY || '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';
    const prompt = `${settings.context}\n\nВопрос пользователя: ${message}\nОтвет:`;
    
    // Определяем URL модели
    const modelUrl = settings.model.startsWith('http') 
      ? settings.model 
      : `https://api-inference.huggingface.co/models/${settings.model === 'huggingface' ? 'google/gemma-2b-it' : settings.model}`;

    const response = await axios.post(modelUrl, {
      inputs: prompt,
      parameters: {
        max_new_tokens: 300,
        temperature: settings.temperature,
        do_sample: true,
        return_full_text: false
      }
    }, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      timeout: 20000
    });

    if (response.data && Array.isArray(response.data) && response.data[0] && response.data[0].generated_text) {
      let generatedText = response.data[0].generated_text;
      
      if (generatedText.includes('Ответ:')) {
        generatedText = generatedText.split('Ответ:').pop()?.trim() || generatedText;
      }
      
      const sentences = generatedText.split(/[.!?]\s+/);
      const cleanResponse = sentences.length > 1 
        ? sentences.slice(0, -1).join('. ') + '.'
        : generatedText.trim();
      
      return cleanResponse || 'Извините, не удалось получить подходящий ответ.';
    }

    throw new Error('Неверный формат ответа от Hugging Face API');
  }

  private async chatWithOpenAISettings(message: string, settings: { model: string; temperature: number; context: string; apiKey?: string }): Promise<string> {
    const apiKey = settings.apiKey || process.env.OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error('OpenAI API ключ не настроен');
    }
    
    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: settings.model,
      messages: [
        { role: 'system', content: settings.context },
        { role: 'user', content: message }
      ],
      temperature: settings.temperature,
      max_tokens: 500
    }, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    return response.data.choices[0].message.content || 'Извините, не удалось получить ответ.';
  }

  private async chatWithAnthropicSettings(message: string, settings: { model: string; temperature: number; context: string; apiKey?: string }): Promise<string> {
    const apiKey = settings.apiKey || process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new Error('Anthropic API ключ не настроен');
    }
    
    const response = await axios.post('https://api.anthropic.com/v1/messages', {
      model: settings.model,
      system: settings.context,
      messages: [
        { role: 'user', content: message }
      ],
      max_tokens: 500
    }, {
      headers: {
        'x-api-key': apiKey,
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01'
      },
      timeout: 30000
    });

    return response.data.content[0].text || 'Извините, не удалось получить ответ.';
  }

  private async chatWithGeminiSettings(message: string, settings: { model: string; temperature: number; context: string; apiKey?: string }): Promise<string> {
    const apiKey = settings.apiKey || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('Gemini API ключ не настроен');
    }

    const prompt = `${settings.context}\n\nПользователь: ${message}`;
    
    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/${settings.model}:generateContent?key=${apiKey}`,
      {
        contents: [
          { parts: [{ text: prompt }] }
        ],
        generationConfig: {
          temperature: settings.temperature,
          maxOutputTokens: 500
        }
      },
      {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 30000
      }
    );

    return response.data.candidates[0].content.parts[0].text || 'Извините, не удалось получить ответ.';
  }

  async chat(message: string, moduleType: keyof ModuleContext = 'admin', context?: number[]): Promise<string> {
    try {
      // Проверяем тип модели
      if (this.model === 'huggingface-free') {
        return await this.chatWithHuggingFace(message, moduleType);
      } else if (this.model.startsWith('gpt-')) {
        return await this.chatWithOpenAI(message, moduleType);
      } else if (this.model.startsWith('claude-')) {
        return await this.chatWithAnthropic(message, moduleType);
      } else if (this.model.startsWith('gemini-')) {
        return await this.chatWithGemini(message, moduleType);
      } else {
        // Ollama модели
        return await this.chatWithOllama(message, moduleType, context);
      }
    } catch (error) {
      console.error('Ошибка AI сервиса:', error);
      return this.getFallbackResponse(message, moduleType);
    }
  }

  private async chatWithOllama(message: string, moduleType: keyof ModuleContext, context?: number[]): Promise<string> {
    const moduleContext = this.moduleContexts[moduleType];
    const systemPrompt = `${moduleContext}
    
    Пользователь спрашивает: ${message}`;

    const response = await axios.post(`${this.baseUrl}/api/generate`, {
      model: this.model,
      prompt: systemPrompt,
      stream: false,
      context: context || [],
      options: {
        temperature: 0.7,
        top_k: 40,
        top_p: 0.9
      }
    }, {
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json'
      }
    });

    const data: OllamaResponse = response.data;
    return data.response || 'Извините, не могу сгенерировать ответ.';
  }

  private async chatWithHuggingFace(message: string, moduleType: keyof ModuleContext): Promise<string> {
    const apiKey = process.env.HUGGINGFACE_API_KEY || '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';
    const moduleContext = this.moduleContexts[moduleType];
    const prompt = `${moduleContext}\n\nВопрос пользователя: ${message}\nОтвет:`;

    try {
      // Используем модель Google Gemma 2B IT
      const response = await axios.post(
        'https://api-inference.huggingface.co/models/google/gemma-2b-it',
        {
          inputs: prompt,
          parameters: {
            max_new_tokens: 300,
            temperature: 0.7,
            do_sample: true,
            return_full_text: false
          }
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          },
          timeout: 20000
        }
      );

      if (response.data && Array.isArray(response.data) && response.data[0] && response.data[0].generated_text) {
        let generatedText = response.data[0].generated_text;
        
        // Очищаем ответ от промпта, если он остался
        if (generatedText.includes('Ответ:')) {
          generatedText = generatedText.split('Ответ:').pop()?.trim() || generatedText;
        }
        
        // Обрезаем в разумных пределах и убираем незаконченные предложения
        const sentences = generatedText.split(/[.!?]\s+/);
        const cleanResponse = sentences.length > 1 
          ? sentences.slice(0, -1).join('. ') + '.'
          : generatedText.trim();
        
        return cleanResponse || 'Извините, не удалось получить подходящий ответ.';
      }

      return 'Извините, не удалось получить ответ от онлайн сервиса.';
    } catch (error: any) {
      console.error('Ошибка Hugging Face API:', error);
      
      if (error?.response?.status === 401) {
        throw new Error('Неверный API ключ Hugging Face. Проверьте настройки.');
      } else if (error?.response?.status === 503) {
        throw new Error('Модель Hugging Face временно недоступна. Попробуйте позже.');
      } else {
        throw new Error(`Ошибка Hugging Face API: ${error?.message || 'неизвестная ошибка'}`);
      }
    }
  }

  private async chatWithOpenAI(message: string, moduleType: keyof ModuleContext): Promise<string> {
    // Требует OPENAI_API_KEY
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error('OpenAI API ключ не настроен. Обратитесь к администратору.');
    }

    const moduleContext = this.moduleContexts[moduleType];
    
    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: this.model,
      messages: [
        { role: 'system', content: moduleContext },
        { role: 'user', content: message }
      ],
      temperature: 0.7,
      max_tokens: 500
    }, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    return response.data.choices[0].message.content || 'Извините, не удалось получить ответ.';
  }

  private async chatWithAnthropic(message: string, moduleType: keyof ModuleContext): Promise<string> {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new Error('Anthropic API ключ не настроен. Обратитесь к администратору.');
    }

    const moduleContext = this.moduleContexts[moduleType];
    
    const response = await axios.post('https://api.anthropic.com/v1/messages', {
      model: this.model,
      system: moduleContext,
      messages: [
        { role: 'user', content: message }
      ],
      max_tokens: 500
    }, {
      headers: {
        'x-api-key': apiKey,
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01'
      },
      timeout: 30000
    });

    return response.data.content[0].text || 'Извините, не удалось получить ответ.';
  }

  private async chatWithGemini(message: string, moduleType: keyof ModuleContext): Promise<string> {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('Gemini API ключ не настроен. Обратитесь к администратору.');
    }

    const moduleContext = this.moduleContexts[moduleType];
    const prompt = `${moduleContext}\n\nПользователь: ${message}`;
    
    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/${this.model}:generateContent?key=${apiKey}`,
      {
        contents: [
          { parts: [{ text: prompt }] }
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 500
        }
      },
      {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 30000
      }
    );

    return response.data.candidates[0].content.parts[0].text || 'Извините, не удалось получить ответ.';
  }

  private getFallbackResponse(message: string, moduleType: keyof ModuleContext = 'admin'): string {
    const lowercaseMessage = message.toLowerCase();
    
    if (lowercaseMessage.includes('статистик') || lowercaseMessage.includes('статистик')) {
      return 'Статистика за сегодня: В очереди сейчас примерно 15-25 человек, среднее время обслуживания 12-15 минут. Для получения точной статистики обратитесь к администратору системы.';
    }
    
    if (lowercaseMessage.includes('прогноз') || lowercaseMessage.includes('нагрузк')) {
      return 'Прогноз нагрузки: Обычно пик нагрузки приходится на 10:00-12:00 и 14:00-16:00. Рекомендуется увеличить количество операторов в эти периоды.';
    }
    
    if (lowercaseMessage.includes('документ') || lowercaseMessage.includes('справк')) {
      return 'Для получения справки обычно требуются: паспорт, заявление установленного образца. В зависимости от типа справки могут потребоваться дополнительные документы.';
    }
    
    if (lowercaseMessage.includes('время') || lowercaseMessage.includes('ожидан')) {
      return 'Среднее время ожидания в очереди составляет 10-15 минут. Время может варьироваться в зависимости от сложности услуг и загруженности.';
    }
    
    return 'Извините, ИИ-помощник временно недоступен. Обратитесь к администратору системы или попробуйте позже.';
  }

  async getModels(): Promise<string[]> {
    try {
      const response = await axios.get(`${this.baseUrl}/api/tags`);
      return response.data.models?.map((model: any) => model.name) || [];
    } catch (error) {
      console.error('Ошибка получения моделей:', error);
      return [this.model];
    }
  }

  setModel(model: string): void {
    this.model = model;
  }

  getModel(): string {
    return this.model;
  }

  updateModuleContext(moduleType: keyof ModuleContext, context: string): void {
    this.moduleContexts[moduleType] = context;
  }

  getModuleContext(moduleType: keyof ModuleContext): string {
    return this.moduleContexts[moduleType];
  }

  getAllModuleContexts(): ModuleContext {
    return { ...this.moduleContexts };
  }
}

export const ollamaService = new OllamaService();
