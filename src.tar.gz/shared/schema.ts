import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, date, time, jsonb, serial, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Departments (отделения)
export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  address: text("address"),
  phone: varchar("phone", { length: 20 }),
  workingHours: jsonb("working_hours"), // {"monday": {"start": "09:00", "end": "18:00"}, ...}
  workSchedule: jsonb("work_schedule"), // График работы по дням недели
  holidays: jsonb("holidays"), // Праздники и выходные дни
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Services (услуги)
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  estimatedTime: integer("estimated_time").default(15), // время в минутах
  departmentId: integer("department_id").references(() => departments.id),
  isActive: boolean("is_active").default(true),
  serviceCode: varchar("service_code", { length: 10 }).unique(), // A, B, C для типов услуг
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Operators (операторы)
export const operators = pgTable("operators", {
  id: serial("id").primaryKey(),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  username: varchar("username", { length: 50 }).unique().notNull(),
  email: varchar("email", { length: 255 }).unique(),
  phone: varchar("phone", { length: 20 }),
  departmentId: integer("department_id").references(() => departments.id),
  windowNumber: integer("window_number"),
  isActive: boolean("is_active").default(true),
  role: varchar("role", { length: 50 }).default("operator"), // operator, admin, supervisor
  passwordHash: varchar("password_hash", { length: 255 }),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Appointments (предварительные записи)
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  serviceId: integer("service_id").references(() => services.id),
  departmentId: integer("department_id").references(() => departments.id),
  clientName: varchar("client_name", { length: 255 }).notNull(),
  clientPhone: varchar("client_phone", { length: 20 }),
  clientEmail: varchar("client_email", { length: 255 }),
  appointmentDate: date("appointment_date").notNull(),
  appointmentTime: time("appointment_time").notNull(),
  pinCode: varchar("pin_code", { length: 10 }).unique().notNull(),
  status: varchar("status", { length: 20 }).default("scheduled"), // scheduled, confirmed, completed, cancelled, no_show
  additionalInfo: text("additional_info"),
  notifySms: boolean("notify_sms").default(false),
  notifyEmail: boolean("notify_email").default(false),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Tickets (талоны)
export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  ticketNumber: varchar("ticket_number", { length: 10 }), // A-15, B-08, etc.
  serviceId: integer("service_id").references(() => services.id),
  departmentId: integer("department_id").references(() => departments.id),
  appointmentId: integer("appointment_id").references(() => appointments.id), // NULL если талон без записи
  status: varchar("status", { length: 20 }).default("waiting"), // waiting, called, serving, completed, missed
  priority: integer("priority").default(0), // 0-обычный, 1-льготный
  issuedAt: timestamp("issued_at").default(sql`CURRENT_TIMESTAMP`),
  calledAt: timestamp("called_at"),
  servedAt: timestamp("served_at"),
  completedAt: timestamp("completed_at"),
  operatorId: integer("operator_id").references(() => operators.id),
  estimatedWaitTime: integer("estimated_wait_time"), // в минутах
  actualWaitTime: integer("actual_wait_time"), // в минутах
});

// Call History (история вызовов)
export const callHistory = pgTable("call_history", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").references(() => tickets.id),
  operatorId: integer("operator_id").references(() => operators.id),
  calledAt: timestamp("called_at").default(sql`CURRENT_TIMESTAMP`),
  callType: varchar("call_type", { length: 20 }).default("first_call"), // first_call, repeat_call
  response: varchar("response", { length: 20 }), // came, no_response
});

// Service Ratings (оценки обслуживания)
export const serviceRatings = pgTable("service_ratings", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").references(() => tickets.id),
  operatorId: integer("operator_id").references(() => operators.id),
  rating: integer("rating"), // 1-5
  comment: text("comment"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// System Settings (настройки системы)
export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).unique().notNull(),
  value: text("value"),
  description: text("description"),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Security Settings (настройки безопасности)
export const securitySettings = pgTable("security_settings", {
  id: serial("id").primaryKey(),
  externalAccessRestricted: boolean("external_access_restricted").default(false),
  allowedExternalPaths: jsonb("allowed_external_paths").default(['"/booking"']), // Разрешенные пути для внешнего доступа
  internalNetworkRanges: jsonb("internal_network_ranges").default(['["192.168.0.0/16", "10.0.0.0/8", "172.16.0.0/12", "127.0.0.1"]']), // Диапазоны внутренних IP
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
  updatedBy: varchar("updated_by", { length: 100 }), // Кто изменил настройку
});

// AI Chat Logs (логи ИИ чата)
export const aiChatLogs = pgTable("ai_chat_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"), // ID пользователя (оператора/админа)
  userType: varchar("user_type", { length: 20 }), // operator, admin
  query: text("query").notNull(),
  response: text("response").notNull(),
  modelUsed: varchar("model_used", { length: 50 }), // llama3, mistral, etc.
  processingTime: integer("processing_time"), // время обработки в мс
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Terminal Settings (настройки терминала)
export const terminalSettings = pgTable("terminal_settings", {
  id: serial("id").primaryKey(),
  departmentId: integer("department_id").references(() => departments.id), // Привязка к отделению
  terminalId: varchar("terminal_id", { length: 100 }).unique(), // Уникальный ID терминала
  location: varchar("location", { length: 255 }), // Физическое расположение терминала
  theme: varchar("theme", { length: 50 }).default("classic"), // classic, modern, minimal
  displayTimeSeconds: integer("display_time_seconds").default(5), // время показа талона
  organizationName: varchar("organization_name", { length: 255 }).default("ЭЛЕКТРОННАЯ ОЧЕРЕДЬ"),
  ticketTemplate: text("ticket_template"), // JSON шаблон для печати
  backgroundColor: varchar("background_color", { length: 7 }).default("#ffffff"),
  textColor: varchar("text_color", { length: 7 }).default("#000000"),
  accentColor: varchar("accent_color", { length: 7 }).default("#0079F2"),
  showWaitingTime: boolean("show_waiting_time").default(true),
  showQueuePosition: boolean("show_queue_position").default(true),
  enableSound: boolean("enable_sound").default(true),
  isConfigured: boolean("is_configured").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Display Settings (настройки дисплея)
export const displaySettings = pgTable("display_settings", {
  id: serial("id").primaryKey(),
  departmentId: integer("department_id").references(() => departments.id), // Привязка к отделению
  displayId: varchar("display_id", { length: 100 }).unique(), // Уникальный ID дисплея
  location: varchar("location", { length: 255 }), // Физическое расположение дисплея
  organizationName: varchar("organization_name", { length: 255 }).default("ЭЛЕКТРОННАЯ ОЧЕРЕДЬ"),
  backgroundColor: varchar("background_color", { length: 7 }).default("#ffffff"),
  textColor: varchar("text_color", { length: 7 }).default("#000000"),
  accentColor: varchar("accent_color", { length: 7 }).default("#2563eb"),
  headerColor: varchar("header_color", { length: 7 }).default("#1e40af"),
  showTime: boolean("show_time").default(true),
  showCompletedCount: boolean("show_completed_count").default(true),
  fontSize: integer("font_size").default(16),
  refreshInterval: integer("refresh_interval").default(3),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Ticket Settings (настройки талонов)
export const ticketSettings = pgTable("ticket_settings", {
  id: serial("id").primaryKey(),
  ticketNumberLength: integer("ticket_number_length").default(4),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Operator Chat Messages (сообщения чата операторов)
export const operatorChatMessages = pgTable("operator_chat_messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").references(() => operators.id).notNull(),
  receiverId: integer("receiver_id").references(() => operators.id), // NULL для группового чата
  message: text("message"),
  messageType: varchar("message_type", { length: 20 }).default("text"), // text, file, image
  fileName: varchar("file_name", { length: 255 }),
  fileSize: integer("file_size"),
  filePath: varchar("file_path", { length: 500 }),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Operator Status (статус операторов)
export const operatorStatus = pgTable("operator_status", {
  id: serial("id").primaryKey(),
  operatorId: integer("operator_id").references(() => operators.id).notNull().unique(),
  status: varchar("status", { length: 20 }).default("available"), // available, busy, break, offline
  breakStartTime: timestamp("break_start_time"),
  breakEndTime: timestamp("break_end_time"),
  breakReason: varchar("break_reason", { length: 100 }),
  lastActivity: timestamp("last_activity").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Database Backups (резервные копии базы данных)
export const databaseBackups = pgTable("database_backups", {
  id: serial("id").primaryKey(),
  fileName: varchar("file_name", { length: 255 }).notNull(),
  filePath: varchar("file_path", { length: 500 }).notNull(),
  fileSize: integer("file_size").notNull(),
  backupType: varchar("backup_type", { length: 20 }).default("manual"), // manual, auto_weekly
  description: text("description"),
  tablesIncluded: jsonb("tables_included"), // список таблиц в бэкапе
  recordsCount: integer("records_count").default(0),
  compressionType: varchar("compression_type", { length: 10 }).default("gzip"),
  userId: integer("user_id"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Import Records (записи импорта для предотвращения дублирования)
export const importRecords = pgTable("import_records", {
  id: serial("id").primaryKey(),
  tableType: varchar("table_type", { length: 50 }).notNull(), // tickets, appointments, etc
  originalId: integer("original_id").notNull(),
  importedId: integer("imported_id").notNull(),
  importHash: varchar("import_hash", { length: 64 }).notNull(), // MD5 hash уникальных полей записи
  importDate: timestamp("import_date").default(sql`CURRENT_TIMESTAMP`),
  userId: integer("user_id"),
});



// Relations
export const departmentsRelations = relations(departments, ({ many }) => ({
  services: many(services),
  operators: many(operators),
  appointments: many(appointments),
  tickets: many(tickets),
}));

export const servicesRelations = relations(services, ({ one, many }) => ({
  department: one(departments, {
    fields: [services.departmentId],
    references: [departments.id],
  }),
  appointments: many(appointments),
  tickets: many(tickets),
}));

export const operatorsRelations = relations(operators, ({ one, many }) => ({
  department: one(departments, {
    fields: [operators.departmentId],
    references: [departments.id],
  }),
  tickets: many(tickets),
  callHistory: many(callHistory),
  serviceRatings: many(serviceRatings),
  sentMessages: many(operatorChatMessages, { relationName: "sentMessages" }),
  receivedMessages: many(operatorChatMessages, { relationName: "receivedMessages" }),
  status: one(operatorStatus),
}));

export const appointmentsRelations = relations(appointments, ({ one, many }) => ({
  service: one(services, {
    fields: [appointments.serviceId],
    references: [services.id],
  }),
  department: one(departments, {
    fields: [appointments.departmentId],
    references: [departments.id],
  }),
  tickets: many(tickets),
}));

export const ticketsRelations = relations(tickets, ({ one, many }) => ({
  service: one(services, {
    fields: [tickets.serviceId],
    references: [services.id],
  }),
  department: one(departments, {
    fields: [tickets.departmentId],
    references: [departments.id],
  }),
  appointment: one(appointments, {
    fields: [tickets.appointmentId],
    references: [appointments.id],
  }),
  operator: one(operators, {
    fields: [tickets.operatorId],
    references: [operators.id],
  }),
  callHistory: many(callHistory),
  serviceRatings: many(serviceRatings),
}));

export const callHistoryRelations = relations(callHistory, ({ one }) => ({
  ticket: one(tickets, {
    fields: [callHistory.ticketId],
    references: [tickets.id],
  }),
  operator: one(operators, {
    fields: [callHistory.operatorId],
    references: [operators.id],
  }),
}));

export const serviceRatingsRelations = relations(serviceRatings, ({ one }) => ({
  ticket: one(tickets, {
    fields: [serviceRatings.ticketId],
    references: [tickets.id],
  }),
  operator: one(operators, {
    fields: [serviceRatings.operatorId],
    references: [operators.id],
  }),
}));

export const operatorChatMessagesRelations = relations(operatorChatMessages, ({ one }) => ({
  sender: one(operators, {
    fields: [operatorChatMessages.senderId],
    references: [operators.id],
    relationName: "sentMessages",
  }),
  receiver: one(operators, {
    fields: [operatorChatMessages.receiverId],
    references: [operators.id],
    relationName: "receivedMessages",
  }),
}));

export const operatorStatusRelations = relations(operatorStatus, ({ one }) => ({
  operator: one(operators, {
    fields: [operatorStatus.operatorId],
    references: [operators.id],
  }),
}));



// Insert schemas
export const insertDepartmentSchema = createInsertSchema(departments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertServiceSchema = createInsertSchema(services).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOperatorSchema = createInsertSchema(operators).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  pinCode: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  id: true,
  ticketNumber: true,
});

export const insertCallHistorySchema = createInsertSchema(callHistory).omit({
  id: true,
});

export const insertServiceRatingSchema = createInsertSchema(serviceRatings).omit({
  id: true,
  createdAt: true,
});

export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertAiChatLogSchema = createInsertSchema(aiChatLogs).omit({
  id: true,
  createdAt: true,
});

export const insertTerminalSettingsSchema = createInsertSchema(terminalSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertDisplaySettingsSchema = createInsertSchema(displaySettings).omit({
  id: true,
  updatedAt: true,
});

export const insertTicketSettingsSchema = createInsertSchema(ticketSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOperatorChatMessageSchema = createInsertSchema(operatorChatMessages).omit({
  id: true,
  createdAt: true,
});

export const insertOperatorStatusSchema = createInsertSchema(operatorStatus).omit({
  id: true,
  lastActivity: true,
  updatedAt: true,
});

export const insertSecuritySettingsSchema = createInsertSchema(securitySettings).omit({
  id: true,
  updatedAt: true,
});

export const insertOperatorMessageSchema = createInsertSchema(operatorChatMessages).omit({
  id: true,
  createdAt: true,
});

// Add type exports for operator messages
export type OperatorMessage = typeof operatorChatMessages.$inferSelect;
export type InsertOperatorMessage = z.infer<typeof insertOperatorMessageSchema>;



// Types
export type InsertDepartment = z.infer<typeof insertDepartmentSchema>;
export type Department = typeof departments.$inferSelect;

export type InsertService = z.infer<typeof insertServiceSchema>;
export type Service = typeof services.$inferSelect;

export type InsertOperator = z.infer<typeof insertOperatorSchema>;
export type Operator = typeof operators.$inferSelect;

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;

export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;

export type InsertCallHistory = z.infer<typeof insertCallHistorySchema>;
export type CallHistory = typeof callHistory.$inferSelect;

export type InsertServiceRating = z.infer<typeof insertServiceRatingSchema>;
export type ServiceRating = typeof serviceRatings.$inferSelect;

export type InsertSystemSetting = z.infer<typeof insertSystemSettingSchema>;
export type SystemSetting = typeof systemSettings.$inferSelect;

export type InsertAiChatLog = z.infer<typeof insertAiChatLogSchema>;
export type AiChatLog = typeof aiChatLogs.$inferSelect;

export type InsertTerminalSettings = z.infer<typeof insertTerminalSettingsSchema>;
export type TerminalSettings = typeof terminalSettings.$inferSelect;

export type InsertDisplaySettings = z.infer<typeof insertDisplaySettingsSchema>;
export type DisplaySettings = typeof displaySettings.$inferSelect;

export type InsertTicketSettings = z.infer<typeof insertTicketSettingsSchema>;
export type TicketSettings = typeof ticketSettings.$inferSelect;

export type InsertOperatorChatMessage = z.infer<typeof insertOperatorChatMessageSchema>;
export type OperatorChatMessage = typeof operatorChatMessages.$inferSelect;

export type InsertOperatorStatus = z.infer<typeof insertOperatorStatusSchema>;
export type OperatorStatus = typeof operatorStatus.$inferSelect;

export type InsertSecuritySettings = z.infer<typeof insertSecuritySettingsSchema>;
export type SecuritySettings = typeof securitySettings.$inferSelect;



// AI Settings (расширенные настройки AI)
export const aiSettings = pgTable("ai_settings", {
  id: serial("id").primaryKey(),
  settingName: varchar("setting_name", { length: 100 }).notNull().default("Default AI Setting"),
  providerType: varchar("provider_type", { length: 50 }).notNull().default("ollama"), // ollama, openai, anthropic, gemini
  modelName: varchar("model_name", { length: 100 }).notNull().default("llama3.2"),
  temperature: integer("temperature").default(70), // 0-100
  context: text("context"),
  module: varchar("module", { length: 20 }), // booking, terminal, operator, display, admin
  apiUrl: varchar("api_url", { length: 500 }), // для онлайн AI сервисов
  apiKey: varchar("api_key", { length: 255 }), // зашифрованный ключ API
  isOnline: boolean("is_online").default(false), // локальная Ollama или онлайн сервис
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Operator Services (связь операторов и услуг many-to-many)
export const operatorServices = pgTable("operator_services", {
  id: serial("id").primaryKey(),
  operatorId: integer("operator_id").notNull().references(() => operators.id, { onDelete: "cascade" }),
  serviceId: integer("service_id").notNull().references(() => services.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Insert schemas for new tables
export const insertAiSettingsSchema = createInsertSchema(aiSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOperatorServicesSchema = createInsertSchema(operatorServices).omit({
  id: true,
  createdAt: true,
});

// Email Settings (настройки почты)
export const emailSettings = pgTable("email_settings", {
  id: serial("id").primaryKey(),
  smtpHost: varchar("smtp_host", { length: 255 }),
  smtpPort: integer("smtp_port").default(587),
  smtpUser: varchar("smtp_user", { length: 255 }),
  smtpPassword: varchar("smtp_password", { length: 255 }),
  fromEmail: varchar("from_email", { length: 255 }),
  adminEmail: varchar("admin_email", { length: 255 }),
  sendTime: time("send_time").default("08:00"), // время отправки ежедневных отчетов
  enableDailyReports: boolean("enable_daily_reports").default(false),
  isActive: boolean("is_active").default(true),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// Import/Export Logs (логи импорта/экспорта)
export const importExportLogs = pgTable("import_export_logs", {
  id: serial("id").primaryKey(),
  type: varchar("type", { length: 20 }).notNull(), // import, export
  dataType: varchar("data_type", { length: 50 }).notNull(), // appointments, tickets, statistics
  fileName: varchar("file_name", { length: 255 }),
  recordsCount: integer("records_count"),
  status: varchar("status", { length: 20 }).default("success"), // success, error
  errorMessage: text("error_message"),
  userId: integer("user_id"), // ID admin'а who performed the operation
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`),
});

// Statistics Cache (кэш статистики)
export const statisticsCache = pgTable("statistics_cache", {
  id: serial("id").primaryKey(),
  dateKey: date("date_key").notNull(),
  departmentId: integer("department_id").references(() => departments.id),
  totalTickets: integer("total_tickets").default(0),
  completedTickets: integer("completed_tickets").default(0),
  averageWaitTime: integer("average_wait_time").default(0),
  averageServiceTime: integer("average_service_time").default(0),
  peakHour: integer("peak_hour"), // час пик (0-23)
  satisfactionRating: integer("satisfaction_rating").default(0), // средняя оценка * 100
  dataJson: jsonb("data_json"), // дополнительные статистики
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

// AI Chat Sessions (сессии AI чата)
export const aiChatSessions = pgTable("ai_chat_sessions", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id", { length: 100 }).unique().notNull(),
  userId: integer("user_id"),
  userType: varchar("user_type", { length: 20 }), // admin, operator
  module: varchar("module", { length: 20 }), // admin, operator, etc.
  isActive: boolean("is_active").default(true),
  startedAt: timestamp("started_at").default(sql`CURRENT_TIMESTAMP`),
  endedAt: timestamp("ended_at"),
});

// Insert schemas for new tables
export const insertEmailSettingsSchema = createInsertSchema(emailSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertImportExportLogSchema = createInsertSchema(importExportLogs).omit({
  id: true,
  createdAt: true,
});

export const insertDatabaseBackupSchema = createInsertSchema(databaseBackups).omit({
  id: true,
  createdAt: true,
});

export const insertImportRecordSchema = createInsertSchema(importRecords).omit({
  id: true,
  importDate: true,
});

export const insertStatisticsCacheSchema = createInsertSchema(statisticsCache).omit({
  id: true,
  updatedAt: true,
});

export const insertAiChatSessionSchema = createInsertSchema(aiChatSessions).omit({
  id: true,
  startedAt: true,
});

// Types for new tables
export type InsertAiSettings = z.infer<typeof insertAiSettingsSchema>;
export type AiSettings = typeof aiSettings.$inferSelect;

export type InsertOperatorServices = z.infer<typeof insertOperatorServicesSchema>;
export type OperatorServices = typeof operatorServices.$inferSelect;

export type InsertEmailSettings = z.infer<typeof insertEmailSettingsSchema>;
export type EmailSettings = typeof emailSettings.$inferSelect;

export type InsertImportExportLog = z.infer<typeof insertImportExportLogSchema>;
export type ImportExportLog = typeof importExportLogs.$inferSelect;

export type InsertDatabaseBackup = z.infer<typeof insertDatabaseBackupSchema>;
export type DatabaseBackup = typeof databaseBackups.$inferSelect;

export type InsertImportRecord = z.infer<typeof insertImportRecordSchema>;
export type ImportRecord = typeof importRecords.$inferSelect;

export type InsertStatisticsCache = z.infer<typeof insertStatisticsCacheSchema>;
export type StatisticsCache = typeof statisticsCache.$inferSelect;

export type InsertAiChatSession = z.infer<typeof insertAiChatSessionSchema>;
export type AiChatSession = typeof aiChatSessions.$inferSelect;

// Legacy user types for compatibility
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Voice Settings Table  
export const voiceSettings = pgTable('voice_settings', {
  id: serial('id').primaryKey(),
  engine: varchar('engine', { length: 20 }).notNull().default('rhvoice'), // 'rhvoice', 'browser'
  voiceName: varchar('voice_name', { length: 50 }).notNull().default('elena'),
  rate: integer('rate').notNull().default(100), // 50-200
  pitch: integer('pitch').notNull().default(100), // 50-200  
  volume: integer('volume').notNull().default(100), // 0-100
  enabled: boolean('enabled').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const insertVoiceSettingsSchema = createInsertSchema(voiceSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertVoiceSettings = z.infer<typeof insertVoiceSettingsSchema>;
export type VoiceSettings = typeof voiceSettings.$inferSelect;

// Настройки табло (электронные панели с номерами талонов)
export const displayBoardSettings = pgTable('display_board_settings', {
  id: serial('id').primaryKey(),
  portPath: varchar('port_path', { length: 50 }).notNull().default('/dev/ttyUSB0'),
  baudRate: integer('baud_rate').notNull().default(9600),
  enabled: boolean('enabled').notNull().default(false),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Конфигурация отдельных табло
export const displayBoards = pgTable('display_boards', {
  id: serial('id').primaryKey(),
  address: integer('address').notNull().unique(), // адрес табло в сети (1-254)
  operatorId: integer('operator_id').notNull().references(() => operators.id),
  windowNumber: integer('window_number').notNull(),
  name: varchar('name', { length: 100 }), // название/описание табло
  enabled: boolean('enabled').notNull().default(true),
  currentTicket: varchar('current_ticket', { length: 50 }), // текущий отображаемый номер талона
  lastUpdated: timestamp('last_updated').defaultNow(),
  createdAt: timestamp('created_at').defaultNow(),
});

export const insertDisplayBoardSettingsSchema = createInsertSchema(displayBoardSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDisplayBoardSchema = createInsertSchema(displayBoards).omit({
  id: true,
  lastUpdated: true,
  createdAt: true,
});

export type InsertDisplayBoardSettings = z.infer<typeof insertDisplayBoardSettingsSchema>;
export type DisplayBoardSettings = typeof displayBoardSettings.$inferSelect;
export type InsertDisplayBoard = z.infer<typeof insertDisplayBoardSchema>;
export type DisplayBoard = typeof displayBoards.$inferSelect;

// Связи для displayBoards (определяем в конце файла)
export const displayBoardsRelations = relations(displayBoards, ({ one }) => ({
  operator: one(operators, {
    fields: [displayBoards.operatorId],
    references: [operators.id],
  }),
}));

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
